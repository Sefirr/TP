package tp.pr3.mv.StrategyOut;

public class NullOut implements StrategyOut {

	@Override
	public void open() throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void close() {
		// TODO Auto-generated method stub

	}

	@Override
	public void write(int c) {
		// TODO Auto-generated method stub

	}

}