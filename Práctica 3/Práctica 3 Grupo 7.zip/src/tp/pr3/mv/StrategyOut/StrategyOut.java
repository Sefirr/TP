package tp.pr3.mv.StrategyOut;

public interface StrategyOut {
	
	public void open() throws Exception;
	public void close();
	public void write(int c);
	
	
}
