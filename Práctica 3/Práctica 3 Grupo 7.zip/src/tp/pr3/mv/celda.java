
package tp.pr3.mv;

/**
 * Una clase celda para representar las posiciones en la memoria.
 * Cada celda queda contiene un atributo posici�n que indica su posici�n y 
 * un atributo contenido que indica lo que contiene la celda correspondiente.
 * @version 1.0, 17/11/2013
 * @author Grupo_7
 */
public class celda {
	
	private int posicion; // Posici�n de la celda
	private int contenido; // Contenido de la celda
	
	/**
	 * 	M�todo accedente que nos devuelve la posicion de la celda
	 * @return Devuelve la posici�n de la celda
	 */
	
	 public int getPosicion() {
		return posicion;
	}
	 
	/**
	 * 	M�todo accedente que nos devuelve el contenido de la celda
	 * @return Devuelve el contenido de la celda
	 */
	 	
	public int getContenido() {
		return contenido;
	}
	
	/**
	  * M�todo constructor que inicializa los atributos del objeto de tipo celda
	  * de dos par�metros.
	  * @param pos Posici�n de la celda.
	  * @param contenido Contenido de la celda.
	  */
	
	public celda(int pos, int contenido) {
		this.posicion = pos;
		this.contenido = contenido;
	}
	
	/**
	 * M�todo constructor que inicializa los atributos del objeto de tipo celda
	 * de un par�metro.
	 * @param contenido Contenido de la celda.
	 */
	public celda(int contenido) {
		super();
		this.contenido = contenido;
	}
	
	/**
	 * Muestra la celda.
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return "[" + posicion  + "]:" + contenido;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
