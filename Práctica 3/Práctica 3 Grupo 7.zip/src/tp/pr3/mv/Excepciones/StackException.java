package tp.pr3.mv.Excepciones;

@SuppressWarnings("serial")
public class StackException extends Exception {
	
	private String _cause;
	
	public StackException(String cause) {
		super();
		this._cause = cause;
	}
	
	@Override
	public String toString() {
		return _cause;
	}

}
