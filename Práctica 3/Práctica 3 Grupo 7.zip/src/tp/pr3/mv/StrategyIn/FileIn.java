package tp.pr3.mv.StrategyIn;

import java.io.*;

public class FileIn implements StrategyIn {

	String fname;
	FileReader f;
	
	public FileIn(String fname) {
		this.fname = fname;		
	}
	
	@Override
	public void open() {
		// TODO Auto-generated method stub
		try {
			f = new FileReader(fname);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("");
		}
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		try {
			f.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("");
		}
	}

	@Override
	public int read() {
		// TODO Auto-generated method stub
		try {
			if(f.ready()) 
				return f.read();
			else 
				return -1;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return 0;
	}
	
	
	
	

}
