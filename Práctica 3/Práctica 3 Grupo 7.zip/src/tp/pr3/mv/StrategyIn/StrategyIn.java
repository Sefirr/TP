package tp.pr3.mv.StrategyIn;

public interface StrategyIn {
	
	public void open();
	public void close();
	public int read();

	
}
