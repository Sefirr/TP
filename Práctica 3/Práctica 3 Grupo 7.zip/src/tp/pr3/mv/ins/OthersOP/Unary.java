package tp.pr3.mv.ins.OthersOP;

import tp.pr3.mv.ins.Instruction;

public abstract class Unary extends Others {

	public Unary() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	public Instruction parseIns(String cadena){
		String [] tok = cadena.split(" ");
		if (tok.length == 1){
			if (tok[0].equalsIgnoreCase(this.toString())){
				return Instruccion();
			}
			else return null;
		}
		else return null;
	}
	
	protected abstract Instruction Instruccion();
	public abstract String toString();

}
