package tp.pr3.mv.ins.OthersOP;

import tp.pr3.mv.ExecutionManager;
import tp.pr3.mv.Memory;
import tp.pr3.mv.OperandStack;
import tp.pr3.mv.Excepciones.MemoryException;
import tp.pr3.mv.StrategyIn.StrategyIn;
import tp.pr3.mv.StrategyOut.StrategyOut;
import tp.pr3.mv.ins.Instruction;

public class WRITE extends Others{
	
	private int pos;
	private int value;

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Unary.
	 */
	public WRITE() {
		// TODO Auto-generated constructor stub
		super();
	}

	/**
	 * M�todo constructor con par�metros que llama al constructor de
	 * Unary.
	 */
	public WRITE(int posicion, int valor) {
		super();
		this.pos = posicion;
		this.value = valor;
		// TODO Auto-generated constructor stub
	}
	
	private static boolean isNumeric(String cadena){
		try {
			Integer.parseInt(cadena);
			return true;
		} catch (NumberFormatException nfe){
			return false;
		}
	}

	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws MemoryException {
		// TODO Auto-generated method stub
	
		if(pos >= 0) {
			memoria.insertar(pos, value);
			gestor.setNextPc(gestor.getCurrentPc()+1);
		}
		else {
			throw new MemoryException("Error ejecutando WRITE " + pos + value + " direccion incorrecta (" + pos + ")");
		}
	}

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "WRITE " + pos + " " + value;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "WRITE";
	}

	@Override
	public Instruction parseIns(String cadena) {
		// TODO Auto-generated method stub
		String [] tok = cadena.split(" ");
			if (tok.length == 3) {
				if (tok[0].equalsIgnoreCase(this.toString())) {
					if(isNumeric(tok[1]) && isNumeric(tok[2]))
						return new WRITE(Integer.parseInt(tok[1]), Integer.parseInt(tok[2]));
					else		
						return null;
				}
			}

		return null;
	}

	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n PUSH.
	 * @return Devuelve si el comando es correcto o no.
	 */


}