package tp.pr3.mv.ins.OthersOP;

import tp.pr3.mv.ins.Instruction;

/**
 * Clase que implementa la interfaz Instruction para el resto de operaciones
 * de dos par�metros.
 * @version 2.0
 * @author Grupo_7
 *
 */
public abstract class Binary extends Others {
	
	protected Integer parametro; // Par�metro de la instrucci�n.

	/**
	 * M�todo constructor sin par�metros de los objetos de la clase Binary
	 */
	public Binary() {
		// TODO Auto-generated constructor stub
		super();
	}

	/**
	 * M�todo constructor con par�metros de los objetos de la clase Binary
	 */
	public Binary(Integer parametro) {
		super();
		this.parametro = parametro;
		// TODO Auto-generated constructor stub
	}
	
	private static boolean isNumeric(String cadena){
		try {
			Integer.parseInt(cadena);
			return true;
		} catch (NumberFormatException nfe){
			return false;
		}
	}
	
	/**
	 * M�todo que implementa el m�todo parseIns para las instrucciones de dos par�metros.
	 * @param cadena Es la cadena correspondiente a la instrucci�n.
	 * @return Devuelve un objeto de tipo Instruction.
	 */
	public Instruction parseIns(String cadena){
		String [] tok = cadena.split(" ");
		
			if (tok.length == 2) {
				if (tok[0].equalsIgnoreCase(this.toString())) {
					if(isNumeric(tok[1]))
							return Instruccion(Integer.parseInt(tok[1]));
					else
							return null;
				}
			}

		return null;
	}
	
	//M�todos abstractos.
	protected abstract Instruction Instruccion(int parseInt);
	public abstract String toString();
	public abstract String name();

}
