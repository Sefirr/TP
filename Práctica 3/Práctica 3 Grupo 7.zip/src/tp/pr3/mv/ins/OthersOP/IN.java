package tp.pr3.mv.ins.OthersOP;

import java.io.FileNotFoundException;
import java.io.IOException;

import tp.pr3.mv.ExecutionManager;
import tp.pr3.mv.Memory;
import tp.pr3.mv.OperandStack;
import tp.pr3.mv.StrategyIn.StrategyIn;
import tp.pr3.mv.StrategyOut.StrategyOut;
import tp.pr3.mv.ins.Instruction;

public class IN extends Unary {
	
	public IN() {
		super();
	}

	

	@Override
	protected Instruction Instruccion() {
		// TODO Auto-generated method stub
		return new IN();
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "IN";
	}
	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "IN";
	}



	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub

		int valor = in.read();
		pila.apilar(valor);
		gestor.setNextPc(gestor.getCurrentPc() + 1);

	}
	
}
