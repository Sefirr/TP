package tp.pr3.mv.ins.OthersOP;

import tp.pr3.mv.ExecutionManager;
import tp.pr3.mv.Memory;
import tp.pr3.mv.OperandStack;
import tp.pr3.mv.Excepciones.MemoryException;
import tp.pr3.mv.Excepciones.StackException;
import tp.pr3.mv.StrategyIn.StrategyIn;
import tp.pr3.mv.StrategyOut.StrategyOut;
import tp.pr3.mv.ins.Instruction;

public class STOREIND extends Unary {

	public STOREIND() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws MemoryException, StackException {
		int cima, subcima;
		cima = pila.getCima();
		pila.desapilar();
		subcima = pila.getCima();
		if(pila.getIndice() > 0) {
			if(subcima >= 0) {
				memoria.insertar(subcima, cima);
				gestor.setNextPc(gestor.getCurrentPc()+1);
			} else {
				throw new MemoryException("Error ejecutando STOREIND " + subcima + " direccion incorrecta (" + subcima + ")");
			}
		} else {
			throw new StackException("Error ejecutando STOREIND: faltan operandos en la pila (hay " + pila.getIndice() +")");
		}
	}

	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada STORE.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion() {
		// TODO Auto-generated method stub
		return new STOREIND();
	}
	
	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente al
	 * toString de STORE.
	 * @return Devuelve la cadena correspondiente a la instrucci�n STORE.
	 */
	@Override
	public String toString() {
		return "STOREIND";
	}

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "STOREIND";
	}

}
