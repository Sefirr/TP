package tp.pr3.mv.ins.BooleansOP;

import tp.pr3.mv.ExecutionManager;
import tp.pr3.mv.Memory;
import tp.pr3.mv.OperandStack;
import tp.pr3.mv.Excepciones.StackException;
import tp.pr3.mv.StrategyIn.StrategyIn;
import tp.pr3.mv.StrategyOut.StrategyOut;
import tp.pr3.mv.ins.Instruction;

/**
 * Clase derivada de Booleans que representa la instrucci�n OR.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class OR extends Booleans {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Booleans.
	 */
	public OR() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n OR.
	 * @return Devuelve si el comando es correcto o no.
	 * @throws BooleanException 
	 */
	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws StackException{
		boolean cima, subcima;
		boolean operacion;
		
		if(pila.getIndice() > 1) {
			cima = (pila.getCima() != 0) ;
			pila.desapilar();
			subcima = (pila.getCima() != 0);
			pila.desapilar();
			
			
	
			operacion = subcima || cima;
			
			if(operacion)
				pila.apilar(1);
			else {
				pila.apilar(0);
			}
			
			gestor.setNextPc(gestor.getCurrentPc()+1);
			
		} else {
			throw new StackException("Error ejecutando OR: faltan operandos en la pila (hay " + pila.getIndice() +")");

		}
	}
	
	/**
	 * M�todo de Booleans que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada OR.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion(){
		return new OR();
	}
	
	/**
	 * M�todo de Booleans que se sobreescribe aqui correspondiente al
	 * toString de OR.
	 * @return Devuelve la cadena correspondiente a la instrucci�n OR.
	 */
	@Override
	public String toString(){
		return "OR";
	}
	
	@Override
	public String name(){
		return "OR";
	}
	

}
