package tp.pr3.mv.ins.BooleansOP;

import tp.pr3.mv.ExecutionManager;
import tp.pr3.mv.Memory;
import tp.pr3.mv.OperandStack;
import tp.pr3.mv.Excepciones.StackException;
import tp.pr3.mv.StrategyIn.StrategyIn;
import tp.pr3.mv.StrategyOut.StrategyOut;
import tp.pr3.mv.ins.Instruction;

/**
 * Clase derivada de Booleans que representa la instrucci�n NOT.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class NOT extends Booleans {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Booleans.
	 */
	public NOT() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n NOT.
	 * @return Devuelve si el comando es correcto o no.
	 * @throws BooleanException 
	 */
	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws StackException{
		boolean operacion;
		
		if(pila.getIndice() > 1) {
			operacion = (pila.getCima() != 0) ;
			pila.desapilar();
			
			if(operacion)
				pila.apilar(0);
			else {
				pila.apilar(1);
			}
			
			gestor.setNextPc(gestor.getCurrentPc()+1);
			
		} else {
			throw new StackException("Error ejecutando NOT: faltan operandos en la pila (hay " + pila.getIndice() +")");

		}
	}
	
	/**
	 * M�todo de Booleans que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada NOT.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion(){
		return new NOT();
	}
	
	/**
	 * M�todo de Booleans que se sobreescribe aqui correspondiente al
	 * toString de NOT.
	 * @return Devuelve la cadena correspondiente a la instrucci�n NOT.
	 */
	@Override
	public String toString(){
		return "NOT";
	}
	
	@Override
	public String name(){
		return "NOT";
	}

}
