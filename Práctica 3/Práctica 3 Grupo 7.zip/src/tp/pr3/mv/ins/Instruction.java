package tp.pr3.mv.ins;

import tp.pr3.mv.ExecutionManager;
import tp.pr3.mv.Memory;
import tp.pr3.mv.OperandStack;
import tp.pr3.mv.StrategyIn.StrategyIn;
import tp.pr3.mv.StrategyOut.StrategyOut;

/**
 * Interfaz correspondiente a las instrucciones. Los m�todos se sobrescriben en las
 * clases derivadas de las clases que implementan la interfaz para que todo funcione
 * correctamente.
 * @version 2.0
 * @author Grupo_7
 *
 */
public interface Instruction {
	
	// M�todos abstractos
	public abstract void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws Exception;
	public abstract Instruction parseIns(String cadena);
	public abstract String toString();
	public abstract String name();

}
