
package tp.pr3.mv;

/**
 * Una clase memoria para representar la memoria de la CPU.
 * Cada memoria contiene un atributo constante MAX_MEMORY correspondiente 
 * al m�ximo de elementos de la memoria, un atributo array correspondiente al
 * array de celdas de la memoria y un contador que indica el n�mero de elementos
 * almacenados en memoria.
 * @version 1.0, 17/11/2013
 * @author Grupo_7
 */
public class Memory {
	private final int MAX_MEMORY = 100; // M�ximo de elementos en memoria
	private celda[] array; //Array de celdas de la memoria
	private int contador; // Contador del array que indica cu�ntos elementos hay en memoria.
	
	/**
	 * M�todo constructor que inicializa los atributos del objeto de tipo Memory
	 * sin par�metros.
	 */
	
	public Memory() {
		this.array = new celda[MAX_MEMORY];
		this.contador = 0;
	}
	
	/**
	 * M�todo accedente que devuelve el n�mero de elementos de la memoria.
	 * @return N�mero de elementos de la memoria.
	 */
	
	public int getContador() {
		return contador;
	}
	
	/**
	 * Busca si la posici�n en la que quieres introducir la cima de la pila ya existe 
	 * para poder modificarla.
	 * @param indice Posici�n en la que quiere colocar la cima de la pila.
	 * @return Devuelve la posici�n existente en donde se quiere a�adir la cima.
	 */
	
	private int buscarPosicion(int indice) {

		boolean encontrada = false;
		int ini = 0;
		int fin = contador - 1;
		int mitad = 0;
		int pos = 0;

		while ((ini <= fin) && !encontrada) {
			mitad = (ini + fin) / 2;
			if ( indice == array[mitad].getPosicion()) 
				encontrada = true;
			else if (indice < array[mitad].getPosicion()) 
				fin = mitad - 1;
			else 
				ini = mitad + 1;
		}
		
		if(encontrada) {
			pos = mitad;
		}
		else {
			pos = 0;
		}
			
		return pos;
	}
	
	/**
	 * Comprueba si la posici�n coincide con el indice
	 * @param pos
	 * @return true si la posici�n coincide con el indice
	 */
	public boolean comprobar(int indice) {
		boolean comprobar;
		int buscado = buscarPosicion(indice);
		if(array[buscado].getPosicion() == indice)
			comprobar = true;
		else 
			comprobar = false;
		
		return comprobar;
	}
	
	/**
	 * Devuelve el contenido de la celda correspondiente al indice.
	 * @param indice Posici�n del dato que se quiere a�adir a la memoria.
	 * @return El contenido de la celda con ese indice.
	 */
	
	public int ObtenerContenido(int indice) {
		int buscado = buscarPosicion(indice);
		return array[buscado].getContenido();
	}
	
	/**
	 * Comprueba si la memoria est� vacia.
	 * @return true si la memoria est� vacia.
	 */
	
	private boolean esVacia() {
		return contador == 0;
	}
	
	/**
	 * Inserta en memoria la cima de la pila en la posici�n corresponidente.
	 * @param pos Posici�n en la que vamos a a�adir la celda con el contenido de la cima de la pila.
	 * @param contenido Contenido de la celda.
	 */
	
	public void insertar(int pos, int contenido){
		
		int buscado = buscarPosicion(pos);
		celda dato = new celda(pos, contenido);
        
        if(esVacia()){
			array[contador] = dato;
			contador++;
		}
		else {
			if(array[buscado].getPosicion() == pos)
				array[buscado] = dato;
			else {
				int i = 0;
				while((i < contador) && (dato.getPosicion() > array[i].getPosicion()))
					i++;
				
				for(int j = contador; j > i; j-- )
					array[j] = array[j-1];
				
				array[i] = dato;
				contador++;
			}
		}	
    }
 
	/**
	 * Muestra la memoria. 
	 */
	
	public String toString() {
		String cadena = "Memoria: ";
		
		if(esVacia())
			cadena = cadena + "<vacia>";
		else {
			for(celda cell: this.array) {
				if(cell != null)
					cadena += cell.toString() + " ";
			}
		}
		
		return cadena;
	}



	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
