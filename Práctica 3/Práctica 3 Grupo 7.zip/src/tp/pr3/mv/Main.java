package tp.pr3.mv;

import java.io.*;

import org.apache.commons.cli.*;

import tp.pr3.mv.StrategyIn.ConsoleIn;
import tp.pr3.mv.StrategyIn.FileIn;
import tp.pr3.mv.StrategyIn.NullIn;
import tp.pr3.mv.StrategyIn.StrategyIn;
import tp.pr3.mv.StrategyOut.ConsoleOut;
import tp.pr3.mv.StrategyOut.FileOut;
import tp.pr3.mv.StrategyOut.NullOut;
import tp.pr3.mv.StrategyOut.StrategyOut;
import tp.pr3.mv.command.CommandInterpreter;
import tp.pr3.mv.command.CommandParser;
import tp.pr3.mv.command.RUN;
import tp.pr3.mv.cpu.CPU;
import tp.pr3.mv.cpu.ProgramMV;
import tp.pr3.mv.ins.Instruction;
import tp.pr3.mv.ins.InstructionParser;

/**
 * @author Grupo 7
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args){
		// TODO Auto-generated method stub
		

		ProgramMV programa = new ProgramMV();
		
		String cadena;
		Instruction ins;
		
		@SuppressWarnings("resource")
		java.util.Scanner sc = new java.util.Scanner(System.in);
		
		
		String inputFile = null;
		String outputFile = null;
		String asmFile = null;
		File input = null;
		File output = null;
		File fichero_asm;
		StrategyIn in = null;
		StrategyOut out = null;
		ASM ensamblador;
		String mode = "";
		
		Options options = new Options();
		options.addOption("h","help", false, "Muestra esta ayuda.");
		options.addOption("i","in", true, "Entrada del programa de la maquina.");
		options.addOption("o","out", true, "Fichero donde se guarda la salida del programa de la maquina.");
		options.addOption("a","asm", true, "Fichero con el codigo en ASM del programa a ejecutar. Obligatorio en modo batch.");
		options.addOption("m","mode", true, "Modo de funcionamiento (batch | interactive). Por defecto, batch.");
		
		
		CommandLineParser cli = new BasicParser();
		CommandLine cmd = null;
		
		try {
		    cmd = cli.parse( options, args);
		
		if(cmd.hasOption("h")) {
			new HelpFormatter().printHelp(" tp.pr3.mv.Main [-a <asmfile>] [-h] [-i <infile>] [-m <mode>] [-o <outfile>] ", options ); 
		} else {
			if(cmd.hasOption("m")) {
				if(cmd.getOptionValue("m").equalsIgnoreCase("interactive")) {
					mode = "interactive";
				} else if(cmd.getOptionValue("m").equalsIgnoreCase("batch")) {
					mode = "batch";
				} else {
					mode = cmd.getOptionValue("m");
					throw new ParseException("Modo incorrecto (parametro -m|--mode)");
				}
			} else {
				mode = "batch";
			}

			if(mode == "interactive") {
				
				if(cmd.hasOption("i")) {
					inputFile = cmd.getOptionValue("i");	
					input = new File(inputFile);
					if(input.exists()) {
						in = new FileIn(inputFile);
						in.open();
					} else{
						throw new ParseException("Error al acceder al fichero de entrada (" + inputFile + ")");
					}
				} else {
					in = new NullIn();
				}
				
				if(cmd.hasOption("o")) {
					outputFile = cmd.getOptionValue("o");
					output = new File(outputFile);
					if(output.exists()) {
						out = new FileOut(outputFile);
					}else{
						output.createNewFile();
						out = new FileOut(outputFile);
					}
					
					try {
						out.open();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {
					out = new NullOut();	
				}
				
				if(cmd.hasOption("a")) {
					fichero_asm = new File(cmd.getOptionValue("a"));
					asmFile = cmd.getOptionValue("a");
					if(fichero_asm.exists()) {
						ensamblador = new ASM(asmFile);
						ensamblador.leer(programa);
					} else {
						throw new ParseException("Error al acceder al fichero ASM (" + asmFile + ")");
					}
				} else {
					System.out.println("Introduce el programa fuente");
					do {
						System.out.print("> ");
						cadena = sc.nextLine();
						if(cadena.compareToIgnoreCase("end") != 0) {
							ins = InstructionParser.parse(cadena);
							if(ins == null) {
								System.err.println("Error: Instrucci�n incorrecta.");
							} else
								programa.addInstruction(ins);
						}
					}while(cadena.compareToIgnoreCase("end") != 0);	
				}
			} else if(mode == "batch") {
				
				if(cmd.hasOption("i")) {
					inputFile = cmd.getOptionValue("i");	
					input = new File(inputFile);
					if(input.exists()) {
						in = new FileIn(inputFile);
						in.open();
					} else{
						throw new ParseException("Error al acceder al fichero de entrada (" + inputFile + ")");
					}
				} else {
					in = new ConsoleIn();
				}
				
				if(cmd.hasOption("o")) {
					outputFile = cmd.getOptionValue("o");
					output = new File(outputFile);
					if(output.exists()) {
						out = new FileOut(outputFile);
					}else{
						output.createNewFile();
						out = new FileOut(outputFile);
					}
					
					try {
						out.open();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {
					out = new ConsoleOut();	
				}
				
				if(cmd.hasOption("a")) {
					fichero_asm = new File(cmd.getOptionValue("a"));
					asmFile = cmd.getOptionValue("a");
					if(fichero_asm.exists()) {
						ensamblador = new ASM(asmFile);
						ensamblador.leer(programa);
					} else {
						throw new ParseException("Error al acceder al fichero ASM (" + asmFile + ")");
					}
				} else {
					throw new ParseException("Fichero ASM no especificado.");
				}
			}
			
			CPU computadora = new CPU(in, out);
			
			computadora.loadProgram(programa);
			System.out.println(programa + System.lineSeparator());
			CommandInterpreter.configureCommandInterpreter(computadora);
			
			if(mode == "interactive") {
				do {
					System.out.print(">");
					cadena = sc.nextLine();
					CommandInterpreter comando = CommandParser.parseCommand(cadena);	
					if(!CommandInterpreter.isQuit()) {
						if(comando == null) {
							System.out.println("No lo entiendo");
						}
						else {
							comando.executeCommand();
						}
					}	
				}while(!CommandInterpreter.isQuit());	
			} else if(mode  == "batch") {
				CommandInterpreter command = new RUN();
				command.executeCommand();
			}
			
			out.close();
			in.close();
		}
	} catch (ParseException e) {
		System.err.println("Uso incorrecto: " + e.getMessage() + " Use -h|--help para m�s detalles.");
		System.exit(1);
	} catch (IOException e) {
		System.err.println(e.getMessage());
		System.exit(2);	
	}
	
	}
}
