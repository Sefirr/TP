package tp.pr3.mv.command;

import tp.pr3.mv.ins.Instruction;
import tp.pr3.mv.ins.InstructionParser;

public class DEBUG extends CommandInterpreter {
	
	private Instruction ins;
	
	public DEBUG() {
		super();
	}
	
	public DEBUG(Instruction i) {
		super();
		ins = i;
	}

	@Override
	public void executeCommand() {
		// TODO Auto-generated method stub	
		CommandInterpreter.computadora.step(ins);
	}
	
	@Override
	public CommandInterpreter parseComm(String cadena) {
		String[] tok = cadena.split(" ");
		
		CommandInterpreter command = null;
		
		if((tok[0].equalsIgnoreCase("PUSH")) || (tok[0].equalsIgnoreCase("POP") || (tok[0].equalsIgnoreCase("WRITE")))) {
			ins = InstructionParser.parseDEBUG(cadena);
			command = new DEBUG(ins);
		}
		
		return command;
		
	}

	@Override
	protected CommandInterpreter Command() {
		// TODO Auto-generated method stub
		return new DEBUG(ins);
	}

	@Override
	protected CommandInterpreter Command(int n) {
		// TODO Auto-generated method stub
		return null;
	}

	

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "DEBUG";
	}

}
