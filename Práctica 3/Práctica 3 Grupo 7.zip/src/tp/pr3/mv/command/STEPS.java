package tp.pr3.mv.command;

/**
 * Clase derivada de STEPS que representa el comando STEPS.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class STEPS extends STEP {
	
	protected int parametro;
	
	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * STEP.
	 */
	public STEPS() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo constructor que inicializa el atributo par�metro de STEP.
	 * @param parametro Es el par�metro del comando STEP n.
	 */
	public STEPS(int parametro) {
		super();
		this.parametro = parametro;
	}
	
	/**
	 * M�todo de CommanInterpreter que se sobreescribe aqui correspondiente a la
	 * ejecuci�n del comando STEPS.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public void executeCommand() {
		
		int cont = 0;
		boolean correcto = false;
		
		do  {
			if(parametro > 0) {
				correcto = computadora.step();
				cont++;
			} else {
				System.out.println("No lo entiendo");
			}
		}while(cont < parametro && correcto && !CommandInterpreter.isQuit());
	
	}
	
	/**
	 * M�todo de CommanInterpreter que se sobreescribe aqui correspondiente al
	 * toString de STEPS.
	 * @return Devuelve la cadena correspondiente al comando STEPS.
	 */
	@Override
	public String toString() {
		return "STEP";
	}
	
	@Override
	protected CommandInterpreter Command(int n) {
		// TODO Auto-generated method stub
		return new STEPS(n);
	}
	
}
