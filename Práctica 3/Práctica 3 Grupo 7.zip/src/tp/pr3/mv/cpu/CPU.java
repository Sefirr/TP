/**
 * 
 */
package tp.pr3.mv.cpu;

import tp.pr3.mv.ExecutionManager;
import tp.pr3.mv.Memory;
import tp.pr3.mv.OperandStack;
import tp.pr3.mv.StrategyIn.StrategyIn;
import tp.pr3.mv.StrategyOut.StrategyOut;
import tp.pr3.mv.command.CommandInterpreter;
import tp.pr3.mv.ins.Instruction;

/**
 * Una clase CPU para representar la CPU de m�quina virtual.
 * Cada CPU contiene una memoria,una pila, un gestor de ejecuci�n y
 * un programa, es decir, el lugar donde se realizan las operaciones.
 * @version 2.0, 07/01/2014
 * @author Grupo_7
 *
 */
public class CPU {
	
	private Memory memoria; //Memoria de la CPU
	private OperandStack pila; //Memoria de la pila
	private ExecutionManager gestor; // Gestor de ejecuci�n del programa
	private ProgramMV programa; // Programa de la m�quina virtual
	private StrategyIn in_file;
	private StrategyOut out_file;

	/**
	 * M�todo constructor que inicializa los atributos del objeto de tipo CPU
	 * sin par�metros.
	 */
	public CPU(StrategyIn entrada, StrategyOut salida) {
		this.memoria = new Memory();
		this.pila = new OperandStack();
		this.gestor = new ExecutionManager();
		this.programa = new ProgramMV();
		this.in_file = entrada;
		this.out_file = salida;
	}

	/**
	 * M�todo que carga el programa en la CPU.
	 * @param maker Es el programa que se va a cargar en la CPU.
	 */
	public void loadProgram(ProgramMV maker) {	
		this.programa = maker;
	}
	
	public boolean isHalted() {
		return (gestor.getCurrentPc() > programa.size()) || (gestor.isHalted() == true);
	}
	
	/**
	 * M�todo que ejecuta las diferentes instrucciones.
	 * @return Si la instrucci�n es correcta devuelve true. En caso contrario, false.
	 */
	public boolean step() {
		
		boolean correcto = false;
		
		try {
			
			Instruction ins = programa.getInstruction(gestor.getCurrentPc());
			
			
			System.out.println("Comienza la ejecuci�n de " + ins.name());
			
			ins.execute(memoria, pila, gestor,in_file, out_file);
				
			correcto = true;
			
			System.out.print(toString());
			
			gestor.incrementPc();
			
			if (isHalted())
				CommandInterpreter.PararEjecucion();
		} catch (Exception e) {
			System.err.println(e);
		}
		
		return correcto;
	}
	
	public boolean step(Instruction i) {
		boolean correcto = false;
		
		try {
			i.execute(memoria, pila, gestor, in_file, out_file);
			
			correcto = true;
		} catch(Exception e) {
			System.err.println(e);
		}
		
		return correcto;
	}
	
	/**
	 * Muestra el estado de la CPU.
	 */
	public String toString() {
		return "El estado de la m�quina tras ejecutar la instrucci�n es: " + 
	System.lineSeparator() + memoria + System.lineSeparator() + pila + System.lineSeparator();
	}

}
