/**
 * 
 */
package tp.pr3.mv.cpu;

import tp.pr3.mv.ins.Instruction;


/**
 * Clase que representa un programa. Contiene un atributo array que es el array de
 * instruciones y atributo contador.
 * @author usuario_local
 *
 */
public class ProgramMV {
	
	private Instruction[] array; // Array de instrucciones
	private int contador; // Contador del programa
	
	/**
	 * M�todo constructor sin par�metros que inicializa los atributos del objeto ProgramMV.
	 */
	public ProgramMV() {
		array = new Instruction[100];
		contador = 0;
	}
	
	/**
	 * Procedimiento encargado de a�adir instrucciones. Con cada instrucci�n que
	 * se a�ade, se incrementa el contador.
	 * @param ins Es la instrucci�n que se va a a�adir al programa.
	 */
	public void addInstruction(Instruction ins) {
		array[contador] = ins;
		contador++;
	}
	
	/**
	 * M�todo accedente que devuelve el array de instrucciones.
	 * @return Devuelve el array de instrucciones del programa.
	 */
	public Instruction getInstruction(int parametro) {
		return array[parametro];
	}
	
	/**
	 * M�todo accedente que devuelve el n�mero de instrucciones del programa.	
	 * @return Devuelve el valor del atributo contador.
	 */
	public int size() {
		return contador - 1;
	}

	/**
	 * Muestra la informaci�n correspondiente al programa, es decir, el conjunto 
	 * de instrucciones del programa.
	 */
	@Override
	public String toString() {
		
		String cadena = "El programa introducido es: ";
		int contador = 0;
		for(Instruction ins: array) {
			if(ins != null) {
				cadena += System.lineSeparator() + contador + ": " + ins.name();
				contador++;
			}
		}
		
		return cadena;
	}
	
}