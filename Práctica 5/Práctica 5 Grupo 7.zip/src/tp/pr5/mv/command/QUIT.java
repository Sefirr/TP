package tp.pr5.mv.command;

/**
 * Clase derivada de CommanInterpreter que representa el comando QUIT.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class QUIT extends CommandInterpreter {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * CommanInterpreter.
	 */
	public QUIT() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo de CommandInterpreter que se sobreescribe aqui correspondiente a la
	 * ejecuci�n del comando QUIT.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public void executeCommand() {
		terminado = true;
	}
	
	/**
	 * M�todo de CommandInterpreter que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada QUIT.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected CommandInterpreter Command() {
		// TODO Auto-generated method stub
		return new QUIT();
	}
	
	/**
	 * M�todo de CommandInterpreter que se sobreescribe aqui correspondiente al
	 * toString de QUIT
	 * @return Devuelve la cadena correspondiente al comando QUIT.
	 */
	@Override
	public String toString() {
		return "QUIT";
	}

	@Override
	protected CommandInterpreter Command(int n) {
		// TODO Auto-generated method stub
		return null;
	}

}
