package tp.pr5.mv.command;

import tp.pr5.mv.cpu.CPU;

/**
 * Clase abstracta que representa los distintos comandos que podemos 
 * ejecutar sobre la m�quina virtual.
 * @version 1.0, 17/11/2013
 * @author Grupo_7
 *
 */

public abstract class CommandInterpreter {
	
	protected static CPU computadora; // CPU de los comandos.
	protected static boolean terminado; // Atributo que indica si la CPU est� parada.
	protected static int delay;
	
	/**
	 * M�todo est�tico que para la ejecuci�n de la CPU.
	 */
	public static void stopExecution() {
		terminado = true;
	}
	
	/** 
	 * M�todo est�tico que configura la CPU para poder ejecutar las instrucciones
	 * mediante el gestor de ejecuci�n.
	 * @param maquina El valor de la CPU.
	 */
	public static void configureCommandInterpreter(CPU maquina){
		computadora = maquina;
	}
	
	/**
	 * M�todo est�tico que configura el retardo por cada instrucci�n a la hora de ejecutar una hebra de RUN en Swing.
	 * @param delay Retardo por cada instrucci�n.
	 */
	public static void setDelay(int retardo) {
		delay = retardo;
	}
	
	/**
	 * M�todo que parsea los distintos comandos en funci�n de la
	 * cadena que recibe.
	 * @param cadena Es la cadena que el usuario introduce.
	 * @return Devuelve un objeto de la clase derivada de CommandInterpreter.
	 */
	public CommandInterpreter parseComm(String cadena) {
		String [] tok = cadena.split(" ",2);
		if(tok.length == 2) {
			if (tok[0].equalsIgnoreCase(this.toString())){
				return Command(Integer.parseInt(tok[1]));	
			}
			else return null;
		}
		else if (tok.length == 1) {
			if (tok[0].equalsIgnoreCase(this.toString())){
				return Command();
			}
			else return null;
		}
		else return null;
	}
	
	/**
	 * M�todo que comprueba si la CPU ha parado.
	 * @return True si la CPU est� parada y false en caso contrario.
	 */
	public static boolean isQuit() {
		return (terminado == true);
	}
	
	//M�todos abstractos
	public abstract void executeCommand();
	protected abstract CommandInterpreter Command();
	protected abstract CommandInterpreter Command(int n);
	public abstract String toString();

}