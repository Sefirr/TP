package tp.pr5.mv.command;

import java.io.IOException;

import tp.pr5.mv.Excepciones.ArithmeticException;
import tp.pr5.mv.Excepciones.MemoryException;
import tp.pr5.mv.Excepciones.StackException;


/**
 * Clase derivada de CommanInterpreter que representa el comando RUN.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class RUN extends STEP {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * CommanInterpreter.
	 */
	public RUN() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo de CommanInterpreter que se sobreescribe aqui correspondiente a la
	 * ejecuci�n del comando RUN.
	 * @return Devuelve si el comando es correcto o no.
	 * @throws Exception 
	 */
	@Override
	public void executeCommand(){
		try {
			do {
				computadora.step();
				Thread.sleep(delay);
			} while(!CommandInterpreter.isQuit());
		} catch (StackException | MemoryException | ArithmeticException | IOException | InterruptedException e) {
			
		}	 
		
	}
	
	/**
	 * M�todo de CommanInterpreter que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada RUN.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected CommandInterpreter Command() {
		// TODO Auto-generated method stub
		return new RUN();
	}
	
	/**
	 * M�todo de CommanInterpreter que se sobreescribe aqui correspondiente al
	 * toString de RUN.
	 * @return Devuelve la cadena correspondiente al comando RUN.
	 */
	@Override
	public String toString() {
		return "RUN";
	}

}
