package tp.pr5.mv.Observadores;

public interface StrategyObserver {
	public void updateInMessage(String msg);
	public void updateOutMessage(String msg);

}
