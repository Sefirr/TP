package tp.pr5.mv.Observadores;

public interface StackObserver {
	public void onPush(int value);
	public void onPop();
	public void stackModify();
}
