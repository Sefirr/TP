package tp.pr5.mv.Observadores;

import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.cpu.ProgramMV;
import tp.pr5.mv.ins.Instruction;

public interface CPUObserver {
	public void onStartInstrExecution(Instruction instr);
	public void onEndInstrExecution(int pc, OperandStack pila, Memory memoria);
	public void updateProgram(ProgramMV programa, int pc);
	public void onStartRun();
	public void onEndRun();
	public void onError(String msg);
	public void onHalt();
}
