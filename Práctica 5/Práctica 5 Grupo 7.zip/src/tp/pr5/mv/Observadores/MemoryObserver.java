package tp.pr5.mv.Observadores;

public interface MemoryObserver {
	public void onWrite(int index, int value);
	public void memoryModify();
}
