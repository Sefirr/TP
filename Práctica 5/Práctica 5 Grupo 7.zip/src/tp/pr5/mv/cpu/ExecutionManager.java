package tp.pr5.mv.cpu;

/**
 * Una clase  ExecutionManager para representar un gestor de ejecuci�n.
 * Cada gestor contiene un atributo currentPc que indica la direcci�n de la
 * instrucci�n actual, un atributo nextPc que indica  la direcci�n de la 
 * siguiente instrucci�n y un atributo halt que indica si la cpu ha parado o no.
 * @version 1.0, 17/11/2013
 * @author Grupo_7
 */

public class ExecutionManager {
	
	private int currentPc;
	private int nextPc;
	private boolean halt;
	
	
	/**
	 * M�todo constructor que inicializa los objetos de tipo ExecutionManager
	 * sin parametros.
	 */
	public ExecutionManager() {
		this.currentPc = 0;
		this.nextPc = 0;
		this.halt = false;
	}
	
	/**
	 * Procedimiento que actualiza el PC en funci�n de la instrucci�n que sea
	 * y si es correcta o no.
	 * @param ins Es la instrucci�n que se est� ejecutando actualmente.
	 */
	public void incrementPc() {
		setCurrentPc(nextPc);	
	}

	/**
	 * M�todo accedente que nos devuelve la direcci�n de la instrucci�n que se est� 
	 * ejecutando.
	 * @return  Devuelve el valor del atributo currentPc.
	 */
	public int getCurrentPc() {
		return currentPc;
	}
	
	/**
	 * M�todo mutador que modifca el currentPc.
	 * @param nextPx Es la direcci�n de la siguiente instrucci�n en el programa.
	 */
	public void setCurrentPc(int nextPx) {
		this.currentPc = nextPc;
	}

	/**
	 * M�todo accedente que nos devuelve la direcci�n de la siguiente instrucci�n a 
	 * ejecutar.
	 * @return Devuelve el valor del atributo nextPc.
	 */
	public int getNextPc() {
		return nextPc;
	}

	/**
	 * M�todo mutador que modifica el valor del atributo nextPc.
	 * @param nextPc Es la direcci�n de la siguiente instrucci�n a ejecutar.
	 * en el programa.
	 */
	public void setNextPc(int nextPc) {
		this.nextPc = nextPc;
	}
	
	/**
	 * M�todo que comprueba si la CPU est� parada.
	 * @return Si la CPU est� parada devuelve true, sino false.
	 */
	public boolean isHalted() {
		return (halt == true);
	}
	
}
