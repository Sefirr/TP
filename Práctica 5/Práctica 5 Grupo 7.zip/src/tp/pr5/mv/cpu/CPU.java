/**
 * 
 */

package tp.pr5.mv.cpu;

import java.io.IOException;
import java.util.ArrayList;

import tp.pr5.mv.Excepciones.ArithmeticException;
import tp.pr5.mv.Excepciones.MemoryException;
import tp.pr5.mv.Excepciones.StackException;
import tp.pr5.mv.Observadores.CPUObserver;
import tp.pr5.mv.Observadores.MemoryObserver;
import tp.pr5.mv.Observadores.StackObserver;
import tp.pr5.mv.Observadores.StrategyObserver;
import tp.pr5.mv.StrategyIn.StrategyIn;
import tp.pr5.mv.StrategyIn.WindowIn;
import tp.pr5.mv.StrategyOut.StrategyOut;
import tp.pr5.mv.StrategyOut.WindowOut;
import tp.pr5.mv.command.CommandInterpreter;
import tp.pr5.mv.command.RUN;
import tp.pr5.mv.ins.Instruction;

/**
 * Una clase CPU para representar la CPU de m�quina virtual.
 * Cada CPU contiene una memoria,una pila, un gestor de ejecuci�n y
 * un programa, es decir, el lugar donde se realizan las operaciones.
 * @version 2.0, 07/01/2014
 * @author Grupo_7
 *
 */
public class CPU {
	
	private Memory memoria; //Memoria de la CPU
	private OperandStack pila; //Memoria de la pila
	private ExecutionManager gestor; // Gestor de ejecuci�n del programa
	private ProgramMV programa; // Programa de la m�quina virtual
	private StrategyIn in;
	private StrategyOut out;
	private ArrayList<CPUObserver> observers;

	/**
	 * M�todo constructor que inicializa los atributos del objeto de tipo CPU
	 * sin par�metros.
	 */
	public CPU() {
		this.memoria = new Memory();
		this.pila = new OperandStack();
		this.gestor = new ExecutionManager();
		this.programa = new ProgramMV();
		this.observers = new ArrayList<CPUObserver>();
		this.in = null;
		this.out = null;
	}
	
	public CPU(StrategyIn in, StrategyOut out) {
		this.memoria = new Memory();
		this.pila = new OperandStack();
		this.gestor = new ExecutionManager();
		this.programa = new ProgramMV();
		this.observers = new ArrayList<CPUObserver>();
		this.in = in;
		this.out = out;
	}

	/**
	 * M�todo que carga el programa en la CPU.
	 * @param maker Es el programa que se va a cargar en la CPU.
	 */
	public void loadProgram(ProgramMV maker) {	
		this.programa = maker;
		for(CPUObserver o: observers) {
			o.updateProgram(maker, 0);
		}
	}
	
	public boolean isHalted() {
		return (gestor.getCurrentPc() > programa.size() - 1) || (gestor.isHalted() == true);
	}
	
	public void StreamClose() {
		in.close();
		out.close();
	}
	
	/**
	 * M�todo que ejecuta las diferentes instrucciones.
	 * @throws StackException, MemoryException, ArithmeticException, IOException 
	 */
	public void step() throws StackException, MemoryException, ArithmeticException, IOException{
		
		Instruction ins = programa.getInstruction(gestor.getCurrentPc());
		for(CPUObserver obs: observers) {
			obs.onStartInstrExecution(ins);
		}
		try {
			ins.execute(memoria, pila, gestor,in, out);
			gestor.incrementPc();
			if(isHalted())
				CommandInterpreter.stopExecution();
		} catch (StackException | MemoryException | ArithmeticException | IOException e) {
			for(CPUObserver obs: observers){
				obs.onError(e.toString());
			}
			throw e;
		}
		for(CPUObserver o: observers) {
			o.onEndInstrExecution(gestor.getCurrentPc(), pila, memoria);
			o.updateProgram(programa, gestor.getCurrentPc());
			if(CommandInterpreter.isQuit()) {
				o.onHalt();
			}
		}
	}
	
	/**
	 * M�todo auxiliar que ejecuta las diferentes instrucciones del comando DEBUG.
	 * @throws StackException, MemoryException, ArithmeticException, IOException 
	 */
	public void step(Instruction i) throws StackException, MemoryException, ArithmeticException, IOException{
		
		try {
			i.execute(memoria, pila, gestor, in, out);
		} catch (StackException | MemoryException | ArithmeticException | IOException e) {
			// TODO Auto-generated catch block
			for(CPUObserver obs: observers){
				obs.onError(e.toString());
			}
			throw e;
		} 
		
	}
	
	/**
	 * M�todo que ejecuta todas las instrucciones de un programa, 
	 * notificando a los observadores cuando comienza y acaba el RUN. 
	 */
	public void run() {
		for(CPUObserver obs: observers){
			obs.onStartRun();
		}
		CommandInterpreter command = new RUN();
		command.executeCommand();
		for(CPUObserver obs: observers){
			obs.onEndRun();
		}
	}

	public void addCPUObserver(CPUObserver o) {
		// TODO Auto-generated method stub
		observers.add(o);
	}

	public void removeCPUObserver(CPUObserver o) {
		// TODO Auto-generated method stub
		observers.remove(o);
	}
	
	public void addStackObserver(StackObserver o) {
		// TODO Auto-generated method stub
		pila.addObserver(o);
	}

	public void removeStackObserver(StackObserver o) {
		// TODO Auto-generated method stub
		pila.removeObserver(o);
	}
	public void addMemoryObserver(MemoryObserver o) {
		// TODO Auto-generated method stub
		memoria.addObserver(o);
	}

	public void removeMemoryObserver(MemoryObserver o) {
		// TODO Auto-generated method stub
		memoria.removeObserver(o);
	}
	
	public void addStrategyInObserver(StrategyObserver o) {
		// TODO Auto-generated method stub
		((WindowIn) in).addObserver(o);
	}

	public void removeStrategyInObserver(StrategyObserver o) {
		// TODO Auto-generated method stub
		((WindowIn) in).removeObserver(o);
	}
	
	public void addStrategyOutObserver(StrategyObserver o) {
		// TODO Auto-generated method stub
		((WindowOut) out).addObserver(o);
	}

	public void removeStrategyOutObserver(StrategyObserver o) {
		// TODO Auto-generated method stub
		((WindowOut) out).removeObserver(o);
	}
	
	/**
	 * Muestra el estado de la CPU.
	 */
	public String toString() {
		return "El estado de la m�quina tras ejecutar la instrucci�n es: " + 
	System.lineSeparator() + memoria + System.lineSeparator() + pila + System.lineSeparator();
	}

}
