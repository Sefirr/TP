/**
 * 
 */
package tp.pr5.mv.cpu;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;

import tp.pr5.mv.ins.Instruction;
import tp.pr5.mv.ins.InstructionParser;


/**
 * Clase que representa un programa. Contiene un atributo array que es el array de
 * instruciones y atributo contador.
 * @author usuario_local
 *
 */
public class ProgramMV {
	private Vector<Instruction> array;
	
	/**
	 * M�todo constructor sin par�metros que inicializa los atributos del objeto ProgramMV.
	 */
	public ProgramMV() {
		array = new Vector<Instruction>();
	}
	
	/**
	 * Procedimiento encargado de a�adir instrucciones. Con cada instrucci�n que
	 * se a�ade, se incrementa el contador.
	 * @param ins Es la instrucci�n que se va a a�adir al programa.
	 */
	public void addInstruction(Instruction ins) {
		array.add(ins);
	}
	
	/**
	 * M�todo accedente que devuelve la instrucci�n  que tiene el indice indicado por el par�metro.
	 * @return Devuelve la instrucci�n que tiene el indice del par�metro.
	 */
	public Instruction getInstruction(int parametro) {
		return array.get(parametro);
	}
	
	/**
	 * M�todo accedente que devuelve la �ltima posici�n ocupada en el array.	
	 * @return Devuelve el n� de instrucciones del programa.
	 */
	public int size() {
		return array.size();
	}
	
	public static ProgramMV read_program() {
		
		Instruction ins = null;
		ProgramMV programa = new ProgramMV();
		@SuppressWarnings("resource")
		java.util.Scanner sc = new java.util.Scanner(System.in);
		String cadena = "";
		
		do {
			System.out.print("> ");
			cadena = sc.nextLine();
			if(cadena.compareToIgnoreCase("end") != 0) {
				ins = InstructionParser.parseInteractive(cadena);
				if(ins != null) {
					programa.addInstruction(ins);
				}
			}
		}while(cadena.compareToIgnoreCase("end") != 0);
		
		return programa;		
	}
	
	public static ProgramMV read_program(String programFileName) throws IOException {
		FileReader archivo;
		Instruction ins = null;
		ProgramMV programa = new ProgramMV();
		
		try {
			archivo = new FileReader(programFileName);
			@SuppressWarnings("resource")
			BufferedReader entrada  = new BufferedReader(archivo);
			String cadena = "";
			String instruccion = "";
		
		
			do {
				cadena = entrada.readLine();
				for(int i = 0; i < cadena.length(); i++) {
					if(cadena.charAt(i) != ';') {
						instruccion += cadena.charAt(i);
					} else {
						i = cadena.length();
					}
				}
				if(instruccion.isEmpty() == false) {
					ins = InstructionParser.parseBatch(instruccion);
					instruccion = "";
				if(ins == null) {
					throw new IOException("Error en el programa. L�nea: " + cadena);
				} else 
					programa.addInstruction(ins);
				}
			 } while(entrada.ready());
				entrada.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw e;
		}
		return programa;	
	}

	/**
	 * Muestra la informaci�n correspondiente al programa, es decir, el conjunto 
	 * de instrucciones del programa.
	 */
	@Override
	public String toString() {
		
		String cadena = "El programa introducido es: ";
		int contador = 0;
		for(Instruction ins: array) {
			if(ins != null) {
				cadena += System.lineSeparator() + contador + ": " + ins.name() + "      ";
				contador++;
			}
		}
		
		return cadena;
	}
	
}