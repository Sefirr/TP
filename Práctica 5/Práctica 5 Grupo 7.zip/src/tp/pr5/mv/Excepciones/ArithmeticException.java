package tp.pr5.mv.Excepciones;

@SuppressWarnings("serial")
public class ArithmeticException extends Exception {

	private String _cause;
	
	public ArithmeticException(String cause) {
		super();
		this._cause = cause;
	}
	
	@Override
	public String toString() {
		return _cause;
	}
	
}