package tp.pr5.mv.Excepciones;

@SuppressWarnings("serial")
public class UndefinedInstructionException extends Exception {

	private String _cause;
	
	public UndefinedInstructionException(String cause) {
		super();
		this._cause = cause;
	}
	
	@Override
	public String toString() {
		return _cause;
	}
	
}
