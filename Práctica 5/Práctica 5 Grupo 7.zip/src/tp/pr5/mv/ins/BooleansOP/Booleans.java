package tp.pr5.mv.ins.BooleansOP;

import tp.pr5.mv.ins.Instruction;

/**
 * Clase que implementa la interfaz Instruction para las operaciones Booleanas.
 * @version 2.0
 * @author Grupo_7
 *
 */
public abstract class Booleans implements Instruction {

	/**
	 * M�todo constructor sin par�metros de los objetos de la clase Booleans
	 */
	public Booleans() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo que implementa el m�todo parseIns para las instrucciones Booleanas
	 * @param cadena Es la cadena correspondiente a la instrucci�n.
	 * @return Devuelve un objeto de tipo Instruction.
	 */
	public Instruction parseIns(String cadena){
		String [] tok = cadena.split(" ");
		if (tok.length == 1){
			if (tok[0].equalsIgnoreCase(this.toString())){
				return Instruccion();
			}
			else 
				return null;
		}
		else 
			return null;
	}
	
	//M�todos abstractos
	protected abstract Instruction Instruccion();
	public abstract String toString();
	public abstract String name();
	

}
