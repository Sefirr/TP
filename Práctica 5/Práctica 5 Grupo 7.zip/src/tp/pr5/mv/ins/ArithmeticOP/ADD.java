package tp.pr5.mv.ins.ArithmeticOP;


import tp.pr5.mv.Excepciones.StackException;
import tp.pr5.mv.StrategyIn.StrategyIn;
import tp.pr5.mv.StrategyOut.StrategyOut;
import tp.pr5.mv.cpu.ExecutionManager;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.ins.Instruction;

/**
 * Clase derivada de Arithmetic que representa la instrucci�n ADD.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class ADD extends Arithmetic {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Arithmetic.
	 */
	public ADD() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n ADD.
	 * @return Devuelve si el comando es correcto o no.
	 * @throws StackException 
	 * @throws ArithmeticException 
	 */
	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws StackException {
		int cima, subcima, resultado;	
		
		if(pila.numElems() > 1) {
			cima = pila.getCima();
			pila.desapilar();
			subcima = pila.getCima();
			pila.desapilar();
			
			resultado = subcima + cima;
			pila.apilar(resultado);
			gestor.setNextPc(gestor.getCurrentPc()+1);
		} else {
			throw new StackException("Error ejecutando ADD: faltan operandos en la pila (hay " + pila.numElems() +")");
		}
	}
	
	/**
	 * M�todo de Arithmetic que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada ADD.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion(){
		return new ADD();
	}
	
	/**
	 * M�todo de Arithmetic que se sobreescribe aqui correspondiente al
	 * toString de ADD.
	 * @return Devuelve la cadena correspondiente a la instrucci�n ADD.
	 */
	@Override
	public String toString(){
		return "ADD";
	}
	
	@Override
	public String name(){
		return "ADD";
	}

}
