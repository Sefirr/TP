package tp.pr5.mv.ins.ArithmeticOP;

import tp.pr5.mv.Excepciones.ArithmeticException;
import tp.pr5.mv.Excepciones.StackException;
import tp.pr5.mv.StrategyIn.StrategyIn;
import tp.pr5.mv.StrategyOut.StrategyOut;
import tp.pr5.mv.cpu.ExecutionManager;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.ins.Instruction;

/**
 * Clase derivada de Arithmetic que representa la instrucci�n DIV.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class DIV extends Arithmetic {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Arithmetic.
	 */
	public DIV() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n DIV.
	 * @return Devuelve si el comando es correcto o no.
	 * @throws ArithmeticException 
	 * @throws StackException 
	 */
	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws ArithmeticException, StackException{
		int cima, subcima, resultado;
		
		if(pila.numElems() > 1) {
			cima = pila.getCima();
			if(cima != 0) {
				pila.desapilar();
				subcima = pila.getCima();
				pila.desapilar();
		
				resultado = subcima / cima;
				pila.apilar(resultado);
				gestor.setNextPc(gestor.getCurrentPc()+1);
			}
			else {
				throw new ArithmeticException("Divisi�n por cero");
			}
		} else {
			throw new StackException("Error ejecutando DIV: faltan operandos en la pila (hay " + pila.numElems() +")");
		}
	}
	
	/**
	 * M�todo de Arithmetic que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada DIV.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion(){
		return new DIV();
	}
	
	/**
	 * M�todo de Arithmetic que se sobreescribe aqui correspondiente al
	 * toString de DIV.
	 * @return Devuelve la cadena correspondiente a la instrucci�n DIV.
	 */
	@Override
	public String toString(){
		return "DIV";
	}
	
	@Override
	public String name(){
		return "DIV";
	}

}
