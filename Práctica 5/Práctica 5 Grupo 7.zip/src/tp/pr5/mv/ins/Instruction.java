package tp.pr5.mv.ins;

import java.io.FileNotFoundException;
import java.io.IOException;

import tp.pr5.mv.Excepciones.ArithmeticException;
import tp.pr5.mv.Excepciones.MemoryException;
import tp.pr5.mv.Excepciones.StackException;
import tp.pr5.mv.StrategyIn.StrategyIn;
import tp.pr5.mv.StrategyOut.StrategyOut;
import tp.pr5.mv.cpu.ExecutionManager;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;

/**
 * Interfaz correspondiente a las instrucciones. Los m�todos se sobrescriben en las
 * clases derivadas de las clases que implementan la interfaz para que todo funcione
 * correctamente.
 * @version 2.0
 * @author Grupo_7
 *
 */
public interface Instruction {
	
	// M�todos abstractos
	public abstract void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws MemoryException, StackException, ArithmeticException, FileNotFoundException, IOException;
	public abstract Instruction parseIns(String cadena);
	public abstract String toString();
	public abstract String name();

}
