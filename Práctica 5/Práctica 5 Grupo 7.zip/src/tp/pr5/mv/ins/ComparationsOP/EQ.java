package tp.pr5.mv.ins.ComparationsOP;

import tp.pr5.mv.Excepciones.StackException;
import tp.pr5.mv.StrategyIn.StrategyIn;
import tp.pr5.mv.StrategyOut.StrategyOut;
import tp.pr5.mv.cpu.ExecutionManager;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.ins.Instruction;

/**
 * Clase derivada de Comparations que representa la instrucci�n EQ.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class EQ extends Comparations {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Comparations.
	 */
	public EQ() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n EQ.
	 * @return Devuelve si el comando es correcto o no.
	 * @throws ComparationsException 
	 */
	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws StackException{
		int cima, subcima;
		
		if(pila.numElems() > 1) {
			cima = pila.getCima();
			pila.desapilar();
			subcima = pila.getCima();
			pila.desapilar();
			
			if(subcima == cima) {
				pila.apilar(1);
			}
			else {
				pila.apilar(0);
			}
			
			gestor.setNextPc(gestor.getCurrentPc()+1);
		} else {
			throw new StackException("Error ejecutando EQ: faltan operandos en la pila (hay " + pila.numElems() +")");
		}
	}
	
	/**
	 * M�todo de Comparations que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada EQ.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion(){
		return new EQ();
	}
	
	/**
	 * M�todo de Comparations que se sobreescribe aqui correspondiente al
	 * toString de EQ.
	 * @return Devuelve la cadena correspondiente a la instrucci�n EQ.
	 */
	@Override
	public String toString(){
		return "EQ";
	}
	
	@Override
	public String name(){
		return "EQ";
	}

}
