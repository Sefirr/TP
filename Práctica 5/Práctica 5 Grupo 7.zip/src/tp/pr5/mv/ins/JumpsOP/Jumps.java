package tp.pr5.mv.ins.JumpsOP;

import tp.pr5.mv.Excepciones.UndefinedInstructionException;
import tp.pr5.mv.ins.Instruction;

/**
 * Clase que implementa la interfaz Instruction para las operaciones Booleanas.
 * @version 2.0
 * @author Grupo_7
 *
 */
public abstract class Jumps implements Instruction {

	protected int parametro; // Par�metro de la instrucci�n de salto.
	
	/**
	 * M�todo constructor sin par�metros de los objetos de la clase Jumps
	 */
	public Jumps() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo constructor con un par�metro que inicializa los atributos 
	 *  de los objetos de la clase Jumps
	 */
	public Jumps(Integer parametro) {
		// TODO Auto-generated constructor stub
		super();
		this.parametro = parametro;
	}
	
	private static boolean isNumeric(String cadena){
		try {
			Integer.parseInt(cadena);
			return true;
		} catch (NumberFormatException nfe){
			return false;
		}
	}
	
	/**
	 * M�todo que implementa el m�todo parseIns para las instrucciones de salto
	 * @param cadena Es la cadena correspondiente a la instrucci�n.
	 * @return Devuelve un objeto de tipo Instruction.
	 */
	public Instruction parseIns(String cadena){
		String [] tok = cadena.split(" ");
		try{
			if (tok.length == 2) {
				if (tok[0].equalsIgnoreCase(this.toString())){
					if(isNumeric(tok[1]))
							return Instruccion(Integer.parseInt(tok[1]));
					else{
						throw new UndefinedInstructionException("Error: Par�metros incorrectos de la instruction y/o comando.");
					}
				}
			}
		} catch(UndefinedInstructionException e) {
			System.err.println(e);
		}
		
		return null;
	}
	
	//M�todos abstractos
	protected abstract Instruction Instruccion();
	protected abstract Instruction Instruccion(int parseInt);
	public abstract String toString();
	public abstract String name();

}