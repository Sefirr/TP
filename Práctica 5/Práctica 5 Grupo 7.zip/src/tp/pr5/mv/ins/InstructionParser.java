package tp.pr5.mv.ins;

import tp.pr5.mv.Excepciones.UndefinedInstructionException;
import tp.pr5.mv.ins.ArithmeticOP.ADD;
import tp.pr5.mv.ins.ArithmeticOP.DIV;
import tp.pr5.mv.ins.ArithmeticOP.MUL;
import tp.pr5.mv.ins.ArithmeticOP.SUB;
import tp.pr5.mv.ins.BooleansOP.AND;
import tp.pr5.mv.ins.BooleansOP.NOT;
import tp.pr5.mv.ins.BooleansOP.OR;
import tp.pr5.mv.ins.ComparationsOP.EQ;
import tp.pr5.mv.ins.ComparationsOP.GT;
import tp.pr5.mv.ins.ComparationsOP.LE;
import tp.pr5.mv.ins.ComparationsOP.LT;
import tp.pr5.mv.ins.JumpsOP.BF;
import tp.pr5.mv.ins.JumpsOP.BT;
import tp.pr5.mv.ins.JumpsOP.JUMP;
import tp.pr5.mv.ins.JumpsOP.RBF;
import tp.pr5.mv.ins.JumpsOP.RBT;
import tp.pr5.mv.ins.JumpsOP.RJUMP;
import tp.pr5.mv.ins.OthersOP.DUP;
import tp.pr5.mv.ins.OthersOP.FLIP;
import tp.pr5.mv.ins.OthersOP.HALT;
import tp.pr5.mv.ins.OthersOP.IN;
import tp.pr5.mv.ins.OthersOP.JUMPIND;
import tp.pr5.mv.ins.OthersOP.LOAD;
import tp.pr5.mv.ins.OthersOP.LOADIND;
import tp.pr5.mv.ins.OthersOP.OUT;
import tp.pr5.mv.ins.OthersOP.POP;
import tp.pr5.mv.ins.OthersOP.PUSH;
import tp.pr5.mv.ins.OthersOP.STORE;
import tp.pr5.mv.ins.OthersOP.STOREIND;
import tp.pr5.mv.ins.OthersOP.WRITE;

/**
 * Una clase para parsear la cadena correspondiente a la instrucci�n 
 * que quiere ejecutar el usuario. Cada instrucci�n queda determinada 
 * por su orden y par�metro.
 * @version 1.0, 17/11/2013
 * @author Grupo_7
 */
public class InstructionParser {
	
	private static Instruction[] instrucciones = {
		new ADD(), new SUB(), new MUL(), new DIV(), new AND(), new OR(), new NOT(),
		new OR(), new JUMP(), new BT(), new BF(), new DUP(), new FLIP(), new HALT(),
		new LOAD(), new OUT(), new POP(), new PUSH(), new STORE(), new EQ(), new GT(),
		new LT(), new LE(), new RJUMP(), new RBT(), new RBF(), new IN(), new JUMPIND(), 
		new STOREIND(), new LOADIND(),
	};
	
	private static Instruction[] debug = { new WRITE(), new POP() , new PUSH(), };

	public static boolean comprobar(String cadena) {
		String[] tok = cadena.split(" ");
		
		// TODO Auto-generated method stub
		for(Instruction op : instrucciones) {
			if (tok[0].equalsIgnoreCase(op.toString())){
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * Recorre el conjunto de posibles instrucciones. Si la instancia de la instrucci�n
	 * que se va a ejecutar corresponde con alguno de ellos.
	 * @param s Es la cadena correspondiente a la instrucci�n con el par�metro o no.
	 * @return Devuelve una clase derivada de Instruction.
	 */
	public static Instruction parseInteractive(String cadena) {
		// TODO Auto-generated method stub
		for(Instruction op : instrucciones) {
			Instruction operacion = op.parseIns(cadena);
			if (operacion != null){
				return operacion;
			}
		}
		
		if(comprobar(cadena) == false)
			try {
				throw new UndefinedInstructionException("Error: Instrucci�n incorrecta.");
			} catch (UndefinedInstructionException e) {
				// TODO Auto-generated catch block
				System.err.println(e);
			}
		
		return null;
	}
	
	public static Instruction parseBatch(String cadena) {
		// TODO Auto-generated method stub
		for(Instruction op : instrucciones) {
			Instruction operacion = op.parseIns(cadena);
			if (operacion != null){
				return operacion;
			}
		}
		
		return null;
	}
	
	public static Instruction parseDEBUG(String cadena) {
		// TODO Auto-generated method stub
		for(Instruction op : debug){
			Instruction operacion = op.parseIns(cadena);
			if (operacion != null){
				return operacion;
			}
		}
		return null;
	}

}
