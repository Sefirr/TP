package tp.pr5.mv.ins.OthersOP;

import tp.pr5.mv.StrategyIn.StrategyIn;
import tp.pr5.mv.StrategyOut.StrategyOut;
import tp.pr5.mv.cpu.ExecutionManager;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.ins.Instruction;

/**
 * Clase derivada de Binary que representa la instrucci�n PUSH.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class PUSH extends Binary {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Unary.
	 */
	public PUSH() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * M�todo constructor con par�metros que llama al constructor de
	 * Unary.
	 */
	public PUSH(int parametro) {
		super(parametro);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n PUSH.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) {
		pila.apilar(parametro);
		gestor.setNextPc(gestor.getCurrentPc()+1);
	}

	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente al
	 * toString de PUSH.
	 * @return Devuelve la cadena correspondiente a la instrucci�n PUSH.
	 */
	@Override
	protected Instruction Instruccion(int d) {
		// TODO Auto-generated method stub
		return new PUSH(d);
	}
	
	@Override
	public String toString() {
		return "PUSH";
	}

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "PUSH " + parametro;
	}

}
