package tp.pr5.mv.ins.OthersOP;

import tp.pr5.mv.Excepciones.MemoryException;
import tp.pr5.mv.Excepciones.StackException;
import tp.pr5.mv.StrategyIn.StrategyIn;
import tp.pr5.mv.StrategyOut.StrategyOut;
import tp.pr5.mv.cpu.ExecutionManager;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.ins.Instruction;
/**
 * Clase derivada de Binary que representa la instrucci�n STORE.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class STORE extends Binary {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Binary.
	 */
	public STORE() {
		// TODO Auto-generated constructor stub
		super();
	}

	/**
	 * M�todo constructor con par�metros que llama al constructor de
	 * Binary.
	 */
	public STORE(int parametro) {
		super(parametro);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n STORE.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws StackException, MemoryException {
		int cima;

		if(pila.numElems() > 0) {
			if(parametro >= 0) {
				cima = pila.getCima();
				pila.desapilar();
				memoria.insertar(parametro, cima);
				gestor.setNextPc(gestor.getCurrentPc()+1);
			} else {
				throw new MemoryException("Error ejecutando STORE " + parametro + " direccion incorrecta (" + parametro + ")");
			}
		}
		else {
			throw new StackException("Error ejecutando STORE: faltan operandos en la pila (hay " + pila.numElems() +")");
		}
	}

	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada STORE.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion(int d) {
		// TODO Auto-generated method stub
		return new STORE(d);
	}
	
	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente al
	 * toString de STORE.
	 * @return Devuelve la cadena correspondiente a la instrucci�n STORE.
	 */
	@Override
	public String toString() {
		return "STORE";
	}

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "STORE " + parametro;
	}

}
