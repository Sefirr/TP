package tp.pr5.mv.ins.OthersOP;

import tp.pr5.mv.Excepciones.StackException;
import tp.pr5.mv.StrategyIn.StrategyIn;
import tp.pr5.mv.StrategyOut.StrategyOut;
import tp.pr5.mv.cpu.ExecutionManager;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.ins.Instruction;

/**
 * Clase derivada de Unary que representa la instrucci�n POP.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class POP extends Unary {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Unary.
	 */
	public POP() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n POP.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws StackException {
		
		if(pila.numElems() > 0) {
			pila.desapilar();
			gestor.setNextPc(gestor.getCurrentPc()+1);
		}
		else {
			throw new StackException("Imposible hacer pop");
		}
		
	}

	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada POP.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion() {
		// TODO Auto-generated method stub
		return new POP();
	}
	
	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente al
	 * toString de POP.
	 * @return Devuelve la cadena correspondiente a la instrucci�n POP.
	 */
	@Override
	public String toString() {
		return "POP";
	}
	
	@Override
	public String name(){
		return "POP";
	}

}
