package tp.pr5.mv.ins.OthersOP;

import tp.pr5.mv.Excepciones.StackException;
import tp.pr5.mv.StrategyIn.StrategyIn;
import tp.pr5.mv.StrategyOut.StrategyOut;
import tp.pr5.mv.cpu.ExecutionManager;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.ins.Instruction;

/**
 * Clase derivada de Unary que representa la instrucci�n DUP.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class DUP extends Unary {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Unary.
	 */
	public DUP() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n DUP.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws StackException {
		
		if(pila.numElems() >= 1) {
			int n = pila.getCima();
			pila.apilar(n);
			gestor.setNextPc(gestor.getCurrentPc()+1);
		} else {
			throw new StackException("Error ejecutando DUP: faltan operandos en la pila (hay " + pila.numElems() +")");
		}

	}

	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada DUP.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion() {
		// TODO Auto-generated method stub
		return new DUP();
	}
	
	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente al
	 * toString de DUP.
	 * @return Devuelve la cadena correspondiente a la instrucci�n DUP.
	 */
	@Override
	public String toString() {
		return "DUP";
	}
	
	@Override
	public String name(){
		return "DUP";
	}

}
