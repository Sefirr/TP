package tp.pr5.mv.ins.OthersOP;

import tp.pr5.mv.StrategyIn.StrategyIn;
import tp.pr5.mv.StrategyOut.StrategyOut;
import tp.pr5.mv.command.CommandInterpreter;
import tp.pr5.mv.cpu.ExecutionManager;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.ins.Instruction;

/**
 * Clase derivada de Unary que representa la instrucci�n HALT.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class HALT extends Unary {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Unary.
	 */
	public HALT() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n HALT.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) {
		CommandInterpreter.stopExecution();
	}

	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada HALT.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion() {
		// TODO Auto-generated method stub
		return new HALT();
	}
	
	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente al
	 * toString de HALT.
	 * @return Devuelve la cadena correspondiente a la instrucci�n HALT.
	 */
	@Override
	public String toString() {
		return "HALT";
	}
	
	@Override
	public String name(){
		return "HALT";
	}

}
