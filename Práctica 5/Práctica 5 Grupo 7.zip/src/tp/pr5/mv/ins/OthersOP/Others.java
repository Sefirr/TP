package tp.pr5.mv.ins.OthersOP;

import tp.pr5.mv.ins.Instruction;

/**
 * Clase que implementa la interfaz Instruction para el resto de instrucciones.
 * @version 2.0
 * @author Grupo_7
 *
 */
public abstract class Others implements Instruction {
	
	//M�todos abstractos
	public abstract Instruction parseIns(String cadena);
	public abstract String toString();


}
