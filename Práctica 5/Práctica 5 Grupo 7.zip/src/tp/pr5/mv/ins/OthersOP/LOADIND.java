package tp.pr5.mv.ins.OthersOP;

import tp.pr5.mv.Excepciones.MemoryException;
import tp.pr5.mv.StrategyIn.StrategyIn;
import tp.pr5.mv.StrategyOut.StrategyOut;
import tp.pr5.mv.cpu.ExecutionManager;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.ins.Instruction;

public class LOADIND extends Unary {

	public LOADIND() {
		// TODO Auto-generated constructor stub
	}



	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws MemoryException {
		int cima = pila.getCima();
		if(memoria.numElems() > 0 && memoria.comprobar(cima)) {
			cima = memoria.ObtenerContenido(cima);
			pila.apilar(cima);
			gestor.setNextPc(gestor.getCurrentPc()+1);
		}
		else {
			throw new MemoryException("Error ejecutando LOADIND " + cima + " direccion incorrecta (" + cima + ")");
		}
	}

	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada LOADIND.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion() {
		// TODO Auto-generated method stub
		return new LOADIND();
	}
	
	/**
	 * M�todo de Other que se sobreescribe aqui correspondiente al
	 * toString de LOADIND.
	 * @return Devuelve la cadena correspondiente a la instrucci�n LOADIND.
	 */
	@Override
	public String toString() {
		return "LOADIND";
	}

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "LOADIND";
	}

}
