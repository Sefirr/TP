package tp.pr5.mv.Vistas;



import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import tp.pr5.mv.Controladores.GUIController;
import tp.pr5.mv.Observadores.CPUObserver;
import tp.pr5.mv.Vistas.Window.InputPanel;
import tp.pr5.mv.Vistas.Window.MemoryPanel;
import tp.pr5.mv.Vistas.Window.OutputPanel;
import tp.pr5.mv.Vistas.Window.ProgramPanel;
import tp.pr5.mv.Vistas.Window.StackPanel;
import tp.pr5.mv.Vistas.Window.StatusBarPanel;
import tp.pr5.mv.Vistas.Window.ToolBarPanel;
import tp.pr5.mv.cpu.CPU;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.cpu.ProgramMV;
import tp.pr5.mv.ins.Instruction;


@SuppressWarnings("serial")
public class MainWindow extends JFrame implements CPUObserver {
	
	private GUIController ctrl;
	
	private Container _panelPrincipal;  
	private JPanel _panelCentralInterior;
	private JPanel _panelCentralExterior;
	private JPanel _panelSur;
	private ToolBarPanel toolBar;
	private ProgramPanel programView;
	private StackPanel stackView;
	private MemoryPanel memoryView;
	private InputPanel inputView;
	private OutputPanel outputView;
	private StatusBarPanel statusBar;
	
	public MainWindow(GUIController ctrl, CPU cpu) {
		super("M�quina virtual de TP");
		this.ctrl = ctrl;
		initGUI(cpu);
	}
	
	private void initGUI(CPU cpu) {
		toolBar = new ToolBarPanel(ctrl);
		cpu.addCPUObserver(toolBar);
		programView = new ProgramPanel();
		cpu.addCPUObserver(programView);
		stackView = new StackPanel(ctrl);
		stackView.setLayout(new GridLayout(2,1));
		cpu.addCPUObserver(stackView);
		cpu.addStackObserver(stackView);
		TitledBorder TituloPila = BorderFactory.createTitledBorder("OperandStack");
		stackView.setBorder(TituloPila);
		memoryView = new MemoryPanel(ctrl);
		memoryView.setLayout(new GridLayout(2,1));
		TitledBorder TituloMemoria = BorderFactory.createTitledBorder("Memory");
		memoryView.setBorder(TituloMemoria);
		cpu.addCPUObserver(memoryView);
		cpu.addMemoryObserver(memoryView);
		inputView = new InputPanel();	
		TitledBorder TituloEntrada = new TitledBorder("Entrada del programa-p");
		inputView.setBorder(TituloEntrada);
		cpu.addStrategyInObserver(inputView);
		outputView = new OutputPanel();
		TitledBorder TituloSalida = new TitledBorder("Salida del programa-p");
		outputView.setBorder(TituloSalida);
		cpu.addStrategyOutObserver(outputView);
		statusBar = new StatusBarPanel();
		statusBar.setLayout(new FlowLayout());
		cpu.addCPUObserver(statusBar);
		cpu.addStackObserver(statusBar);
		cpu.addMemoryObserver(statusBar);
		
		//Panel de la ventana
		_panelPrincipal = this.getContentPane();  
		_panelPrincipal.setLayout(new BorderLayout());
		
		//Panel central
		_panelCentralInterior = new JPanel();
		_panelCentralInterior.setLayout(new GridLayout(2,1));
		_panelCentralExterior = new JPanel();	
		_panelCentralExterior.setLayout(new GridLayout(1,2));
		
		//Panel del sur
		_panelSur = new JPanel();
		_panelSur.setLayout(new GridLayout(2,1));
		
		_panelSur.add(inputView);
		_panelSur.add(outputView);
		_panelCentralExterior.add(stackView);
		_panelCentralExterior.add(memoryView);
		_panelCentralInterior.add(_panelCentralExterior);
		_panelCentralInterior.add(_panelSur);
		
		_panelPrincipal.add(toolBar, BorderLayout.NORTH);
		_panelPrincipal.add(_panelCentralInterior, BorderLayout.CENTER);
		_panelPrincipal.add(programView,BorderLayout.WEST);
		_panelPrincipal.add(statusBar, BorderLayout.SOUTH);
		
		this.setLocation(50, 100);
		this.setSize(600,550);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);	
	}

	@Override
	public void onStartInstrExecution(Instruction instr) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onEndInstrExecution(int pc, OperandStack pila, Memory memoria) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStartRun() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onEndRun() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onError(String msg) {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(null, msg, "Error", JOptionPane.ERROR_MESSAGE);
	}

	@Override
	public void onHalt() {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateProgram(ProgramMV programa, int pc) {
		// TODO Auto-generated method stub
		
	}

}
