package tp.pr5.mv.Vistas;

import tp.pr5.mv.Controladores.BatchController;
import tp.pr5.mv.Observadores.CPUObserver;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.cpu.ProgramMV;
import tp.pr5.mv.ins.Instruction;

public class BatchView implements CPUObserver{
	
	public BatchView(BatchController batchCtrl) {
		super();
	}

	@Override
	public void onStartInstrExecution(Instruction instr) {
		// TODO Auto-generated method stub
		System.out.println("Comienza la ejecuci�n de " + instr.name());
	}

	@Override
	public void onEndInstrExecution(int pc, OperandStack pila, Memory memoria) {
		// TODO Auto-generated method stub
		System.out.print("El estado de la m�quina tras ejecutar la instrucci�n es: " + 
		System.lineSeparator() + memoria + System.lineSeparator() + pila + System.lineSeparator());
	}

	@Override
	public void onStartRun() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onEndRun() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onError(String msg) {
		// TODO Auto-generated method stub
		System.err.println(msg);
	}

	@Override
	public void onHalt() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateProgram(ProgramMV programa, int pc) {
		// TODO Auto-generated method stub
		
	}

}
