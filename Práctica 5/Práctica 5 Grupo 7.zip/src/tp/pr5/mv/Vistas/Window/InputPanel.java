package tp.pr5.mv.Vistas.Window;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import tp.pr5.mv.Observadores.StrategyObserver;


@SuppressWarnings("serial")
public class InputPanel extends JPanel implements StrategyObserver {
	
	private JTextArea _Entrada;
	private JScrollPane ScrollEntrada;
	
	public InputPanel(){
		initGUI();	
	}

	private void initGUI() {
		// TODO Auto-generated method stub
		_Entrada = new JTextArea(4,36);
		//_Entrada.append(guiCtrl.mensajeEntrada());
		_Entrada.setLineWrap(true);
		_Entrada.setEditable(false);
		
		ScrollEntrada = new JScrollPane(_Entrada);
		this.add(ScrollEntrada);
	}

	@Override
	public void updateInMessage(final String msg) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				_Entrada.setText("");
				_Entrada.append(msg);
				
			}
			
		});
		
	}

	@Override
	public void updateOutMessage(String msg) {
		// TODO Auto-generated method stub
		
	}

	

}
