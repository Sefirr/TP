package tp.pr5.mv.Vistas.Window;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.TitledBorder;

import tp.pr5.mv.Controladores.GUIController;
import tp.pr5.mv.Observadores.CPUObserver;
import tp.pr5.mv.command.CommandInterpreter;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.cpu.ProgramMV;
import tp.pr5.mv.ins.Instruction;

@SuppressWarnings("serial")
public class ToolBarPanel extends JPanel implements CPUObserver {

	private GUIController guiCtrl;
	private JPanel _panelBotones;
	private JButton _botonSTEP;
	private JButton _botonRUN;
	private JButton _botonPAUSE;
	private JButton _botonQUIT;
	private Thread _currentThread;
	
	
	public ToolBarPanel(GUIController ctrl) {
		this.guiCtrl = ctrl;
		CommandInterpreter.setDelay(200);
		initGUI();
	}
	

	
	private void initGUI() {
		_panelBotones = new JPanel();
		_panelBotones.setLayout(new FlowLayout());
		
		 TitledBorder tituloBotones = BorderFactory.createTitledBorder("Acciones");
		 _panelBotones.setBorder(tituloBotones);
		 
		 ImageIcon STEP = new ImageIcon("src/imagenes/step.png");
		 ImageIcon RUN = new ImageIcon("src/imagenes/run.png");
		 ImageIcon QUIT = new ImageIcon("src/imagenes/exit.png");
		 ImageIcon PAUSE = new ImageIcon("src/imagenes/pause.png");
		
		_botonSTEP = new JButton(STEP);
		
		_botonSTEP.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(!CommandInterpreter.isQuit()) {
					guiCtrl.step();
				} else {
					JOptionPane.showMessageDialog(null, "La ejecuci�n del programa-MV ha terminado. Por favor, cierre la aplicaci�n.", "Aviso", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		
		_botonRUN = new JButton(RUN);
		_botonRUN.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				_currentThread = new Thread(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						if(!CommandInterpreter.isQuit()) {
							guiCtrl.run();	
						} else {
							JOptionPane.showMessageDialog(null, "La ejecuci�n del programa-MV ha terminado. Por favor, cierre la aplicaci�n.", "Aviso", JOptionPane.INFORMATION_MESSAGE);
		
						}
					}
					
				});
				
				_currentThread.start();
			}
		});
		
		_botonPAUSE = new JButton(PAUSE);
		
		_botonPAUSE.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				_currentThread.interrupt();					
			}
		});
		
		_botonQUIT = new JButton(QUIT);
		
		_botonQUIT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource().equals(_botonQUIT)){
					int i = JOptionPane.showConfirmDialog(null,
							"�Realmente desea salir?",
							"Salir ",
							JOptionPane.YES_NO_OPTION,
							JOptionPane.ERROR_MESSAGE);
					if (i == JOptionPane.YES_OPTION){
						guiCtrl.quit();
					}
				}
			}
		});
		
		_panelBotones.add(_botonSTEP);
		_panelBotones.add(_botonRUN);
		_panelBotones.add(_botonPAUSE);
		_panelBotones.add(_botonQUIT);
		this.add(_panelBotones);
		
		
	}
	
	@Override
	public void onStartInstrExecution(Instruction instr) {
		// TODO Auto-generated method stub
	
	}

	@Override
	public void onEndInstrExecution(int pc, OperandStack pila, Memory memoria) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStartRun() {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				_botonRUN.setEnabled(false);
				_botonSTEP.setEnabled(false);
			}
			
		});
	}

	@Override
	public void onEndRun() {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				_botonRUN.setEnabled(true);
				_botonSTEP.setEnabled(true);
			}
			
		});
	}

	@Override
	public void onError(String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onHalt() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void updateProgram(ProgramMV programa, int pc) {
		// TODO Auto-generated method stub
		
	}
	
}
