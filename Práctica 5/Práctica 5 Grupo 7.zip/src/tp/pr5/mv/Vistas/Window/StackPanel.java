package tp.pr5.mv.Vistas.Window;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import tp.pr5.mv.Controladores.GUIController;
import tp.pr5.mv.Excepciones.UndefinedInstructionException;
import tp.pr5.mv.Observadores.CPUObserver;
import tp.pr5.mv.Observadores.StackObserver;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.cpu.ProgramMV;
import tp.pr5.mv.ins.Instruction;

@SuppressWarnings("serial")
public class StackPanel extends JPanel implements CPUObserver, StackObserver {

	private DefaultListModel<Integer> model;
	private JList<Integer> _pila;
	private JPanel _panelComandosPila;
	private GUIController guiCtrl;
	
	private JScrollPane ScrollPila;
	private JLabel _LValor;
	private JTextField _Valor;
	
	private JButton _botonPUSH;
	private JButton _botonPOP;
	
	public StackPanel(GUIController guiCtrl) {
		this.guiCtrl = guiCtrl;
		initGUI();
	}
	
	private void initGUI() {
		model = new DefaultListModel<Integer>();
		_pila = new JList<Integer>(model);
		ScrollPila = new JScrollPane(_pila);
		_LValor = new JLabel("Valor: ");
		_Valor = new JTextField(5);
		
		
		
		_botonPUSH = new JButton("PUSH");
		_botonPUSH.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String cadena = _Valor.getText();
				try {
					if(isNumeric(cadena)) {
						int parametro = Integer.parseInt(cadena);
						guiCtrl.push(parametro);
					} else {
						throw new UndefinedInstructionException("Error: Par�metros incorrectos en el comando.");
					}
				} catch (UndefinedInstructionException e) {
					JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
				}
				_Valor.setText(null);
			}
		});
		
		_botonPOP = new JButton("POP");
		
		_botonPOP.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {	
				guiCtrl.pop();
				_Valor.setText(null);
			}
		});
		
		//Panel de comandos de la pila
		_panelComandosPila = new JPanel();
		_panelComandosPila.setLayout(new FlowLayout());
		
		_panelComandosPila.add(_LValor);
		_panelComandosPila.add(_Valor);
		_panelComandosPila.add(_botonPUSH);
		_panelComandosPila.add(_botonPOP);
		this.add(ScrollPila);
		this.add(_panelComandosPila);
	}
	
	private static boolean isNumeric(String cadena){
		try {
			Integer.parseInt(cadena);
			return true;
		} catch (NumberFormatException nfe){
			return false;
		}
	}
	
	@Override
	public void onPush(int value) {
		// TODO Auto-generated method stub
		model.add(0, value);
		_pila.setModel(model);
	}

	@Override
	public void onPop() {
		// TODO Auto-generated method stub
		model.removeElementAt(0);
		_pila.setModel(model);
	}

	@Override
	public void onStartInstrExecution(Instruction instr) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onEndInstrExecution(int pc, OperandStack pila, Memory memoria) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStartRun() {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				_botonPUSH.setEnabled(false);
				_botonPOP.setEnabled(false);		
			}
		});
		
	}

	@Override
	public void onEndRun() {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				_botonPUSH.setEnabled(true);
				_botonPOP.setEnabled(true);	
			}
		});
		
	}

	@Override
	public void onError(String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onHalt() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void stackModify() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateProgram(ProgramMV programa, int pc) {
		// TODO Auto-generated method stub
		
	}

}
