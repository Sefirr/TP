package tp.pr5.mv.Vistas.Window;

import java.awt.Color;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import tp.pr5.mv.Observadores.CPUObserver;
import tp.pr5.mv.Observadores.MemoryObserver;
import tp.pr5.mv.Observadores.StackObserver;
import tp.pr5.mv.command.CommandInterpreter;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.cpu.ProgramMV;
import tp.pr5.mv.ins.Instruction;

@SuppressWarnings("serial")
public class StatusBarPanel extends JPanel implements CPUObserver,
		MemoryObserver, StackObserver {

	private JLabel estadoCpu;
	private JLabel numInst;
	private JLabel memoriaModificada;
	private JLabel pilaModificada;
	private JCheckBox stack;
	private JCheckBox memory;
	private int numInstrExecute;
	
	public StatusBarPanel() {
		initGUI();
	}
	
	private void initGUI() {
		estadoCpu = new JLabel("");
		numInst = new JLabel("Num. instrucciones ejecutadas " + numInstrExecute);
		memoriaModificada = new JLabel("Memoria modificada ");
		pilaModificada = new JLabel("Pila modificada ");
		numInstrExecute = 0;
	
		stack = new JCheckBox();
		memory = new JCheckBox();
		
		this.add(estadoCpu);
		this.add(numInst);
		this.add(memory);
		this.add(memoriaModificada);
		this.add(stack);
		this.add(pilaModificada);
	}
 	
	@Override
	public void onPush(int value) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPop() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onWrite(int index, int value) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStartInstrExecution(Instruction instr) {
		// TODO Auto-generated method stub
		numInstrExecute++;
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				numInst.setText("Num. instrucciones ejecutadas " + numInstrExecute);
			}
			
		});
		
	}

	@Override
	public void onEndInstrExecution(int pc, OperandStack pila, Memory memoria) {
		// TODO Auto-generated method stub
		if(CommandInterpreter.isQuit()) {
			SwingUtilities.invokeLater(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					estadoCpu.setText("M�quina parada");
					estadoCpu.setForeground(Color.RED);
					
				}
				
			});
			
		}
	}

	@Override
	public void onStartRun() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onEndRun() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onError(String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onHalt() {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				stack.setSelected(false);
				memory.setSelected(false);	
			}	
		});
		
	}

	@Override
	public void stackModify() {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				stack.setSelected(true);
			}
		});
		
	}

	@Override
	public void memoryModify() {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				memory.setSelected(true);	
			}
		});
	}

	@Override
	public void updateProgram(ProgramMV programa, int pc) {
		// TODO Auto-generated method stub
		
	}


}
