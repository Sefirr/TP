package tp.pr5.mv.Vistas.Window;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.border.TitledBorder;

import tp.pr5.mv.Observadores.CPUObserver;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.cpu.ProgramMV;
import tp.pr5.mv.ins.Instruction;

@SuppressWarnings("serial")
public class ProgramPanel extends JPanel implements CPUObserver {

	private JScrollPane ScrollPrograma;
	private JTextArea programTextArea;
	
	public ProgramPanel() {
		initGUI();
	}
	
	private void initGUI() {
		TitledBorder TituloPanelPrograma = BorderFactory.createTitledBorder("Programa");
		this.setBorder(TituloPanelPrograma);
		programTextArea = new JTextArea(21,13);
		programTextArea.append("");
		programTextArea.setLineWrap(true);
		programTextArea.setBounds(0,0, 150,500);
		programTextArea.setEditable(false);
		
		ScrollPrograma = new JScrollPane(programTextArea);
		
		this.add(ScrollPrograma);

	}
	
	@Override
	public void updateProgram(ProgramMV programa, int pc) {
		Instruction ins;
		int contador = 0;
		String cadena = "";
		
		for(int i = 0; i < programa.size(); i++) {
			ins = programa.getInstruction(i);
			if(contador == pc) {
				cadena += "*      " + contador + ": " + ins.name() + System.lineSeparator();
			}
			else {
				cadena += "        " + contador + ": " + ins.name() + System.lineSeparator();
			}
			contador++;	
		}
		
		final String msg = cadena;
		
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				programTextArea.setText("");
				programTextArea.append(msg);
			}
		});
		
		
		
	}
	
	@Override
	public void onStartInstrExecution(Instruction instr) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onEndInstrExecution(int pc, OperandStack pila, Memory memoria) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStartRun() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onEndRun() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onError(String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onHalt() {
		// TODO Auto-generated method stub
		
	}

}
