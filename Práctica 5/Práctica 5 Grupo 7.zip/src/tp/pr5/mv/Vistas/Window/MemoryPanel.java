package tp.pr5.mv.Vistas.Window;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.TreeMap;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.AbstractTableModel;

import tp.pr5.mv.Controladores.GUIController;
import tp.pr5.mv.Excepciones.UndefinedInstructionException;
import tp.pr5.mv.Observadores.CPUObserver;
import tp.pr5.mv.Observadores.MemoryObserver;
import tp.pr5.mv.cpu.Memory;
import tp.pr5.mv.cpu.OperandStack;
import tp.pr5.mv.cpu.ProgramMV;
import tp.pr5.mv.ins.Instruction;

@SuppressWarnings("serial")
public class MemoryPanel extends JPanel implements MemoryObserver, CPUObserver {

	private GUIController guiCtrl;
	
	private JTable _Tabla;
	private JScrollPane tableScrollPane;
	private ModelTable model;
	private JTextField _Pos;
	private JTextField _Val;
	private JLabel _LPos;
	private JLabel _LVal;
	private JPanel _panelComandosMemoria;
	private JButton _botonWRITE;
	
	public MemoryPanel(GUIController guiCtrl) {
		this.guiCtrl = guiCtrl;
		initGUI();
	}
	
	private class ModelTable extends AbstractTableModel{	
		TreeMap<Integer,Integer> content;
		private String[] columnas = {"DIRECCI�N ", "VALOR"};
		
		public ModelTable() {
			content = new TreeMap<Integer,Integer>();
		}
		@Override
		public int getColumnCount() {
			// TODO Auto-generated method stub
			return 2;
		}
		@Override
		public int getRowCount() {
			// TODO Auto-generated method stub
			return content.size();
		}
		
		@Override
		public String getColumnName(int col) {
			return columnas[col];
		}
		
		public void setValueAt(int index, int value) {
			content.put(index, value);
			this.fireTableDataChanged();
		}
		
		@Override
		public Object getValueAt(int rowIndex, int columnIndex) {
			// TODO Auto-generated method stub
			if (rowIndex>=content.size())
				return null;
			else {
				if (columnIndex==0)
					return content.keySet().toArray()[rowIndex];
				else if (columnIndex==1)
					return content.get(content.keySet().toArray()[rowIndex]);				
				else
					return null;
			}
		}
		
	}
	
	private void initGUI() {
		model = new ModelTable();		
		_Tabla = new JTable(model);
		tableScrollPane = new JScrollPane(_Tabla);
		
		
		//Panel de comandos para la memoria
		_panelComandosMemoria = new JPanel();
		_panelComandosMemoria.setLayout(new FlowLayout());
		_Pos  = new JTextField(5);
		_Val = new JTextField(5);
		_LPos = new JLabel("Pos: ");
		_LVal = new JLabel("Val: ");
		
		_botonWRITE = new JButton("WRITE");		
		
		_botonWRITE.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {				
				String pos = _Pos.getText();
				String content = _Val.getText();
				try {
					if(isNumeric(pos) && isNumeric(content)) {
						int _pos = Integer.parseInt(pos);	
						int _value = Integer.parseInt(content);
						guiCtrl.memorySet(_pos, _value);
					} else if(!isNumeric(pos) || (!isNumeric(content))) {
						throw new UndefinedInstructionException("Error: Par�metros incorrectos en el comando.");
					}
				} catch(UndefinedInstructionException e) {
					JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
				}
				SwingUtilities.invokeLater(new Runnable() {
					@Override
					public void run() {
						// TODO Auto-generated method stub
						_Pos.setText(null);
						_Val.setText(null);
					}	
				});
				
			}
		});		
		
		_panelComandosMemoria.add(_LPos);
		_panelComandosMemoria.add(_Pos);
		_panelComandosMemoria.add(_LVal);
		_panelComandosMemoria.add(_Val);
		_panelComandosMemoria.add(_botonWRITE);
		
		this.add(tableScrollPane);		
		this.add(_panelComandosMemoria);
	}
	
	private static boolean isNumeric(String cadena){
		try {
			Integer.parseInt(cadena);
			return true;
		} catch (NumberFormatException nfe){
			return false;
		}
	}
	
	@Override
	public void onStartInstrExecution(Instruction instr) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onEndInstrExecution(int pc, OperandStack pila, Memory memoria) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStartRun() {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				_botonWRITE.setEnabled(false);
			}
		});
	}

	@Override
	public void onEndRun() {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				_botonWRITE.setEnabled(true);
			}
		});
	}

	@Override
	public void onError(String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onHalt() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onWrite(final int index, final int value) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				model.setValueAt(index, value);
				_Tabla.setModel(model);	
			}	
		});
		
	}

	@Override
	public void memoryModify() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateProgram(ProgramMV programa, int pc) {
		// TODO Auto-generated method stub
		
	}
	
}
