package tp.pr5.mv.Vistas.Window;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import tp.pr5.mv.Observadores.StrategyObserver;

@SuppressWarnings("serial")
public class OutputPanel extends JPanel implements StrategyObserver {
	
	private JTextArea _Salida;
	private JScrollPane ScrollSalida;
	
	public OutputPanel() {
		initGUI();
	}

	private void initGUI() {
		// TODO Auto-generated method stub
		_Salida = new JTextArea(4, 36);	
		//_Salida.append(guiCtrl.mensajeSalida());
		_Salida.setLineWrap(true);
		_Salida.setEditable(false);
		
		ScrollSalida = new JScrollPane(_Salida);
		this.add(ScrollSalida);
	}

	@Override
	public void updateInMessage(String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateOutMessage(final String msg) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				_Salida.setText("");
				_Salida.append(msg);
			}
			
		});
		
	}

	

}
