package tp.pr5.mv.StrategyIn;

/** Clase decoradora base llamada StrategyInDecorator que lo que hace es decorar la estrategia
 * de entrada con las funcionalidades de la ventana.
 */
public abstract class StrategyInDecorator implements StrategyIn {
	
	protected StrategyIn entrada;
	
	/**
	 * Constructor que recibe una instancia de StrategyIn
	 * con el fin de poder decorarla
	 */
	public StrategyInDecorator(StrategyIn entrada) {
		this.entrada = entrada;
	}
	
	public void open() {
		// TODO Auto-generated method stub
		this.entrada.open();	
	}

	public void close() {
		// TODO Auto-generated method stub
		this.entrada.close();
	}
	
	/**
	 * Operaciones que ser�n decoradas por la subclase decoradora WindowIn
	 */
	
	public int read() {
		return this.entrada.read();
	}
	
	public void leerFichero() {
		this.entrada.leerFichero();
	}
	
}
