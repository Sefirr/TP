/**
 * 
 */
package tp.pr5.mv.StrategyIn;

import java.util.ArrayList;
import tp.pr5.mv.Observadores.StrategyObserver;

/**
 * Clase decoradora WindowIn que a�ade las funcionalidades del modo Window a las estrategias
 * de entrada.
 */
public class WindowIn extends StrategyInDecorator{

	private String mensajeEntrada; // Mensaje que se tiene que mostrar en la ventana
	private int numeroCaracter; // Posici�n que corresponde al car�cter que se tiene que sustituir por la pista visual una vez ha sido le�do
	private ArrayList<StrategyObserver> observers;
	
	/**
	 * Constructor de la clase decoradora que corresponde a la estrategia de entrada del modo Window
	 * y inicializa el mensaje que recibir� la interfaz gr�fica del modo Window, adem�s de el numCaracter
	 * @param entrada es la estrategia de entrada que se va a decorar.
	 */
	public WindowIn(StrategyIn entrada) {
		super(entrada);
		this.mensajeEntrada = new String();
		this.numeroCaracter = 0;
		this.observers = new ArrayList<StrategyObserver>();
		// TODO Auto-generated constructor stub
	}

	public int read() {
		// TODO Auto-generated method stub
		char car;
		if(numeroCaracter < mensajeEntrada.length()) {
			car = (char) super.read();
			char[] linea = mensajeEntrada.toCharArray();
			if(mensajeEntrada.charAt(numeroCaracter) == '\n');
			else if(mensajeEntrada.charAt(numeroCaracter) == car)
				linea[numeroCaracter] = '*';
				
			mensajeEntrada = new String(linea);
			numeroCaracter++;
			for(StrategyObserver o: observers) {
				o.updateInMessage(mensajeEntrada);
			}
			return (int) car;
		}
		return -1;
	}
	
	public void leerFichero() {
		super.leerFichero();
		int linea;
		do {
			linea = super.read();
			if(linea != -1)
				mensajeEntrada += (char) linea;
		} while(linea != -1);
		close();
		open();
		for(StrategyObserver o: observers) {
			o.updateInMessage(mensajeEntrada);
		}
	}
	
	public void addObserver(StrategyObserver o) {
		// TODO Auto-generated method stub
		observers.add(o);
	}
	
	public void removeObserver(StrategyObserver o) {
		// TODO Auto-generated method stub
		observers.remove(o);
	}

}
