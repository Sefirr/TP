package tp.pr5.mv.StrategyIn;

public interface StrategyIn {
	
	public void open();
	public void close();
	public int read();
	public void leerFichero();
	
}
