package tp.pr5.mv;

import java.io.*;

import org.apache.commons.cli.*;

import tp.pr5.mv.Controladores.BatchController;
import tp.pr5.mv.Controladores.GUIController;
import tp.pr5.mv.Controladores.InteractiveController;
import tp.pr5.mv.StrategyIn.ConsoleIn;
import tp.pr5.mv.StrategyIn.FileIn;
import tp.pr5.mv.StrategyIn.NullIn;
import tp.pr5.mv.StrategyIn.StrategyIn;
import tp.pr5.mv.StrategyIn.WindowIn;
import tp.pr5.mv.StrategyOut.ConsoleOut;
import tp.pr5.mv.StrategyOut.FileOut;
import tp.pr5.mv.StrategyOut.NullOut;
import tp.pr5.mv.StrategyOut.WindowOut;
import tp.pr5.mv.StrategyOut.StrategyOut;
import tp.pr5.mv.Vistas.BatchView;
import tp.pr5.mv.Vistas.InteractiveView;
import tp.pr5.mv.Vistas.MainWindow;
import tp.pr5.mv.command.CommandInterpreter;
import tp.pr5.mv.cpu.CPU;
import tp.pr5.mv.cpu.ProgramMV;

/**
 * @author Grupo 7
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args){
		// TODO Auto-generated method stub
		String mode = "";
		
		Options options = new Options();
		options.addOption("h","help", false, "Muestra esta ayuda.");
		options.addOption("i","in", true, "Entrada del programa de la maquina.");
		options.addOption("o","out", true, "Fichero donde se guarda la salida del programa de la maquina.");
		options.addOption("a","asm", true, "Fichero con el codigo en ASM del programa a ejecutar. Obligatorio en modo batch.");
		options.addOption("m","mode", true, "Modo de funcionamiento (batch | interactive | window). Por defecto, batch.");
		
		
		CommandLineParser cli = new BasicParser();
		CommandLine cmd = null;
		
		try {
		    cmd = cli.parse( options, args);
		
			if(cmd.hasOption("h")) {
				new HelpFormatter().printHelp(" tp.pr5.mv.Main [-a <asmfile>] [-h] [-i <infile>] [-m <mode>] [-o <outfile>] ", options ); 
			} else {
				if(cmd.hasOption("m")) {
					if(cmd.getOptionValue("m").equalsIgnoreCase("interactive")) {
						mode = "interactive";
					} else if(cmd.getOptionValue("m").equalsIgnoreCase("batch")) {
						mode = "batch";	
					} else if(cmd.getOptionValue("m").equalsIgnoreCase("window")) {
						mode = "window";	
					} else {
						mode = cmd.getOptionValue("m");
						throw new ParseException("Modo incorrecto (parametro -m|--mode)");
					}
				} else {
					mode = "batch";
				}
	
				if(mode == "interactive" ) {
					interactiveMode(args);
				} else if(mode == "window" ) {
					windowMode(args);
				} else if(mode == "batch") {
					batchMode(args);
				}
			}
			
		} catch (ParseException e) {
			System.err.println("Uso incorrecto: " + e.getMessage() + " Use -h|--help para m�s detalles.");
			System.exit(1);
		} catch(Exception e) {
			System.err.println(e);
		}
			
	}
	
	public static void interactiveMode(String[] args) {
		String inputFile = null;
		String outputFile = null;
		String asmFile = null;
		File input = null;
		File output = null;
		File fichero_asm;
		StrategyIn entrada = null;
		StrategyOut salida = null;
		
		Options options = new Options();
		
		options.addOption("i","in", true, "Entrada del programa de la maquina.");
		options.addOption("o","out", true, "Fichero donde se guarda la salida del programa de la maquina.");
		options.addOption("a","asm", true, "Fichero con el codigo en ASM del programa a ejecutar. Obligatorio en modo batch.");
		options.addOption("m","mode", true, "Modo de funcionamiento (batch | interactive). Por defecto, batch.");
		
		CommandLineParser cli = new BasicParser();
		CommandLine cmd = null;
		
		try {
		    cmd = cli.parse( options, args);
		    
		    if(cmd.hasOption("i")) {
				inputFile = cmd.getOptionValue("i");	
				input = new File(inputFile);
				if(input.exists()) {
					entrada = new FileIn(inputFile);
				} else{
					throw new ParseException("Error al acceder al fichero de entrada (" + inputFile + ")");
				}
			} else {
				entrada = new NullIn();
			}
			
			if(cmd.hasOption("o")) {
				outputFile = cmd.getOptionValue("o");
				output = new File(outputFile);
				if(output.exists()) {
					salida = new FileOut(outputFile);
				}else{
					output.createNewFile();
					salida = new FileOut(outputFile);
				}
				
			} else {
				salida = new NullOut();	
			}
			
			if(cmd.hasOption("a")) {
				fichero_asm = new File(cmd.getOptionValue("a"));
				asmFile = cmd.getOptionValue("a");
				if(fichero_asm.exists());
				else {
					throw new ParseException("Error al acceder al fichero ASM (" + asmFile + ")");
				}
			}
		

			CPU cpu = new CPU(entrada, salida);
			entrada.open();
			salida.open();
			
			ProgramMV program = (asmFile == null) ? ProgramMV.read_program() : ProgramMV.read_program(asmFile);
			cpu.loadProgram(program);
			CommandInterpreter.configureCommandInterpreter(cpu);
			
			InteractiveController ctrl = new InteractiveController(cpu);
			InteractiveView view = new InteractiveView(ctrl);
			cpu.addCPUObserver(view);
			ctrl.start();
			
			entrada.close();
			salida.close();
		} catch (ParseException e) {
			System.err.println("Uso incorrecto: " + e.getMessage() + " Use -h|--help para m�s detalles.");
			System.exit(1);
		} catch (IOException e) {
			System.err.println(e.getMessage());
			System.exit(2);	
		} catch(Exception e) {
			System.err.println(e);
		}
	}
	
	public static void batchMode(String[] args) {
		
		String inputFile = null;
		String outputFile = null;
		String asmFile = null;
		File input = null;
		File output = null;
		File fichero_asm;
		StrategyIn entrada = null;
		StrategyOut salida = null;
		
		Options options = new Options();
		
		options.addOption("i","in", true, "Entrada del programa de la maquina.");
		options.addOption("o","out", true, "Fichero donde se guarda la salida del programa de la maquina.");
		options.addOption("a","asm", true, "Fichero con el codigo en ASM del programa a ejecutar. Obligatorio en modo batch.");
		options.addOption("m","mode", true, "Modo de funcionamiento (batch | interactive | window). Por defecto, batch.");
		
		CommandLineParser cli = new BasicParser();
		CommandLine cmd = null;
		
		try {
		    cmd = cli.parse( options, args);
		    
		    if(cmd.hasOption("i")) {
				inputFile = cmd.getOptionValue("i");	
				input = new File(inputFile);
				if(input.exists()) {
					entrada = new FileIn(inputFile);
				} else{
					throw new ParseException("Error al acceder al fichero de entrada (" + inputFile + ")");
				}
			} else {
				entrada = new ConsoleIn();
			}
			
			if(cmd.hasOption("o")) {
				outputFile = cmd.getOptionValue("o");
				output = new File(outputFile);
				if(output.exists()) {
					salida = new FileOut(outputFile);
				}else{
					output.createNewFile();
					salida = new FileOut(outputFile);
				}
			} else {
				salida = new ConsoleOut();	
			}
			
			if(cmd.hasOption("a")) {
				fichero_asm = new File(cmd.getOptionValue("a"));
				asmFile = cmd.getOptionValue("a");
				if(fichero_asm.exists()) {
			
				} else {
					throw new ParseException("Error al acceder al fichero ASM (" + asmFile + ")");
				}
			} else {
				throw new ParseException("Fichero ASM no especificado.");
			}
		
		
			CPU cpu = new CPU(entrada, salida);
			entrada.open();
			salida.open();
			
			ProgramMV program = ProgramMV.read_program(asmFile);
			cpu.loadProgram(program);
			CommandInterpreter.configureCommandInterpreter(cpu);
			
			BatchController ctrl = new BatchController(cpu);
			BatchView view = new BatchView(ctrl);
			cpu.addCPUObserver(view);
			ctrl.start();
			
			entrada.close();
			salida.close();
		} catch (ParseException e) {
			System.err.println("Uso incorrecto: " + e.getMessage() + " Use -h|--help para m�s detalles.");
			System.exit(1);
		} catch (IOException e) {
			System.err.println(e.getMessage());
			System.exit(2);	
		} catch(Exception e) {
			System.err.println(e);
		}
	}
	
	public static void windowMode(String[] args) {
		
		String inputFile = null;
		String outputFile = null;
		String asmFile = null;
		File input = null;
		File output = null;
		File fichero_asm;
		StrategyIn entrada = null;
		StrategyOut salida = null;
		
		Options options = new Options();
		
		options.addOption("i","in", true, "Entrada del programa de la maquina.");
		options.addOption("o","out", true, "Fichero donde se guarda la salida del programa de la maquina.");
		options.addOption("a","asm", true, "Fichero con el codigo en ASM del programa a ejecutar. Obligatorio en modo batch.");
		options.addOption("m","mode", true, "Modo de funcionamiento (batch | interactive | window). Por defecto, batch.");
		
		CommandLineParser cli = new BasicParser();
		CommandLine cmd = null;
		
		try {
		    cmd = cli.parse( options, args);
		    
		    if(cmd.hasOption("i")) {
				inputFile = cmd.getOptionValue("i");	
				input = new File(inputFile);
				if(input.exists()) {
					entrada = new WindowIn(new FileIn(inputFile));
				} else{
					throw new ParseException("Error al acceder al fichero de entrada (" + inputFile + ")");
				}
			} else {
				entrada = new WindowIn(new NullIn());
			}
			
			if(cmd.hasOption("o")) {
				outputFile = cmd.getOptionValue("o");
				output = new File(outputFile);
				if(output.exists()) {
					salida = new WindowOut(new FileOut(outputFile));
				}else{
					output.createNewFile();
					salida = new WindowOut(new FileOut(outputFile));
				}
			} else {
				salida = new WindowOut(new NullOut());
			}
			
			if(cmd.hasOption("a")) {
				fichero_asm = new File(cmd.getOptionValue("a"));
				asmFile = cmd.getOptionValue("a");
				if(fichero_asm.exists()) {
				
				} else {
					throw new ParseException("Error al acceder al fichero ASM (" + asmFile + ")");
				}
			} else {
				throw new ParseException("Fichero ASM no especificado.");
			}
		
			CPU cpu = new CPU(entrada, salida);
			ProgramMV program = ProgramMV.read_program(asmFile);
			CommandInterpreter.configureCommandInterpreter(cpu);
			
			GUIController ctrl = new GUIController(cpu);
			MainWindow view = new MainWindow(ctrl, cpu);
			cpu.addCPUObserver(view);
			cpu.loadProgram(program);
			ctrl.start();
			
			entrada.open();
			entrada.leerFichero();
			entrada.open();
			salida.open();
		} catch (ParseException e) {
			System.err.println("Uso incorrecto: " + e.getMessage() + " Use -h|--help para m�s detalles.");
			System.exit(1);
		} catch (IOException e) {
			System.err.println(e.getMessage());
			System.exit(2);	
		} catch(Exception e) {
			System.err.println(e);
		}
			
	}
}
