package tp.pr5.mv.Controladores;

import tp.pr5.mv.cpu.CPU;

public class GUIController extends Controller {

	public GUIController(CPU modelo) {
		super(modelo);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void start() { // TODO Auto-generated method stub
		
	}
	
}
