package tp.pr5.mv.Controladores;

import tp.pr5.mv.Excepciones.UndefinedInstructionException;
import tp.pr5.mv.command.CommandInterpreter;
import tp.pr5.mv.command.CommandParser;
import tp.pr5.mv.cpu.CPU;

public class InteractiveController extends Controller {

	public InteractiveController(CPU modelo) {
		super(modelo);
		// TODO Auto-generated constructor stub
	}
	

	@Override
	public void start() { // TODO Auto-generated method stub
		
		String cadena;
		@SuppressWarnings("resource")
		java.util.Scanner sc = new java.util.Scanner(System.in);
		CommandInterpreter comando;
		
		do {
			cadena = sc.nextLine();
			comando = CommandParser.parseCommand(cadena);
			if(!CommandInterpreter.isQuit()) {
				if(comando != null) {
					comando.executeCommand();
				} else {
					try {
						throw new UndefinedInstructionException("No te entiendo.");
					} catch (UndefinedInstructionException e) {
						System.err.println(e);
					}
				}
			}	
		}while(!CommandInterpreter.isQuit());
		
	}

}
