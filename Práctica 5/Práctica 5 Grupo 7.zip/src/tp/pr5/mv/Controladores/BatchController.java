package tp.pr5.mv.Controladores;

import tp.pr5.mv.cpu.CPU;

public class BatchController extends Controller {

	public BatchController(CPU modelo) {
		super(modelo);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void start() { // TODO Auto-generated method stub
		run();
	}

}
