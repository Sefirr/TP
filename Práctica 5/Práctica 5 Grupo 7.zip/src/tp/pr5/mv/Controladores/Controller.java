package tp.pr5.mv.Controladores;

import java.io.IOException;

import tp.pr5.mv.Excepciones.ArithmeticException;
import tp.pr5.mv.Excepciones.MemoryException;
import tp.pr5.mv.Excepciones.StackException;
import tp.pr5.mv.command.CommandInterpreter;
import tp.pr5.mv.command.DEBUG;
import tp.pr5.mv.cpu.CPU;
import tp.pr5.mv.ins.OthersOP.POP;
import tp.pr5.mv.ins.OthersOP.PUSH;
import tp.pr5.mv.ins.OthersOP.WRITE;


public abstract class Controller {
	
	protected CPU modelo;
	
	public Controller(CPU modelo) {
		this.modelo = modelo;
	}
	
	public void step() {
		try {
			modelo.step();
		} catch (StackException | MemoryException | ArithmeticException | IOException e) {
			
		}
		
	}
	
	public void StreamClose() {
		modelo.StreamClose();
	}
	
	public void run() {
		modelo.run();
	}
	
	public void pop() {
		CommandInterpreter command = new DEBUG(new POP());	// ejecuta el pop del cpu
		command.executeCommand();
	} 
	
	public void push(int v) {
		CommandInterpreter command = new DEBUG(new PUSH(v));	// ejecuta push
		command.executeCommand();
	} 
	
	
	public void memorySet(int i, int v) {
		CommandInterpreter command = new DEBUG(new WRITE(i,v));	// ejecuta write
		command.executeCommand();
	} 
	
	
	public abstract void start(); // un m�todo abstracto, depende del modo
	
	public void quit() {
		StreamClose();
		System.exit(0);
	}

}
