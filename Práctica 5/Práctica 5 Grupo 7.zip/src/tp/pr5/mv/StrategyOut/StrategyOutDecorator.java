package tp.pr5.mv.StrategyOut;

public abstract class StrategyOutDecorator implements StrategyOut {
	
	protected StrategyOut salida;
	
	/**
	 * Constructor que recibe una instancia de StrategyOut
	 * con el fin de poder decorarla
	 */
	public StrategyOutDecorator(StrategyOut salida) {
		this.salida = salida;
	}

	@Override
	public void open() throws Exception {
		// TODO Auto-generated method stub
		this.salida.open();
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		this.salida.close();
	}
	
	/**
	 * Operaciones que ser�n decoradas por la subclase decoradora WindowOut
	 */

	@Override
	public void write(int c) {
		// TODO Auto-generated method stub
		this.salida.write(c);
	}

}