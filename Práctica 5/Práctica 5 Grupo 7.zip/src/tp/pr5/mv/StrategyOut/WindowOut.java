/**
 * 
 */
package tp.pr5.mv.StrategyOut;

import java.util.ArrayList;

import tp.pr5.mv.Observadores.StrategyObserver;


/**
 * Clase decoradora WindowOut que a�ade las funcionalidades del modo Window a las estrategias
 * de salida.
 */
public class WindowOut extends StrategyOutDecorator {
	
	private String mensajeSalida; // Mensaje que se tiene que mostrar en la ventana
	private ArrayList<StrategyObserver> observers;
	/**
	 * Constructor de la clase decoradora que corresponde a la estrategia de salida del modo Window
	 * y inicializa el mensaje que recibir� la interfaz gr�fica del modo Window.
	 * @param salida es la estrategia de salida que se va a decorar.
	 */
	public WindowOut(StrategyOut salida) {
		super(salida);
		this.mensajeSalida = new String();
		this.observers = new ArrayList<StrategyObserver>();
		// TODO Auto-generated constructor stub
	}
	
	public void write(int c) {
		// TODO Auto-generated method stub
		super.write((char) c);
		mensajeSalida += (char) c;
		for(StrategyObserver o: observers) {
			o.updateOutMessage(mensajeSalida);
		}
	}
	
	public void addObserver(StrategyObserver o) {
		// TODO Auto-generated method stub
		observers.add(o);
	}
	
	public void removeObserver(StrategyObserver o) {
		// TODO Auto-generated method stub
		observers.remove(o);
	}

}
