/**
 * 
 */
package tp.pr0;

/**
 * @author Javier Villarreal
 * @version October, 2013
 *
 */
public class pr0Main {

	/**
	 * @param args
	 */
	public void escribeSaludo(String nombre) {
		System.out.println("Hola, " + nombre);
		}
		public static void main(String args[]) {
			// TODO Auto-generated method stub
			pr0Main Main = new pr0Main();
			Main.escribeSaludo("Javier");
		}
	
}
