/**
 * 
 */
package tp.pr0;

/**
 * @author Javier Villarreal
 * @version October, 2013
 *
 */
public class FuncsMatematicas {

	/**
	 * @param args
	 */
	public static int factorial(int n) {
		int resultado = 1;
		if(n < 0)
			resultado = 0;
		else if(n == 0 || n == 1)
			resultado = 1;
		else {
			for(int i = 2; i <= n; i++)
				resultado = resultado*i;
		}
		
		return resultado;
	}
	
	public static int combinatorio(int n, int k) {
		int resultado;
		
		if(k > 0 && k < n)
			resultado = factorial(n) / (factorial(k) * factorial(n-k));
		else
			resultado = 1;
		
		return resultado;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 0; i < 6; ++i) {
			for (int j = 0; j <= i; ++j)
			System.out.print(FuncsMatematicas.combinatorio(i, j) + " ");
			System.out.println();
			}

	}

}
