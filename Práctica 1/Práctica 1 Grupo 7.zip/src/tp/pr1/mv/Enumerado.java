/**
 * 
 */
package tp.pr1.mv;

/**
 * Una clase enumerada con todas las posibles ordenes de la instrucci�n.
 * @author Grupo_7
 *
 */
public enum Enumerado {
	
	PUSH, POP, DUP, FLIP, LOAD, STORE, ADD, SUB, MUL, DIV, OUT, HALT;
	
	/**
	 * Comprueba si la instrucci�n de 2 par�metros es v�lida. Si es v�lida, le asigna la orden a la instrucci�n.
	 * @param s Es la cadena correspondiente a la orden.
	 * @return Devuelve la orden de la instrucci�n.
	 */
	
	public static Enumerado getEnum2Parametros(String s) {
		Enumerado orden;
		if(STORE.name().equalsIgnoreCase(s))
			orden = STORE;
		else if(LOAD.name().equalsIgnoreCase(s))
			orden = LOAD;
		else if(PUSH.name().equalsIgnoreCase(s))
			orden = PUSH;
		else
			orden = null;
			
	    return orden;
	}
	
	/**
	 * Comprueba si la instrucci�n de 1 par�metro es v�lida. Si es v�lida, le asigna la orden a la instrucci�n.
	 * @param s Es la cadena correspondiente a la orden.
	 * @return Devuelve la orden de la instrucci�n.
	 */
	public static Enumerado getEnum1Parametro(String s) {
		Enumerado orden;
		if(HALT.name().equalsIgnoreCase(s))
			orden = HALT;
		else if(DUP.name().equalsIgnoreCase(s))
			orden = DUP;
		else if(FLIP.name().equalsIgnoreCase(s))
			orden = FLIP;
		else if(POP.name().equalsIgnoreCase(s))
			orden = POP;
		else if(OUT.name().equalsIgnoreCase(s))
			orden = OUT;
		else if(ADD.name().equalsIgnoreCase(s))
			orden = ADD;
		else if(SUB.name().equalsIgnoreCase(s))
			orden = SUB;
		else if(MUL.name().equalsIgnoreCase(s))
			orden = MUL;
		else if(DIV.name().equalsIgnoreCase(s))
			orden = DIV;
		else
			orden = null;
			
	    return orden;
	}

}
