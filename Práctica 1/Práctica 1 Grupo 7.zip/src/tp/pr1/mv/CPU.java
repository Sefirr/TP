/**
 * 
 */
package tp.pr1.mv;

/**
 * Una clase CPU para representar la CPU de m�quina virtual.
 * Cada CPU contiene una memoria y una pila, es decir, el lugar
 * donde se realizan las operaciones.
 * @version 1.0, 17/11/2013
 * @author Grupo_7
 *
 */
public class CPU {
	
	private Memory memoria; //Memoria de la CPU
	private OperandStack pila; //Memoria de la pila
	private boolean terminado; //Booleano que determina si la ejecuci�n de la CPU ha terminado o no.
	
	/**
	 * M�todo constructor que inicializa los atributos del objeto de tipo CPU
	 * sin par�metros.
	 */
	
	public CPU() {
		this.memoria = new Memory();
		this.pila = new OperandStack();
		this.terminado = false;
	}
	
	/**
	 * Comprueba si la CPU est� activa.
	 * @return true si la m�quina sigue activa.
	 */
	
	public boolean esActiva() {
		return (terminado == false);
	}
	
	/**
	 * 	Para la m�quina virtual
	 * @return true si la m�quina se para.
	 */
	
	private boolean pararMaquina() {
		
		this.terminado = true;
		
		return terminado;
	}
	
	/**
	 * Ejecuta la instrucci�n HALT, que para la m�quina.
	 * @return true si se para la m�quina.
	 */
	
	private boolean ejecutaHALT() {
		
		boolean correcto = pararMaquina();
		
		
		return correcto;
		
	}
	
	/**
	 * Ejecuta la instrucci�n STORE, que almacena en memoria la cima de la pila en la
	 * posici�n indicada. Luego, lo desapila de la pila.
	 * @param pos Posici�n de memoria en la que se almacena la cima de la pila.
	 * @return true si se ejecuta correctamente la instrucci�n.
	 */
	
	private boolean ejecutaSTORE(int pos) {
		
		int cima;
		boolean correcto = true;
		if(pila.getIndice() > 0 && pos >= 0) {
			cima = pila.getCima();
			pila.desapilar();
			memoria.insertar(pos, cima);
		}
		else {
			correcto = false;
		}
		
		return correcto;
		
	}
	
	/**
	 * Ejecuta la instrucci�n LOAD, que almacena en la cima de la pila,
	 *  el elemento situado en la posici�n de memoria indicado.
	 * @param pos Posici�n de memoria correspondiente al contenido de la celda que se quiere apilar en la pila.
	 * @return true si se ha ejecutado correctamente la instrucci�n.
	 */
	
		private boolean ejecutaLOAD(int pos) {
		
		int cima;
		boolean correcto = true;
		if(memoria.getContador() > 0 && memoria.comprobar(pos)) {
			cima = memoria.ObtenerContenido(pos);
			pila.apilar(cima);
		}
		else
			correcto = false;
			
		return correcto;
		
	}
	
	/**
	 * Ejecuta la instrucci�n FLIP, que cambia el contenido de la cima de la pila
	 * por el de la subcima y viceversa.
	 * @return true si se ejecuta correctamente la instrucci�n.
	 */
	
	private boolean ejecutaFLIP() {
		
		int cima, subcima;
		boolean correcto = true;
		
		if(pila.getIndice() > 1) {
			cima = pila.getCima();
			pila.desapilar();
			subcima = pila.getCima();
			pila.desapilar();
			pila.apilar(cima);
			pila.apilar(subcima);
		} else {
			correcto = false;
		}
		
		return correcto;
		
	}
	
	/**
	 * Ejecuta la instrucci�n PUSH, que apila el dato "n" en la cima de la pila. 
	 * @param n Es el dato que se va a apilar en la cima de la pila.
	 * @return true si se ejecuta correctamente la instrucci�n.
	 */
	
	private boolean ejecutaPUSH(int n) {
		
		pila.apilar(n);
		
		return true;	
	}
	
	/**
	 * Ejecuta la instrucci�n DUP que coge la cima de la pila y la apila.
	 * @return true si se ejecuta correctamente la instrucci�n.
	 */
	
	private boolean ejecutaDUP() {
		
		boolean correcto = true;
		
		if(pila.getIndice() >= 1) {
			int n = pila.getCima();
			pila.apilar(n);
		} else {
			correcto = false;
		}
		
		return correcto;
		
	}
	
	/**
	 * Ejecuta la instrucci�n POP, que desapila de la pila la cima de la pila.
	 * @return true si se ejecuta correctamente la instrucci�n.
	 */
	
	private boolean ejecutaPOP() {
		
		boolean correcto = true;
		
		if(pila.getIndice() > 0) {
			pila.desapilar();
		}
		else {
			correcto = false;
		}
		
		return correcto;
	}
	
	/**
	 * Ejecuta la instrucci�n OUT, que coge la cima de la pila, la convierte a c�racter
	 * y la muestra en pantalla.
	 * @return true si se ejecuta correctamente la instrucci�n.
	 */
	
	private boolean ejecutaOUT(){
		
		char cima;
		boolean correcto = true;
		
		if(pila.getIndice() >= 1) {
			cima = (char) pila.getCima();
			System.out.println(cima);	
		} else {
			correcto = false;
		}
		
		return correcto;
	}
	
	/**
	 * Ejecuta la instrucci�n ADD, que suma la cima y subcima de la pila y apila el resultado,
	 * desapilando los elementos de la cima y subcima.
	 * @return true si se ejecuta correctamente la instrucci�n.
	 */
	
	private boolean ejecutaADD() {
		
		int cima, subcima, resultado;
		boolean correcto = true;
		
		if(pila.getIndice() > 1) {
			cima = pila.getCima();
			pila.desapilar();
			subcima = pila.getCima();
			pila.desapilar();
	
			resultado = subcima + cima;
			pila.apilar(resultado);
		} else {
			correcto = false;
		}
		
		
		return correcto;
		
	}
	
	/**
	 * Ejecuta la instrucci�n SUB, que resta la cima y subcima de la pila y apila el resultado,
	 * desapilando los elementos de la cima y subcima.
	 * @return true si se ejecuta correctamente la instrucci�n.
	 */
	
	private boolean ejecutaSUB() {
		
		int cima, subcima, resultado;
		boolean correcto = true;
		
		if(pila.getIndice() > 1) {		
			cima = pila.getCima();
			pila.desapilar();
			subcima = pila.getCima();
			pila.desapilar();
	
			resultado = subcima - cima;
			pila.apilar(resultado);
		} else {
			correcto = false;
		}
		
		return correcto;
		
	}
	
	/**
	 * Ejecuta la instrucci�n MUL, que multiplica la cima y subcima de la pila y apila el resultado,
	 * desapilando los elementos de la cima y subcima.
	 * @return true si se ejecuta correctamente la instrucci�n.
	 */
	
	private boolean ejecutaMUL() {
		
		int cima, subcima, resultado;
		boolean correcto = true;
		
		if(pila.getIndice() > 1) {		
			cima = pila.getCima();
			pila.desapilar();
			subcima = pila.getCima();
			pila.desapilar();
	
			resultado = subcima * cima;
			pila.apilar(resultado);
		} else {
			correcto = false;
		}
		
		return correcto;
		
	}
	
	/**
	 * Ejecuta la instrucci�n DIV, que divide la cima y subcima de la pila y apila el resultado,
	 * desapilando los elementos de la cima y subcima.
	 * @return true si se ejecuta correctamente la instrucci�n.
	 */
	
	private boolean ejecutaDIV() {
		
		int cima, subcima, resultado;
		boolean correcto = true;
		
		if(pila.getIndice() > 1) {

			cima = pila.getCima();
			if(cima != 0) {
				pila.desapilar();
				subcima = pila.getCima();
				pila.desapilar();
	
				resultado = subcima / cima;
				pila.apilar(resultado);
			}
			else {
				correcto = false;
			}
		} else {
			correcto = false;
		}
		
		return correcto;
		
	}
	
	/**
	 * Ejecuta la instrucci�n que ha pedido el usuario para que se ejecute.
	 * @param instr Es la instrucci�n que se va a ejecutar.
	 * @return true si la instrucci�n que ha pedido el usuario se ejecuta correctamente.
	 */
	
	public boolean execute(Instruction instr) {
		Enumerado orden = instr.getOrden();
		int parametro = instr.getParametro();
		boolean correcto = false;
	
		switch(orden) {
			case HALT: correcto = ejecutaHALT();
			break;
			case STORE: correcto = ejecutaSTORE(parametro);
			break;
			case LOAD: correcto = ejecutaLOAD(parametro);
			break;
			case FLIP: correcto = ejecutaFLIP();
			break;
			case PUSH:  correcto = ejecutaPUSH(parametro);
			break;
			case DUP:  correcto = ejecutaDUP();
			break;
			case POP: correcto = ejecutaPOP();
			break;
			case ADD: correcto = ejecutaADD();
			break;
			case SUB: correcto = ejecutaSUB();
			break;
			case MUL: correcto = ejecutaMUL();
			break;
			case DIV: correcto = ejecutaDIV();
			break;
			case OUT: correcto = ejecutaOUT();
			break;
			default: break;
		}
		
		return correcto;
		
	}
	
	

	/**
	 * Muestra el contenido de la CPU.
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return "El estado de la m�quina tras ejecutar la instrucci�n es: " + 
	System.lineSeparator() + memoria + System.lineSeparator() + pila + System.lineSeparator();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
