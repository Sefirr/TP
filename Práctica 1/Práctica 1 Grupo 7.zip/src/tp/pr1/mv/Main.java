
package tp.pr1.mv;

/**
 * La clase main ejecuta la m�quina virtual y llama a los m�todos correspondientes para
 * que se ejecute correctamente.
 * @author Grupo_7
 *
 */
public class Main {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CPU computadora = new CPU(); // CPU de la m�quina virtual
		
		System.out.print("Instrucci�n a ejecutar: ");
		@SuppressWarnings("resource")
		java.util.Scanner sc = new java.util.Scanner(System.in);
		String cadena = sc.nextLine();
		Instruction ins;
		ins = InstructionParser.Parse(cadena);
		
		while(computadora.esActiva())  {
			if(ins == null) {
				System.out.println("Error en la ejecuci�n de la instruccion");
				System.out.print("Instrucci�n a ejecutar: ");
				cadena = sc.nextLine();
				ins = InstructionParser.Parse(cadena);
			}
			else {	
				System.out.print("Comienza la ejecuci�n de " +  ins.getOrden().name() + " ");
				
				if(ins.getParametro() != 0)
					System.out.println(ins.getParametro());
				else
					System.out.println(" ");
				
				if(computadora.execute(ins)) {
					System.out.println(computadora);			
					if(computadora.esActiva()) {
						System.out.print("Instrucci�n a ejecutar: ");
						cadena = sc.nextLine();
						ins = InstructionParser.Parse(cadena);
					}
				}
				else
					ins = null;
			}
		}
		
	}


}
