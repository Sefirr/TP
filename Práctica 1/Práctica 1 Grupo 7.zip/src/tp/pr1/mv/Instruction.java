
package tp.pr1.mv;

/**
 * Una clase para representar las instrucciones.
 * Cada instrucci�n posee atributo orden correspondiente al orden de la instrucci�n
 *  y un atributo par�metro correspondiente al par�metro de la instrucci�n.
 * @version 1.0, 17/11/2013
 * @author Grupo_7
 */
public class Instruction {
	
	private Enumerado orden; //Orden de la instrucci�n
	private Integer parametro; // Par�metro de la instrucci�n
	
	/**
	 * M�todo constructor que inicializa los atributos del objeto de tipo Instruction
	 * de un par�metro.
	 * @param orden Es la orden de la instrucci�n.
	 */
	
	public Instruction(Enumerado orden) {
			this.orden = orden;
			this.parametro = 0;
	}
	
	/**
	 * M�todo constructor que inicializar los atributos del objeto de tipo Instruction
	 * de dos par�metros.
	 * @param orden Es la orden de la instrucci�n.
	 * @param parametro Es el par�metro de la instrucci�n.
	 */
	
	public Instruction(Enumerado orden, int parametro) {
		this.orden =  orden;
		this.parametro = parametro;
	}
	
	/**
	 * M�todo accedente que nos devuelve el valor del atributo orden.
	 * @return Devuelve el valor del atributo orden.
	 */
	
	public Enumerado getOrden() {
		return orden;
	}
	
	/**
	 * M�todo accedente que nos devuelve el valor del atributo par�metro.
	 * @return Devuelve el valor del atributo par�metro.
	 */

	public int getParametro() {
		return parametro;
	}

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

}
