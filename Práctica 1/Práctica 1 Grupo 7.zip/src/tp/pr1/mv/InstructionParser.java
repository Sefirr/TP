
package tp.pr1.mv;

/**
 * Una clase para parsear la cadena correspondiente a la instrucci�n 
 * que quiere ejecutar el usuario. Cada instrucci�n queda determinada 
 * por su orden y par�metro.
 * @version 1.0, 17/11/2013
 * @author Grupo_7
 */

public class InstructionParser {
	
	/**
	 * Comprueba si la cadena es entera, si es entera se ejecuta el c�digo. 
	 * Si no es entera ejecuta la excepci�n.
	 * @param cad Es la cadena cad que se va a compruebar si es un n�mero o no
	 * @return true si la cadena es un n�mero
	 */
	
	private static boolean esEntero(String cad) {
		
		try {
			// C�digo que genera problemas. Cuando la cadena no es num�rica se ejecuta la excepci�n.
			Integer.parseInt(cad);
			return true;
		} catch(NumberFormatException nfe) {
			// Excepci�n del c�digo cuando da problemas.
			return false;
		}
	 }
	
	/**
	 * Descompone la cadena en subcadenas. En base a esas subcadenas genera un objeto de 
	 * tipo Instruction, que corresponde a la instrucci�n que se va a ejecutar.
	 * @param s Es la cadena que se va a descomponer mediante el m�todo split en las subcadenas cadena[0] y cadena[1], orden y par�metro respectivamente.
	 * @return El objeto de la instrucci�n que se va a ejecutar
	 */

	public static Instruction Parse(String s) {
		// TODO Auto-generated method stub
		String[] cadena = s.split(" ",2);
		
		Instruction ins = null;
		
		if (cadena.length == 2) {
			Enumerado orden = Enumerado.getEnum2Parametros(cadena[0]);
				
			if(orden != null) {
				if(esEntero(cadena[1])) {
					int parametro = Integer.parseInt(cadena[1]);
					ins = new Instruction(orden, parametro);
				}
			}
			else 
				ins = null;
				
		}
		else if(cadena.length == 1) {
			Enumerado orden = Enumerado.getEnum1Parametro(cadena[0]);
			ins = new Instruction(orden);
			
		    if(orden  != null)
				ins = new Instruction(orden);
		    else
		    	ins = null;
		}
		else if(cadena.length == 0)
			ins = null;
		
		return ins;
	}
	
	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

}
