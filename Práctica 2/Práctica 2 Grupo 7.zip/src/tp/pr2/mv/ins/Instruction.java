package tp.pr2.mv.ins;

import tp.pr2.mv.ExecutionManager;
import tp.pr2.mv.Memory;
import tp.pr2.mv.OperandStack;

/**
 * Interfaz correspondiente a las instrucciones. Los m�todos se sobrescriben en las
 * clases derivadas de las clases que implementan la interfaz para que todo funcione
 * correctamente.
 * @version 2.0
 * @author Grupo_7
 *
 */
public interface Instruction {
	
	// M�todos abstractos
	public abstract boolean execute(Memory memoria, OperandStack pila, ExecutionManager gestor);
	public abstract Instruction parseIns(String cadena);
	public abstract String toString();
	public abstract Integer getParametro();

}
