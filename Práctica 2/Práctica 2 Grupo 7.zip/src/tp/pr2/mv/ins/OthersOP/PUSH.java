package tp.pr2.mv.ins.OthersOP;

import tp.pr2.mv.ExecutionManager;
import tp.pr2.mv.Memory;
import tp.pr2.mv.OperandStack;
import tp.pr2.mv.ins.Instruction;

/**
 * Clase derivada de Binary que representa la instrucci�n PUSH.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class PUSH extends Binary {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Unary.
	 */
	public PUSH() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * M�todo constructor con par�metros que llama al constructor de
	 * Unary.
	 */
	public PUSH(int parametro) {
		super(parametro);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n PUSH.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public boolean execute(Memory memoria, OperandStack pila, ExecutionManager gestor) {
		pila.apilar(parametro);
		
		return true;
	}

	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente al
	 * toString de PUSH.
	 * @return Devuelve la cadena correspondiente a la instrucci�n PUSH.
	 */
	@Override
	protected Instruction Instruccion(int d) {
		// TODO Auto-generated method stub
		return new PUSH(d);
	}
	
	@Override
	public String toString() {
		return "PUSH";
	}

}
