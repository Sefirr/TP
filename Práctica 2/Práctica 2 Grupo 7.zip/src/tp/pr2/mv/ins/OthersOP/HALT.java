package tp.pr2.mv.ins.OthersOP;

import tp.pr2.mv.ExecutionManager;
import tp.pr2.mv.Memory;
import tp.pr2.mv.OperandStack;
import tp.pr2.mv.command.CommandInterpreter;
import tp.pr2.mv.ins.Instruction;

/**
 * Clase derivada de Unary que representa la instrucci�n ADD.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class HALT extends Unary {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Unary.
	 */
	public HALT() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n HALT.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public boolean execute(Memory memoria, OperandStack pila, ExecutionManager gestor) {
		return CommandInterpreter.getComputadora().getGestor().setHalt(true);
	}

	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada HALT.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion() {
		// TODO Auto-generated method stub
		return new HALT();
	}
	
	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente al
	 * toString de HALT.
	 * @return Devuelve la cadena correspondiente a la instrucci�n HALT.
	 */
	@Override
	public String toString() {
		return "HALT";
	}

}
