package tp.pr2.mv.ins.OthersOP;

import tp.pr2.mv.ExecutionManager;
import tp.pr2.mv.Memory;
import tp.pr2.mv.OperandStack;
import tp.pr2.mv.ins.Instruction;

/**
 * Clase derivada de Unary que representa la instrucci�n OUT.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class OUT extends Unary {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Unary.
	 */
	public OUT() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n OUT.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public boolean execute(Memory memoria, OperandStack pila, ExecutionManager gestor) {
		char cima;
		boolean correcto = true;
		
		if(pila.getIndice() >= 1) {
			cima = (char) pila.getCima();
			pila.desapilar();
			System.out.println(cima);	
		} else {
			correcto = false;
		}	
		
		return correcto;
	}

	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada OUT.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion() {
		// TODO Auto-generated method stub
		return new OUT();
	}
	
	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente al
	 * toString de OUT.
	 * @return Devuelve la cadena correspondiente a la instrucci�n OUT.
	 */
	@Override
	public String toString() {
		return "OUT";
	}

}
