package tp.pr2.mv.ins.OthersOP;

import tp.pr2.mv.ExecutionManager;
import tp.pr2.mv.Memory;
import tp.pr2.mv.OperandStack;
import tp.pr2.mv.ins.Instruction;

/**
 * Clase derivada de Binary que representa la instrucci�n LOAD.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class LOAD extends Binary {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Unary.
	 */
	public LOAD() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * M�todo constructor con par�metros que llama al constructor de
	 * Unary.
	 */
	public LOAD(int parametro) {
		super(parametro);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n 	LOAD.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public boolean execute(Memory memoria, OperandStack pila, ExecutionManager gestor) {
		int cima;
		boolean correcto = true;
		if(memoria.getContador() > 0 && memoria.comprobar(parametro)) {
			cima = memoria.ObtenerContenido(parametro);
			pila.apilar(cima);
		}
		else
			correcto = false;
		
		return correcto;
	}

	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada LOAD.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion(int d) {
		// TODO Auto-generated method stub
		return new LOAD(d);
	}
	
	/**
	 * M�todo de Other que se sobreescribe aqui correspondiente al
	 * toString de LOAD.
	 * @return Devuelve la cadena correspondiente a la instrucci�n LOAD.
	 */
	@Override
	public String toString() {
		return "LOAD";
	}

}
