/**
 * 
 */
package tp.pr2.mv.ins.JumpsOP;

import tp.pr2.mv.ExecutionManager;
import tp.pr2.mv.Memory;
import tp.pr2.mv.OperandStack;
import tp.pr2.mv.command.CommandInterpreter;
import tp.pr2.mv.ins.Instruction;

/**
 * Clase derivada de Jumps que representa la instrucci�n JUMP.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class JUMP extends Jumps {
	
	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Jumps.
	 */
	public JUMP() {
		// TODO Auto-generated constructor stub
		super();
	}

	/**
	 * M�todo constructor con par�metros que llama al constructor de
	 * Jumps.
	 */
	public JUMP(int parametro) {
		super(parametro);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n JUMP.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public boolean execute(Memory memoria, OperandStack pila, ExecutionManager gestor){

		boolean correcto = true;
		int cont = CommandInterpreter.getComputadora().getPrograma().getContador();
		
		if(parametro < cont)
			gestor.setNextPc(parametro);
		else 
			correcto = false;
		
		return correcto;
	}
	
	/**
	 * M�todo de Jumps que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada JUMP.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion(int d){
		return new JUMP(d);
	}
	
	/**
	 * M�todo de Jumps que se sobreescribe aqui correspondiente al
	 * toString de JUMP.
	 * @return Devuelve la cadena correspondiente a la instrucci�n JUMP.
	 */
	@Override
	public String toString(){
		return "JUMP";
	}

}
