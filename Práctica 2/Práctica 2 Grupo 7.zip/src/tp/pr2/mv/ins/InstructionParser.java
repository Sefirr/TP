package tp.pr2.mv.ins;

import tp.pr2.mv.ins.ArithmeticOP.ADD;
import tp.pr2.mv.ins.ArithmeticOP.DIV;
import tp.pr2.mv.ins.ArithmeticOP.MULT;
import tp.pr2.mv.ins.ArithmeticOP.SUB;
import tp.pr2.mv.ins.BooleansOP.AND;
import tp.pr2.mv.ins.BooleansOP.NOT;
import tp.pr2.mv.ins.BooleansOP.OR;
import tp.pr2.mv.ins.ComparationsOP.EQ;
import tp.pr2.mv.ins.ComparationsOP.GT;
import tp.pr2.mv.ins.ComparationsOP.LE;
import tp.pr2.mv.ins.ComparationsOP.LT;
import tp.pr2.mv.ins.JumpsOP.BF;
import tp.pr2.mv.ins.JumpsOP.BT;
import tp.pr2.mv.ins.JumpsOP.JUMP;
import tp.pr2.mv.ins.OthersOP.DUP;
import tp.pr2.mv.ins.OthersOP.FLIP;
import tp.pr2.mv.ins.OthersOP.HALT;
import tp.pr2.mv.ins.OthersOP.LOAD;
import tp.pr2.mv.ins.OthersOP.OUT;
import tp.pr2.mv.ins.OthersOP.POP;
import tp.pr2.mv.ins.OthersOP.PUSH;
import tp.pr2.mv.ins.OthersOP.STORE;

/**
 * Una clase para parsear la cadena correspondiente a la instrucci�n 
 * que quiere ejecutar el usuario. Cada instrucci�n queda determinada 
 * por su orden y par�metro.
 * @version 1.0, 17/11/2013
 * @author Grupo_7
 */
public class InstructionParser {
	
	private static Instruction[] instrucciones = {
		new ADD(), new SUB(), new MULT(), new DIV(), new AND(), new OR(), new NOT(),
		new OR(), new JUMP(), new BT(), new BF(), new DUP(), new FLIP(), new HALT(),
		new LOAD(), new OUT(), new POP(), new PUSH(), new STORE(), new EQ(), new GT(),
		new LT(), new LE()
	};

	/**
	 * Recorre el conjunto de posibles instrucciones. Si la instancia de la instrucci�n
	 * que se va a ejecutar corresponde con alguno de ellos.
	 * @param s Es la cadena correspondiente a la instrucci�n con el par�metro o no.
	 * @return Devuelve una clase derivada de Instruction.
	 */
	public static Instruction parse(String cadena) {
		// TODO Auto-generated method stub
		for(Instruction op : instrucciones){
			Instruction operacion = op.parseIns(cadena);
			if (operacion != null){
				return operacion;
			}
		}
		return null;
	}

}
