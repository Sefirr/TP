package tp.pr2.mv.ins.ArithmeticOP;

import tp.pr2.mv.ExecutionManager;
import tp.pr2.mv.Memory;
import tp.pr2.mv.OperandStack;
import tp.pr2.mv.ins.Instruction;


/**
 * Clase derivada de Arithmetic que representa la instrucci�n SUB.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class SUB extends Arithmetic {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Arithmetic.
	 */
	public SUB() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n SUB.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public boolean execute(Memory memoria, OperandStack pila, ExecutionManager gestor){
		int cima, subcima, resultado;
		boolean correcto = true;
		
		if(pila.getIndice() > 1) {
			cima = pila.getCima();
			pila.desapilar();
			subcima = pila.getCima();
			pila.desapilar();
	
			resultado = subcima - cima;
			pila.apilar(resultado);
		} else {
			correcto = false;
		}
		
		return correcto;
	}
	
	/**
	 * M�todo de Arithmetic que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada SUB.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion(){
		return new SUB();
	}
	
	/**
	 * M�todo de Arithmetic que se sobreescribe aqui correspondiente al
	 * toString de SUB.
	 * @return Devuelve la cadena correspondiente a la instrucci�n SUB.
	 */
	@Override
	public String toString(){
		return "SUB";
	}

}

