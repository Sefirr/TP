package tp.pr2.mv.ins.BooleansOP;

import tp.pr2.mv.ExecutionManager;
import tp.pr2.mv.Memory;
import tp.pr2.mv.OperandStack;
import tp.pr2.mv.ins.Instruction;

/**
 * Clase derivada de Booleans que representa la instrucci�n NOT.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class NOT extends Booleans {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Booleans.
	 */
	public NOT() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n NOT.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public boolean execute(Memory memoria, OperandStack pila, ExecutionManager gestor){
		boolean operacion;
		boolean correcto = true;
		
		if(pila.getIndice() > 1) {
			operacion = (pila.getCima() != 0) ;
			pila.desapilar();
			
			if(operacion)
				pila.apilar(0);
			else {
				pila.apilar(1);
			}
		} else {
			correcto = false;
		}
		
		return correcto;
	}
	
	/**
	 * M�todo de Booleans que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada NOT.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion(){
		return new NOT();
	}
	
	/**
	 * M�todo de Booleans que se sobreescribe aqui correspondiente al
	 * toString de NOT.
	 * @return Devuelve la cadena correspondiente a la instrucci�n NOT.
	 */
	@Override
	public String toString(){
		return "NOT";
	}

}
