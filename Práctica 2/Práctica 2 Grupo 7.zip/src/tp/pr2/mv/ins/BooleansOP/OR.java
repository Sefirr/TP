package tp.pr2.mv.ins.BooleansOP;

import tp.pr2.mv.ExecutionManager;
import tp.pr2.mv.Memory;
import tp.pr2.mv.OperandStack;
import tp.pr2.mv.ins.Instruction;

/**
 * Clase derivada de Booleans que representa la instrucci�n OR.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class OR extends Booleans {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Booleans.
	 */
	public OR() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n OR.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public boolean execute(Memory memoria, OperandStack pila, ExecutionManager gestor){
		boolean cima, subcima;
		boolean operacion;
		boolean correcto = true;
		
		if(pila.getIndice() > 1) {
			cima = (pila.getCima() != 0) ;
			pila.desapilar();
			subcima = (pila.getCima() != 0);
			pila.desapilar();
			
			
	
			operacion = subcima || cima;
			
			if(operacion)
				pila.apilar(1);
			else {
				pila.apilar(0);
			}
		} else {
			correcto = false;
		}
		
		return correcto;
	}
	
	/**
	 * M�todo de Booleans que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada OR.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion(){
		return new OR();
	}
	
	/**
	 * M�todo de Booleans que se sobreescribe aqui correspondiente al
	 * toString de OR.
	 * @return Devuelve la cadena correspondiente a la instrucci�n OR.
	 */
	@Override
	public String toString(){
		return "OR";
	}
	

}
