/**
 * 
 */
package tp.pr2.mv.cpu;

import tp.pr2.mv.COMUNES;
import tp.pr2.mv.ExecutionManager;
import tp.pr2.mv.Memory;
import tp.pr2.mv.OperandStack;
import tp.pr2.mv.command.CommandInterpreter;
import tp.pr2.mv.ins.Instruction;
import tp.pr2.mv.ins.JumpsOP.Jumps;

/**
 * Una clase CPU para representar la CPU de m�quina virtual.
 * Cada CPU contiene una memoria,una pila, un gestor de ejecuci�n y
 * un programa, es decir, el lugar donde se realizan las operaciones.
 * @version 2.0, 07/01/2014
 * @author Grupo_7
 *
 */
public class CPU {
	
	private Memory memoria; //Memoria de la CPU
	private OperandStack pila; //Memoria de la pila
	private ExecutionManager gestor; // Gestor de ejecuci�n del programa
	private ProgramMV programa; // Programa de la m�quina virtual

	/**
	 * M�todo constructor que inicializa los atributos del objeto de tipo CPU
	 * sin par�metros.
	 */
	public CPU() {
		this.memoria = new Memory();
		this.pila = new OperandStack();
		this.gestor = new ExecutionManager();
		this.programa = new ProgramMV();
	}	

	/**
	 * M�todo accedente que devuelve el valor de la memoria.
	 * @return Devuelve el valor del atributo memoria.
	 */
	public Memory getMemoria() {
		return memoria;
	}

	/**
	 * M�todo mutador que modifica el valor del atributo memoria.
	 * @param memoria Es la memoria de la CPU.
	 */
	public void setMemoria(Memory memoria) {
		this.memoria = memoria;
	}

	/**
	 * M�todo accedente que devuelve el valor de la pila.
	 * @return Devuelve el valor del atributo pila.
	 */
	public OperandStack getPila() {
		return pila;
	}

	/**
	 * M�todo mutador que modifica el valor del atributo pila.
	 * @param pila Es la pila de la CPU.
	 */
	public void setPila(OperandStack pila) {
		this.pila = pila;
	}

	/**
	 * M�todo accedente que devuelve el valor del gestor de ejecuci�n.
	 * @return Devuelve el valor del atributo gestor.
	 */
	public ExecutionManager getGestor() {
		return gestor;
	}

	/**
	 * M�todo mutador que modifica el valor del atributo gestor .
	 * @param gestor Es el gestor de ejecuci�n de la CPU.
	 */
	public void setGestor(ExecutionManager gestor) {
		this.gestor = gestor;
	}

	/**
	 * M�todo accedente que devuelve el valor de la programa.
	 * @return Devuelve el valor del atributo programa.
	 */
	public ProgramMV getPrograma() {
		return programa;
	}

	/**
	 * M�todo mutador que modifica el valor del atributo programa.
	 * @param programa Es el programa de la CPU.
	 */
	public void setPrograma(ProgramMV programa) {
		this.programa = programa;
	}

	/**
	 * M�todo que carga el programa en la CPU.
	 * @param maker Es el programa que se va a cargar en la CPU.
	 */
	public void loadProgram(ProgramMV maker) {	
		for(Instruction op: maker.getArray())
			if(op != null) 
				programa.addInstruction(op);
			
	}
	
	/**
	 * M�todo que ejecuta las diferentes instrucciones.
	 * @return Si la instrucci�n es correcta devuelve true. En caso contrario, false.
	 */
	public boolean step() {
		Instruction ins = programa.getArray()[gestor.getCurrentPc()];
		String orden = ins.toString();
	    Integer parametro = ins.getParametro();
		System.out.print("Comienza la ejecuci�n de " + orden + " ");
	    if(parametro != null)
		    System.out.println(parametro);
		else
			System.out.println();
		boolean correcto = ins.execute(memoria, pila, gestor);
		if (correcto) {
			System.out.println(CommandInterpreter.getComputadora().toString());
			gestor.actualizarPC(ins);
		} else {
			if(ins instanceof Jumps) {
				gestor.incrementPc();
				System.out.println(CommandInterpreter.getComputadora().toString());
			}
			else {
				System.out.println("Error en la ejecuci�n de la instrucci�n");
			}
		}
		
		if (gestor.getCurrentPc() >= COMUNES.MAX_INS)
			CommandInterpreter.setTerminado(true);
		
		return correcto;
	}
	
	/**
	 * Muestra el estado de la CPU.
	 */
	public String toString() {
		return "El estado de la m�quina tras ejecutar la instrucci�n es: " + 
	System.lineSeparator() + memoria + System.lineSeparator() + pila + System.lineSeparator();
	}

}
