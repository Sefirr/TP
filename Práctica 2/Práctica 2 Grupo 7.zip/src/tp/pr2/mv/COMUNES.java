package tp.pr2.mv;

import tp.pr2.mv.command.CommandInterpreter;

public class COMUNES {

	public static int MAX_INS = CommandInterpreter.getComputadora().getPrograma().getContador();
	public static final boolean isHalt = (CommandInterpreter.getComputadora().getGestor().isHalted() == false);
}
