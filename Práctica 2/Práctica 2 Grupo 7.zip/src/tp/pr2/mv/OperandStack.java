
package tp.pr2.mv;

/**
 * Una clase OperandStack para representar la pila de la CPU.
 * Cada pila contiene un atributo constante MAX_STACK correspondiente 
 * al m�ximo de elementos de la pila, un atributo array correspondiente al
 * array de enteros de la pila y un indice que indica el n�mero de elementos
 * almacenados en la pila.
 * @version 1.0, 17/11/2013
 * @author Grupo_7
 */

public class OperandStack {
	private final int MAX_STACK = 10; // M�ximo de elementos en la pila, excepto posible redimensi�n.
	private int[] array;  // Array de enteros de la pila
	private int indice; // Contador del array que indica cu�ntos elementos hay en la pila.
	private int capacidad;
	/**
	 *  M�todo constructor que inicializa los atributos del objeto de tipo OperandStack
	 * sin par�metros.
	 */
	
	public OperandStack() {
		this.capacidad = MAX_STACK;
		this.array = new int[capacidad];
		this.indice = 0;	
	}

	/**
	 * M�todo accedente que nos devuelve el valor de la cima de la pila.
	 * @return Devuelve el valor de la cima de la pila.
	 */
	
	public int getCima() {	
		return array[indice-1];
	}
	
	/**
	 * M�todo que redimensiona la pila, permitiendo introducir as� m�s elementos en la pila.
	 * @return Devuelve el array de pila redimensionado con cada uno de sus elementos.
	 */
	
	private int[] ampliar() {
		int cap = capacidad * 3 / 2 + 1;
		int[] aux = new int[cap];	
		
		for(int i = 0; i < getIndice(); i++) {
			aux[i] = array[i];
		}
		
		int[] var = new int[cap];
		
		var = aux;
		aux = array;
		
		return var;
	}
	
	/**
	 * Apila un elemento en la pila comprobando que no est� llena. 
	 * Si est� llena, redimensiona el array y introduce el nuevo 
	 * elemento en la cima de la pila.
	 * @param contenido Contenido del nuevo elemento de la pila.
	 */
	
	public void apilar(int contenido) {
		if(!estaLlena()) {
			array[indice++] = contenido;
		}
		else {
			int cap = this.capacidad;
			this.capacidad = cap* 3 / 2 + 1;
			int[] aux = new int[capacidad];
			aux = ampliar();
			array = new int[capacidad];
			array = aux; 
			array[indice++] = contenido;
		}
	}
	
	/**
	 * Desapila un elemento de la pila comprobando que no est� vacia. 
	 * Si est� vacia, no hace nada.
	 */
	public void desapilar() {
		--indice;
	}
	
	/**
	 * Comprueba si el array de la pila est� lleno.
	 * @return true si el array de la pila est� lleno.
	 */
	
	private boolean estaLlena() { 
		return ( indice == MAX_STACK ) ; 
	} 

	/**
	 * M�todo accedente que devuelve el n�mero de elementos de la pila.
	 * @return Devuelve el n�mero de elementos de la pila.
	 */
		
	public int getIndice() {
		return indice;
	}


	/**
	 * Muestra la pila.
	 */
	
	public String toString() {
		String cadena = "Pila de operandos: ";
		
		if(this.indice == 0)
			cadena = cadena + "<vacia>";
		else {
			for(int pos = 0; pos < indice; pos++) {
				cadena += array[pos] + " ";
			}
		}
			
		
		return cadena;
	}

	public void setArray(int[] array) {
		this.array = array;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}