
package tp.pr2.mv;

import tp.pr2.mv.command.CommandInterpreter;
import tp.pr2.mv.command.CommandParser;
import tp.pr2.mv.cpu.CPU;
import tp.pr2.mv.cpu.ProgramMV;
import tp.pr2.mv.ins.Instruction;
import tp.pr2.mv.ins.InstructionParser;

/**
 * @author Javier Villarreal
 *
 */
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ProgramMV programa = new ProgramMV();
		CPU computadora = new CPU();
		
		String cadena;
		
		System.out.println("Introduce el programa fuente");
		@SuppressWarnings("resource")
		java.util.Scanner sc = new java.util.Scanner(System.in);
		Instruction ins;
		
		do {
			System.out.print("> ");
			cadena = sc.nextLine();
			if(cadena.compareToIgnoreCase("end") != 0) {
				ins = InstructionParser.parse(cadena);
				if(ins == null)
					System.out.println("Error: Instrucci�n incorrecta");
				else 
					programa.addInstruction(ins);
			}
		}while(cadena.compareToIgnoreCase("end") != 0);	
		
		computadora.loadProgram(programa);
		CommandInterpreter.configureCommandInterpreter(computadora);
		System.out.println(CommandInterpreter.getComputadora().getPrograma());
		do {
			System.out.print("> ");
			cadena = sc.nextLine();
			CommandInterpreter comando = CommandParser.parseCommand(cadena);	
			if(!CommandInterpreter.isQuit()) {
				if(comando == null) {
					System.out.println("No te entiendo");
				}
				else {
					comando.executeCommand();
				}
			}	
		}while(!CommandInterpreter.isQuit() && !CommandInterpreter.getComputadora().getGestor().isHalted());
	}
}