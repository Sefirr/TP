package tp.pr2.mv.command;

import tp.pr2.mv.COMUNES;

/**
 * Clase derivada de CommanInterpreter que representa el comando RUN.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class RUN extends STEP {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * CommanInterpreter.
	 */
	public RUN() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo de CommanInterpreter que se sobreescribe aqui correspondiente a la
	 * ejecuci�n del comando RUN.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public boolean executeCommand() {
		int currentPc = 0;
		boolean correcto = true;
		
		do{
			if(currentPc < COMUNES.MAX_INS) {
			correcto = computadora.step();	  
			currentPc = computadora.getGestor().getCurrentPc();
			}
		}while(currentPc < COMUNES.MAX_INS && correcto && !computadora.getGestor().isHalted());
		
		return correcto;	
	}
	
	/**
	 * M�todo de CommanInterpreter que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada RUN.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected CommandInterpreter Command() {
		// TODO Auto-generated method stub
		return new RUN();
	}
	
	/**
	 * M�todo de CommanInterpreter que se sobreescribe aqui correspondiente al
	 * toString de RUN.
	 * @return Devuelve la cadena correspondiente al comando RUN.
	 */
	@Override
	public String toString() {
		return "RUN";
	}
	

}
