package tp.pr2.mv.command;

/**
 * Clase derivada de CommanInterpreter que representa el comando STEP.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class STEP extends CommandInterpreter {
	
	protected int parametro;

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * CommanInterpreter.
	 */
	public STEP() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo constructor con un param�tro que llama al constructor de
	 * STEPS inicializando su atributo par�metro.
	 */
	public STEP(int parametro) {
		new STEPS(parametro);
	}
	
	/**
	 * M�todo de CommanInterpreter que se sobreescribe aqui correspondiente a la
	 * ejecuci�n del comando STEP.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override	
	public boolean executeCommand() {
		return computadora.step();
		
	}
	
	/**
	 * M�todo de CommanInterpreter que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada STEP.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected CommandInterpreter Command(){
		return new STEP();
		
	}
	
	/**
	 * M�todo de CommanInterpreter que se sobreescribe aqui correspondiente al
	 * toString de STEP.
	 * @return Devuelve la cadena correspondiente al comando STEP.
	 */
	@Override
	public String toString() {
		return "STEP";
		
	}

}
