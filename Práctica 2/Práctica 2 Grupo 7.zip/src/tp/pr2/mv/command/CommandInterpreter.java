package tp.pr2.mv.command;

import tp.pr2.mv.cpu.CPU;

/**
 * Clase abstracta que representa los distintos comandos que podemos 
 * ejecutar sobre la m�quina virtual.
 * @version 1.0, 17/11/2013
 * @author Grupo_7
 *
 */

public abstract class CommandInterpreter {
	
	protected static CPU computadora; // CPU de los comandos.
	protected static boolean terminado; // Atributo que indica si la CPU est� parada.
	
	/**
	 * M�todo accedente que devuelve la CPU.
	 * @return Devuelve el contenido de la CPU.
	 */
	public static CPU getComputadora() {
		return computadora;
	}

	/**
	 * M�todo mutador que modifica el valor de la computador.
	 * @param computadora Es la computadora en la que se interpretan los par�metros.
	 */
	public static void setComputadora(CPU computadora) {
		CommandInterpreter.computadora = computadora;
	}

	
	/**
	 * M�todo que comprueba si la CPU de los comandos est� parada.
	 * @return Devuelve el valor del atributo terminado.
	 */
	public static boolean isTerminado() {
		return terminado;
	}

	/**
	 * M�todo mutador que modifica el valor del par�metro terminado.
	 * @param terminado Indica si la CPU de comandos est� parada o no.
	 * @return El valor del atributo terminado modificado.
	 */
	public static boolean setTerminado(boolean terminado) {
		return CommandInterpreter.terminado = terminado;
	}
	
	/** 
	 * M�todo est�tico que configura la CPU para poder ejecutar las instrucciones
	 * mediante el gestor de ejecuci�n.
	 * @param maquina El valor de la CPU.
	 */
	public static void configureCommandInterpreter(CPU maquina){
		computadora = maquina;
	}
	
	/**
	 * M�todo que parsea los distintos comandos en funci�n de la
	 * cadena que recibe.
	 * @param cadena Es la cadena que el usuario introduce.
	 * @return Devuelve un objeto de la clase derivada de CommandInterpreter.
	 */
	public CommandInterpreter parseComm(String cadena) {
		String [] tok = cadena.split(" ");
		if(tok.length == 2) {
			if (tok[0].equalsIgnoreCase(this.toString())){
				return new STEPS(Integer.parseInt(tok[1]));	
			}
			else return null;
		}
		if (tok.length == 1){
			if (tok[0].equalsIgnoreCase(this.toString())){
				return Command();
			}
			else return null;
		}
		else 
			return null;
	}
	
	/**
	 * M�todo que comprueba si la CPU ha parado.
	 * @return True si la CPU est� parada y false en caso contrario.
	 */
	public static boolean isQuit() {
		return (terminado == true);
	}
	
	//M�todos abstractos
	public abstract boolean executeCommand();
	protected abstract CommandInterpreter Command();
	public abstract String toString();

}