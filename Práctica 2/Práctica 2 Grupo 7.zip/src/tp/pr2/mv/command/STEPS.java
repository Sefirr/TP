package tp.pr2.mv.command;

import tp.pr2.mv.COMUNES;

/**
 * Clase derivada de STEPS que representa el comando STEPS.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class STEPS extends STEP {
	
	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * STEP.
	 */
	public STEPS() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo constructor que inicializa el atributo par�metro de STEP.
	 * @param parametro Es el par�metro del comando STEP n.
	 */
	public STEPS(int parametro) {
		super();
		this.parametro = parametro;
	}
	
	/**
	 * M�todo de CommanInterpreter que se sobreescribe aqui correspondiente a la
	 * ejecuci�n del comando STEPS.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public boolean executeCommand() {
		
		boolean correcto;
		int cont = 0, currentPc;
		do  {
			correcto = computadora.step();
			cont++;
			currentPc = computadora.getGestor().getCurrentPc();
		}while(currentPc < COMUNES.MAX_INS && cont < parametro && correcto && !computadora.getGestor().isHalt());
		
		return correcto;		
	}
	
	/**
	 * M�todo de CommanInterpreter que se sobreescribe aqui correspondiente al
	 * toString de STEPS.
	 * @return Devuelve la cadena correspondiente al comando STEPS.
	 */
	@Override
	public String toString() {
		return "STEPS";
	}

}
