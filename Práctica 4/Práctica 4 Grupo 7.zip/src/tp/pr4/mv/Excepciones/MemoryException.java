package tp.pr4.mv.Excepciones;

@SuppressWarnings("serial")
public class MemoryException extends Exception {

	private String _cause;
	
	public MemoryException(String cause) {
		super();
		this._cause = cause;
	}
	
	@Override
	public String toString() {
		return _cause;
	}

}
