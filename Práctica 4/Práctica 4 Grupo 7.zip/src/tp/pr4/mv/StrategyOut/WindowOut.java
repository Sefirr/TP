package tp.pr4.mv.StrategyOut;

public class WindowOut implements StrategyOut {
	
	String mensajeSalida;
	
	public WindowOut() {
		this.mensajeSalida = new String();
	}
	
	public void open(){
		
	}

	@Override
	public void close() {
		
	}

	@Override
	public void write(int c) {
		// TODO Auto-generated method stub
		mensajeSalida += (char) c;
	}

	@Override
	public String obtenerMensajeSalida() {
		// TODO Auto-generated method stub
		return mensajeSalida;
	}

}