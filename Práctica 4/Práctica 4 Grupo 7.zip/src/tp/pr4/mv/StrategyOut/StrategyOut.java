package tp.pr4.mv.StrategyOut;

public interface StrategyOut {
	
	public void open() throws Exception;
	public void close();
	public void write(int c);
	public String obtenerMensajeSalida();
	
}
