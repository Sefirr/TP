package tp.pr4.mv.StrategyOut;

import java.io.*;

public class FileOut implements StrategyOut {
	
	String fname;
	PrintWriter pw;
	
	public FileOut(String fname) {
		this.fname = fname;
	}
	
	public void open(){
		try {
			pw = new PrintWriter(fname);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("");
		}
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		pw.close();
	}

	@Override
	public void write(int c) {
		// TODO Auto-generated method stub
		pw.print((char) c);
	}

	@Override
	public String obtenerMensajeSalida() {
		// TODO Auto-generated method stub
		return null;
	}

}
