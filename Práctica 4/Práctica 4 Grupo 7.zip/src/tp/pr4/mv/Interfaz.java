package tp.pr4.mv;


import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.BorderFactory;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.table.AbstractTableModel;

import tp.pr4.mv.StrategyIn.StrategyIn;
import tp.pr4.mv.StrategyOut.StrategyOut;
import tp.pr4.mv.command.CommandInterpreter;
import tp.pr4.mv.command.STEP;
import tp.pr4.mv.command.RUN;
import tp.pr4.mv.command.DEBUG;
import tp.pr4.mv.cpu.CPU;
import tp.pr4.mv.cpu.Celda;
import tp.pr4.mv.ins.OthersOP.POP;
import tp.pr4.mv.ins.OthersOP.PUSH;
import tp.pr4.mv.Excepciones.*;
import tp.pr4.mv.ins.OthersOP.WRITE;

@SuppressWarnings("serial")
public class Interfaz extends JFrame {
	
	private Container _panelPrincipal;  
	private JPanel _panelCentralInterior;
	private JPanel _panelCentralExterior;
	private JPanel _panelBotones;
	private JPanel _panelPrograma;
	private JPanel _panelPila;
	private JPanel _panelComandosPila;
	private JPanel _panelMemoria;
	private JPanel _panelComandosMemoria;
	private JPanel _panelSur;
	private JPanel _panelEntrada;
	private JPanel _panelSalida;
	
	//Scrolls
	private JScrollPane ScrollPrograma;
	private JScrollPane ScrollPila;
	private JScrollPane ScrollEntrada;
	private JScrollPane ScrollSalida;
	
	// �reas de texto
	private JLabel _LValor;
	private JLabel _LPos;
	private JLabel _LVal;
	private JTextArea _programa;
	private JTextArea _pila;
	private JTextArea _Entrada;
	private JTextArea _Salida;
	private JTextField _Valor;
	private JTextField _Pos;
	private JTextField _Val;

	//Tabla
	private JTable _Tabla;
	private JScrollPane tableScrollPane;
	private ModelTable model;
	private ArrayList<Celda> data;
	
	// Botones
	private JButton _botonSTEP;
	private JButton _botonRUN;
	private JButton _botonQUIT;
	private JButton _botonPUSH;
	private JButton _botonPOP;
	private JButton _botonWRITE;	

	
	private class ModelTable extends AbstractTableModel{	

		private String[] columnas = {"DIRECCI�N ", "VALOR"};
		private ArrayList<Celda> lista = new ArrayList<Celda>();

		@Override
		public int getColumnCount() {
			return 2;
		}
		@Override
		public int getRowCount() {	
			return lista.size();
		}
		@Override
		public Object getValueAt(int rowIndex, int columnIndex) {			
			if (rowIndex>=lista.size())
				return null;
			else {
				Celda i = lista.get(rowIndex);
				if (columnIndex==0)
					return i.getPosicion();
				else if (columnIndex==1)
					return i.getContenido();				
				else
					return null;
			}
		}

		@Override
		public String getColumnName(int col) {
			return columnas[col];
		}
		public void add(Celda i) {
			lista.add(i);
			this.fireTableDataChanged();
		}
		
		public void actualizar(ArrayList<Celda> data){
			lista.clear();
			for(Celda i: data) {
				add(i);
			}
		}
	}
	
	public Interfaz(final CPU computadora, final StrategyIn in , final StrategyOut out) {
		
		super("M�quina virtual de TP");
	
		ImageIcon STEP = new ImageIcon("src/imagenes/step.png");
		ImageIcon RUN = new ImageIcon("src/imagenes/run.png");
		ImageIcon QUIT = new ImageIcon("src/imagenes/exit.png");
				
		//Panel de la ventana
		_panelPrincipal = this.getContentPane();  
		_panelPrincipal.setLayout(new BorderLayout());
		
		//Panel de los botones
		_panelBotones = new JPanel();
		_panelBotones.setLayout(new FlowLayout());
		
		 TitledBorder tituloBotones = BorderFactory.createTitledBorder("Acciones");
		 _panelBotones.setBorder(tituloBotones);
		
		_botonSTEP = new JButton(STEP);
		
		_botonSTEP.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CommandInterpreter command = new STEP();
				
				if(!CommandInterpreter.isQuit()) {
					command.executeCommand();
					_programa.setText("");
					_programa.append(computadora.InterfazPrograma());
					_pila.setText("");
					_pila.append(computadora.InterfazPila());
					_Entrada.setText("");
					_Entrada.append(computadora.mensajeEntrada());
					_Salida.setText("");
					_Salida.append(computadora.mensajeSalida());
					data = computadora.actualizarMemoria();
					model.actualizar(data);
				}
			}
		});
		
		_botonRUN = new JButton(RUN);
		
		_botonRUN.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CommandInterpreter command = new RUN();
				
				if(!CommandInterpreter.isQuit()) {
					command.executeCommand();
					_programa.setText("");
					_programa.append(computadora.InterfazPrograma());
					_pila.setText("");
					_pila.append(computadora.InterfazPila());
					_Entrada.setText("");
					_Entrada.append(computadora.mensajeEntrada());
					_Salida.setText("");
					_Salida.append(computadora.mensajeSalida());
					data = computadora.actualizarMemoria();
					model.actualizar(data);
				}
			}
		});
		
		_botonQUIT = new JButton(QUIT);
		
		_botonQUIT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				in.close();
				out.close();
				if (e.getSource().equals(_botonQUIT)){
					int i = JOptionPane.showConfirmDialog(null,
							"�Realmente desea salir?",
							"Salir ",
							JOptionPane.YES_NO_OPTION,
							JOptionPane.ERROR_MESSAGE);
					if (i == JOptionPane.YES_OPTION){
						System.exit(0);
					}
				}
			}
		});
		
		_panelBotones.add(_botonSTEP);
		_panelBotones.add(_botonRUN);
		_panelBotones.add(_botonQUIT);
		
		//Panel del programa
		_panelPrograma = new JPanel();
		
		TitledBorder TituloPanelPrograma = BorderFactory.createTitledBorder("Programa");
		_panelPrograma.setBorder(TituloPanelPrograma);
		
		_programa = new JTextArea(21,13);
		_programa.append(computadora.InterfazPrograma());
		_programa.setLineWrap(true);
		_programa.setBounds(0,0, 150,500);
		_programa.setEditable(false);
		
		ScrollPrograma = new JScrollPane(_programa);
		_panelPrograma.add(ScrollPrograma);
		
		//Panel central
		_panelCentralInterior = new JPanel();
		_panelCentralInterior.setLayout(new GridLayout(2,1));
		_panelCentralExterior = new JPanel();	
		_panelCentralExterior.setLayout(new GridLayout(1,2));
		
		//Panel de la pila
		_panelPila = new JPanel();
		_panelPila.setLayout(new GridLayout(2,1));
		
		TitledBorder TituloPila = BorderFactory.createTitledBorder("Pila de operandos");
		_panelPila.setBorder(TituloPila);
		
		_pila = new JTextArea(computadora.InterfazPila());
		ScrollPila = new JScrollPane(_pila);
		_pila.setEditable(false);
		_LValor = new JLabel("Valor: ");
		_Valor = new JTextField(5);
		
		_botonPUSH = new JButton("PUSH");
		
		_botonPUSH.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String cadena = _Valor.getText();
				try {
					if(isNumeric(cadena)) {
						int parametro = Integer.parseInt(cadena);
						CommandInterpreter command = new DEBUG(new PUSH(parametro));
						command.executeCommand();
					} else {
						throw new UndefinedInstructionException("Error: Par�metros incorrectos en el comando.");
					}
				} catch (UndefinedInstructionException e) {
					JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
				}
				_Valor.setText(null);
				_pila.setText("");
				_pila.append(computadora.InterfazPila());

			}
		});
		
		_botonPOP = new JButton("POP");
		
		_botonPOP.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {	
				CommandInterpreter command = new DEBUG(new POP());
				if(!CommandInterpreter.isQuit()) {
					command.executeCommand();
					_Valor.setText(null);
					_pila.setText("");
					_pila.append(computadora.InterfazPila());
				}
			}
		});
		
		//Panel de comandos de la pila
		_panelComandosPila = new JPanel();
		_panelComandosPila.setLayout(new FlowLayout());
		
		_panelPila.add(ScrollPila);
		_panelComandosPila.add(_LValor);
		_panelComandosPila.add(_Valor);
		_panelComandosPila.add(_botonPUSH);
		_panelComandosPila.add(_botonPOP);
		_panelPila.add(_panelComandosPila);
		
		//Panel de la memoria
		_panelMemoria = new JPanel();
		_panelMemoria.setLayout(new GridLayout(2,1));
		
		TitledBorder TituloMemoria = BorderFactory.createTitledBorder("Memoria de la m�quina");
		_panelMemoria.setBorder(TituloMemoria);
		model = new ModelTable();		
		_Tabla = new JTable(model);
		tableScrollPane = new JScrollPane(_Tabla);
		_Tabla.setFillsViewportHeight(true);
		
		//Panel de comandos para la memoria
		_panelComandosMemoria = new JPanel();
		_panelComandosMemoria.setLayout(new FlowLayout());
		_Pos  = new JTextField(5);
		_Val = new JTextField(5);
		_LPos = new JLabel("Pos: ");
		_LVal = new JLabel("Val: ");
		
		_botonWRITE = new JButton("WRITE");		
		
		_botonWRITE.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {				
				String pos = _Pos.getText();
				String content = _Val.getText();
				try {
					if(isNumeric(pos) && isNumeric(content) && !CommandInterpreter.isQuit()) {
						int _pos = Integer.parseInt(pos);	
						int _value = Integer.parseInt(content);
						CommandInterpreter command = new DEBUG(new WRITE(_pos,_value));
						command.executeCommand();
						data = computadora.actualizarMemoria();
						model.actualizar(data);
					} else if(!isNumeric(pos) || (!isNumeric(content))) {
						throw new UndefinedInstructionException("Error: Par�metros incorrectos en el comando.");
					}
				} catch(UndefinedInstructionException e) {
					JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
				}
				_Pos.setText(null);
				_Val.setText(null);
			}
		});		
		
		_panelComandosMemoria.add(_LPos);
		_panelComandosMemoria.add(_Pos);
		_panelComandosMemoria.add(_LVal);
		_panelComandosMemoria.add(_Val);
		_panelComandosMemoria.add(_botonWRITE);
		
		_panelMemoria.add(tableScrollPane);		
		_panelMemoria.add(_panelComandosMemoria);
		
		//Panel del sur
		_panelSur = new JPanel();
		_panelSur.setLayout(new GridLayout(2,1));
		
		//Panel de entrada
		_panelEntrada = new JPanel();
		
		TitledBorder TituloEntrada = new TitledBorder("Entrada del programa-p");
		_panelEntrada.setBorder(TituloEntrada);
		_Entrada = new JTextArea(4,36);
		_Entrada.append(computadora.mensajeEntrada());
		_Entrada.setLineWrap(true);
		_Entrada.setEditable(false);
		
		ScrollEntrada = new JScrollPane(_Entrada);
		_panelEntrada.add(ScrollEntrada);
		
		//Panel de salida
		_panelSalida = new JPanel();
		
		TitledBorder TituloSalida = new TitledBorder("Salida del programa-p");
		_panelSalida.setBorder(TituloSalida);
		_Salida = new JTextArea(4, 36);	
		_Salida.append(computadora.mensajeSalida());
		_Salida.setLineWrap(true);
		_Salida.setEditable(false);
		
		ScrollSalida = new JScrollPane(_Salida);
		_panelSalida.add(ScrollSalida);
		
		_panelSur.add(_panelEntrada);
		_panelSur.add(_panelSalida);
		
		_panelCentralExterior.add(_panelPila);
		_panelCentralExterior.add(_panelMemoria);
		_panelCentralInterior.add(_panelCentralExterior);
		_panelCentralInterior.add(_panelSur);
		
		_panelPrincipal.add(_panelBotones, BorderLayout.NORTH);
		_panelPrincipal.add(_panelCentralInterior, BorderLayout.CENTER);
		_panelPrincipal.add(_panelPrograma,BorderLayout.WEST);
		
		this.setLocation(50, 100);
		this.setSize(600,500);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);	
	}
	
	private static boolean isNumeric(String cadena){
		try {
			Integer.parseInt(cadena);
			return true;
		} catch (NumberFormatException nfe){
			return false;
		}
	}

}
