package tp.pr4.mv.ins.OthersOP;

import tp.pr4.mv.Excepciones.StackException;
import tp.pr4.mv.StrategyIn.StrategyIn;
import tp.pr4.mv.StrategyOut.StrategyOut;
import tp.pr4.mv.cpu.ExecutionManager;
import tp.pr4.mv.cpu.Memory;
import tp.pr4.mv.cpu.OperandStack;
import tp.pr4.mv.ins.Instruction;

/**
 * Clase derivada de Unary que representa la instrucci�n FLIP.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class FLIP extends Unary {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Unary.
	 */
	public FLIP() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n FLIP.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws StackException {
		int cima, subcima;
		
		if(pila.numElems() > 1) {
			cima = pila.getCima();
			pila.desapilar();
			subcima = pila.getCima();
			pila.desapilar();
			pila.apilar(cima);
			pila.apilar(subcima);
			gestor.setNextPc(gestor.getCurrentPc()+1);
		} else {
			throw new StackException("Error ejecutando FLIP: faltan operandos en la pila (hay " + pila.numElems() +")");
		}
		
	}

	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada FLIP.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion() {
		// TODO Auto-generated method stub
		return new FLIP();
	}
	
	/**
	 * M�todo de Others que se sobreescribe aqui correspondiente al
	 * toString de FLIP.
	 * @return Devuelve la cadena correspondiente a la instrucci�n FLIP.
	 */
	@Override
	public String toString() {
		return "FLIP";
	}
	
	@Override
	public String name(){
		return "FLIP";
	}

}
