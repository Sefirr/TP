package tp.pr4.mv.ins.OthersOP;

import java.io.FileNotFoundException;
import java.io.IOException;

import tp.pr4.mv.StrategyIn.StrategyIn;
import tp.pr4.mv.StrategyOut.StrategyOut;
import tp.pr4.mv.cpu.ExecutionManager;
import tp.pr4.mv.cpu.Memory;
import tp.pr4.mv.cpu.OperandStack;
import tp.pr4.mv.ins.Instruction;

public class IN extends Unary {
	
	public IN() {
		super();
	}

	

	@Override
	protected Instruction Instruccion() {
		// TODO Auto-generated method stub
		return new IN();
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "IN";
	}
	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "IN";
	}



	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub

		int valor = in.read();
		pila.apilar(valor);
		gestor.setNextPc(gestor.getCurrentPc() + 1);

	}
	
}
