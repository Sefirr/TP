package tp.pr4.mv.ins.OthersOP;

import tp.pr4.mv.StrategyIn.StrategyIn;
import tp.pr4.mv.StrategyOut.StrategyOut;
import tp.pr4.mv.cpu.ExecutionManager;
import tp.pr4.mv.cpu.Memory;
import tp.pr4.mv.cpu.OperandStack;
import tp.pr4.mv.ins.Instruction;

public class JUMPIND extends Unary{
		/**
		 * M�todo constructor sin par�metros que llama al constructor de
		 * Jumps.
		 */
		public JUMPIND() {
			// TODO Auto-generated constructor stub
			super();
		}
		
		/**
		 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
		 * ejecuci�n de la instrucci�n JUMPIND.
		 * @return Devuelve si el comando es correcto o no.
		 */
		@Override
		public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out){
		
		    int cima = pila.getCima();
		    pila.desapilar();
		    gestor.setNextPc(cima);
			
		}
		
		/**
		 * M�todo de Jumps que se sobreescribe aqui correspondiente a devolver
		 * un objeto de la clase derivada JUMPIND.
		 * @return Devuelve el objeto de la clase derivada.
		 */
		@Override
		protected Instruction Instruccion(){
			return new JUMPIND();
		}
		
		/**
		 * M�todo de Jumps que se sobreescribe aqui correspondiente al
		 * toString de JUMPIND.
		 * @return Devuelve la cadena correspondiente a la instrucci�n JUMPIND.
		 */
		@Override
		public String toString(){
			return "JUMPIND";
		}

		@Override
		public String name() {
			// TODO Auto-generated method stub
			return "JUMPIND";
		}
}