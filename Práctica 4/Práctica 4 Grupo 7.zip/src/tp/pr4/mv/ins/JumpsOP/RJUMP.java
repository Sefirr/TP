package tp.pr4.mv.ins.JumpsOP;

import tp.pr4.mv.StrategyIn.StrategyIn;
import tp.pr4.mv.StrategyOut.StrategyOut;
import tp.pr4.mv.cpu.ExecutionManager;
import tp.pr4.mv.cpu.Memory;
import tp.pr4.mv.cpu.OperandStack;
import tp.pr4.mv.ins.Instruction;

/**
 * Clase derivada de Jumps que representa la instrucci�n JUMP.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class RJUMP extends JUMP {
	
	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Jumps.
	 */
	public RJUMP() {
		// TODO Auto-generated constructor stub
		super();
	}

	/**
	 * M�todo constructor con par�metros que llama al constructor de
	 * Jumps.
	 */
	public RJUMP(int parametro) {
		super(parametro);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n JUMP.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out){
	
	    gestor.setNextPc(gestor.getCurrentPc()+parametro);
	}
	
	/**
	 * M�todo de Jumps que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada JUMP.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion(int d){
		return new RJUMP(d);
	}
	
	/**
	 * M�todo de Jumps que se sobreescribe aqui correspondiente al
	 * toString de JUMP.
	 * @return Devuelve la cadena correspondiente a la instrucci�n JUMP.
	 */
	@Override
	public String toString(){
		return "RJUMP";
	}

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "RJUMP " + parametro;
	}

}