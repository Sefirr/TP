/**
 * 
 */
package tp.pr4.mv.ins.JumpsOP;

import tp.pr4.mv.Excepciones.StackException;
import tp.pr4.mv.StrategyIn.StrategyIn;
import tp.pr4.mv.StrategyOut.StrategyOut;
import tp.pr4.mv.cpu.ExecutionManager;
import tp.pr4.mv.cpu.Memory;
import tp.pr4.mv.cpu.OperandStack;
import tp.pr4.mv.ins.Instruction;

/**
 * Clase derivada de Jumps que representa la instrucci�n BF.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class BF extends Jumps {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * Jumps.
	 */
	public BF() {
		// TODO Auto-generated constructor stub
		super();
	}

	/**
	 * M�todo constructor con par�metros que llama al constructor de
	 * Jumps.
	 */
	public BF(int parametro) {
		super(parametro);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * M�todo de Instruction que se sobreescribe aqui correspondiente a la
	 * ejecuci�n de la instrucci�n BF.
	 * @return Devuelve si el comando es correcto o no.
	 * @throws JumpsException 
	 */
	@Override
	public void execute(Memory memoria, OperandStack pila, ExecutionManager gestor, StrategyIn in, StrategyOut out) throws StackException{

		boolean cima;
		
		if(pila.numElems() >= 1) {
			cima = (pila.getCima() != 0);
			pila.desapilar();
			
			if(cima == false)
				gestor.setNextPc(parametro);
			else if(cima == true)
				gestor.setNextPc(gestor.getCurrentPc()+1);
		} else {
			throw new StackException("Error ejecutando BF: faltan operandos en la pila (hay " + pila.numElems() +")");
		}
	}
	
	/**
	 * M�todo de Jumps que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada BF.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected Instruction Instruccion(int d){
		return new BF(d);
	}
	
	/**
	 * M�todo de Jumps que se sobreescribe aqui correspondiente al
	 * toString de BF.
	 * @return Devuelve la cadena correspondiente a la instrucci�n BF.
	 */
	@Override
	public String toString(){
		return "BF";
	}

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "BF " + parametro;
	}

	@Override
	protected Instruction Instruccion() {
		// TODO Auto-generated method stub
		return null;
	}

}

