package tp.pr4.mv.cpu;

import java.util.ArrayList;



/**
 * Una clase memoria para representar la memoria de la CPU.
 * Cada memoria contiene un atributo constante MAX_MEMORY correspondiente 
 * al m�ximo de elementos de la memoria, un atributo array correspondiente al
 * array de celdas de la memoria y un contador que indica el n�mero de elementos
 * almacenados en memoria.
 * @version 1.0, 17/11/2013
 * @author Grupo_7
 */
public class Memory {
	private ArrayList<Celda> array; //Array de celdas de la memoria
	
	/**
	 * M�todo constructor que inicializa los atributos del objeto de tipo Memory
	 * sin par�metros.
	 */
	
	public Memory() {
		this.array = new ArrayList<Celda>();
	}
	
	/**
	 * M�todo accedente que devuelve el n�mero de elementos de la memoria.
	 * @return N�mero de elementos de la memoria.
	 */
	
	public int numElems() {
		return array.size();
	}
	
	/**
	 * Busca si la posici�n en la que quieres introducir la cima de la pila ya existe 
	 * para poder modificarla.
	 * @param indice Posici�n en la que quiere colocar la cima de la pila.
	 * @return Devuelve la posici�n existente en donde se quiere a�adir la cima.
	 */
	
	private int buscarPosicion(int indice) {
		boolean encontrada = false;
		int ini = 0;
		int fin = array.size() - 1;
		int mitad = 0;
		int pos = 0;
		
		

		while ((ini <= fin) && !encontrada) {
			mitad = (ini + fin) / 2;
			if ( indice == array.get(mitad).getPosicion()) 
				encontrada = true;
			else if (indice < array.get(mitad).getPosicion()) 
				fin = mitad - 1;
			else 
				ini = mitad + 1;
		}
		
		if(encontrada) {
			pos = mitad;
		}
		else {
			pos = 0;
		}
			
		return pos;
	}
	
	/**
	 * Comprueba si la posici�n coincide con el indice
	 * @param pos
	 * @return true si la posici�n coincide con el indice
	 */
	public boolean comprobar(int indice) {
		boolean comprobar;
		int buscado = buscarPosicion(indice);
		if(array.get(buscado).getPosicion() == indice)
			comprobar = true;
		else 
			comprobar = false;
		
		return comprobar;
	}
	
	/**
	 * Devuelve el contenido de la celda correspondiente al indice.
	 * @param indice Posici�n del dato que se quiere a�adir a la memoria.
	 * @return El contenido de la celda con ese indice.
	 */
	
	public int ObtenerContenido(int indice) {
		int buscado = buscarPosicion(indice);
		return array.get(buscado).getContenido();
	}
	
	/**
	 * Comprueba si la memoria est� vacia.
	 * @return true si la memoria est� vacia.
	 */
	
	private boolean esVacia() {
		return array.isEmpty();
	}
	
	/**
	 * Inserta en memoria la cima de la pila en la posici�n corresponidente.
	 * @param pos Posici�n en la que vamos a a�adir la celda con el contenido de la cima de la pila.
	 * @param contenido Contenido de la celda.
	 */
	
	public void insertar(int pos, int contenido){
		int buscado = buscarPosicion(pos);
		Celda dato = new Celda(pos, contenido);
        
        if(esVacia()){
			array.add(dato);
		}
		else {
			if(array.get(buscado).getPosicion() == pos) {
				array.get(buscado).setContenido(contenido);
			} else {
				int i = 0;
				while((i < array.size()) && (dato.getPosicion() > array.get(i).getPosicion()))
					i++;
				
				for(int j = array.size(); j > i; j-- ) {
					array.add(j, array.get(j-1));
					array.remove(j-1);
				}
	
				
				array.add(i, dato);
			}
		}	
    }
	
	/**
	 * M�todo accedente que devuelve la celda de memoria  que tiene el indice indicado por el par�metro.
	 * @return Devuelve la celda de memoria que tiene el indice del par�metro.
	 */
	public Celda getCelda(int parametro){
		return array.get(parametro);
	}
 
	/**
	 * Muestra la memoria. 
	 */
	
	public String toString() {
		String cadena = "Memoria: ";
		
		if(esVacia())
			cadena = cadena + "<vacia>";
		else {
			for(Celda cell: this.array) {
				if(cell != null)
					cadena += cell.toString() + " ";
			}
		}
		
		return cadena;
	}

}
