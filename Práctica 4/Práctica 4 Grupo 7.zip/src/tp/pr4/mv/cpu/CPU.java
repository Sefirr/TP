/**
 * 
 */

package tp.pr4.mv.cpu;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import tp.pr4.mv.Excepciones.ArithmeticException;
import tp.pr4.mv.Excepciones.MemoryException;
import tp.pr4.mv.Excepciones.StackException;
import tp.pr4.mv.StrategyIn.StrategyIn;
import tp.pr4.mv.StrategyOut.StrategyOut;
import tp.pr4.mv.command.CommandInterpreter;
import tp.pr4.mv.ins.Instruction;

/**
 * Una clase CPU para representar la CPU de m�quina virtual.
 * Cada CPU contiene una memoria,una pila, un gestor de ejecuci�n y
 * un programa, es decir, el lugar donde se realizan las operaciones.
 * @version 2.0, 07/01/2014
 * @author Grupo_7
 *
 */
public class CPU {
	
	private Memory memoria; //Memoria de la CPU
	private OperandStack pila; //Memoria de la pila
	private ExecutionManager gestor; // Gestor de ejecuci�n del programa
	private ProgramMV programa; // Programa de la m�quina virtual
	private StrategyIn in;
	private StrategyOut out;

	/**
	 * M�todo constructor que inicializa los atributos del objeto de tipo CPU
	 * sin par�metros.
	 */
	public CPU(StrategyIn entrada, StrategyOut salida) {
		this.memoria = new Memory();
		this.pila = new OperandStack();
		this.gestor = new ExecutionManager();
		this.programa = new ProgramMV();
		this.in = entrada;
		this.out = salida;
	}

	/**
	 * M�todo que carga el programa en la CPU.
	 * @param maker Es el programa que se va a cargar en la CPU.
	 */
	public void loadProgram(ProgramMV maker) {	
		this.programa = maker;
	}
	
	public boolean isHalted() {
		return (gestor.getCurrentPc() > programa.size() - 1) || (gestor.isHalted() == true);
	}
	
	/**
	 * M�todo que ejecuta las diferentes instrucciones.
	 * @return Si la instrucci�n es correcta devuelve true. En caso contrario, false.
	 */
	public boolean step(){
		
		boolean correcto = false;
		
		try {
			Instruction ins = programa.getInstruction(gestor.getCurrentPc());	
			
			System.out.println("Comienza la ejecuci�n de " + ins.name());
			
			ins.execute(memoria, pila, gestor,in, out);
		
				
			correcto = true;
			
			System.out.print(toString());
			
			gestor.incrementPc();
			
			if (isHalted())
				CommandInterpreter.PararEjecucion();
		} catch (StackException e) {
			// TODO Auto-generated catch block
			if(CommandInterpreter.informarModo() == "window")
				JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
			System.err.println(e);
		} catch (MemoryException e) {
			// TODO Auto-generated catch block
			if(CommandInterpreter.informarModo() == "window")
				JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
			System.err.println(e);
		} catch (ArithmeticException e) {
			// TODO Auto-generated catch block
			if(CommandInterpreter.informarModo() == "window")
				JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
			System.err.println(e);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			if(CommandInterpreter.informarModo() == "window")
				JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
			System.err.println(e);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			if(CommandInterpreter.informarModo() == "window")
				JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
			System.err.println(e);
		}
		
		return correcto;
	}
	
	/**
	 * M�todo auxiliar que ejecuta las diferentes instrucciones del comando DEBUG.
	 * @return Si la instrucci�n es correcta devuelve true. En caso contrario, false.
	 */
	public boolean step(Instruction i){
		boolean correcto = false;
		
		try {
			i.execute(memoria, pila, gestor, in, out);
			
			correcto = true;
		} catch (StackException e) {
			// TODO Auto-generated catch block
			if(CommandInterpreter.informarModo() == "window")
				JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
			System.err.println(e);
		} catch (MemoryException e) {
			// TODO Auto-generated catch block
			if(CommandInterpreter.informarModo() == "window")
				JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
			System.err.println(e);
		} catch (ArithmeticException e) {
			// TODO Auto-generated catch block
			if(CommandInterpreter.informarModo() == "window")
				JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
			System.err.println(e);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			if(CommandInterpreter.informarModo() == "window")
				JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
			System.err.println(e);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			if(CommandInterpreter.informarModo() == "window")
				JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
			System.err.println(e);
		}
		
		return correcto;
	}
	
	/*
	 * M�todo que proporciona a la interfaz gr�fica la pila.
	 * @return Devuelve la interfaz de la pila.
	 */
	public String InterfazPila() {
		String cadena = "";
		
		if(pila.esVacia())
			cadena = " ";
		else {
			for(int pos = 0; pos < pila.numElems(); pos++) {
				cadena += pila.getPosicion(pos) + System.lineSeparator();
			}
		}
			
		return cadena;
	}
	
	/*
	 * M�todo que proporciona a la interfaz gr�fica el programa.
	 * @return Devuelve la interfaz del programa.
	 */
	public String InterfazPrograma() {
		Instruction ins;
		int contador = 0;
		String cadena = "";
		
		for(int i = 0; i < programa.size(); i++) {
			ins = programa.getInstruction(i);
			if(contador == gestor.getCurrentPc()) {
				cadena += "*      " + contador + ": " + ins.name() + System.lineSeparator();
			}
			else {
				cadena += "        " + contador + ": " + ins.name() + System.lineSeparator();
			}
			contador++;	
		}
		
		return cadena;
	}
	
	/*
	 * M�todo que proporciona a la interfaz gr�fica la entrada del programa.
	 * @return Devuelve la entrada del programa.
	 */
	public String mensajeEntrada() {
		return in.obtenerMensajeEntrada();
	}
	
	/*
	 * M�todo que proporciona a la interfaz gr�fica la salida del programa.
	 * @return Devuelve la salida del programa.
	 */
	public String mensajeSalida() {
		return out.obtenerMensajeSalida();
	}
	
	/*
	 * M�todo que proporciona actualiza la memoria en la interfaz gr�fica.
	 * @return Devuelve la memoria actualizada.
	 */
	public ArrayList<Celda> actualizarMemoria() {
		ArrayList<Celda> datos = new ArrayList<Celda>();
		datos.clear();
		for(int i = 0; i < memoria.numElems(); i++) {
			datos.add(memoria.getCelda(i));
		}
		return datos;
	}
	
	/**
	 * Muestra el estado de la CPU.
	 */
	public String toString() {
		return "El estado de la m�quina tras ejecutar la instrucci�n es: " + 
	System.lineSeparator() + memoria + System.lineSeparator() + pila + System.lineSeparator();
	}

}
