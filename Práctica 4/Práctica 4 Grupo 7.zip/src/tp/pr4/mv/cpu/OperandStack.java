
package tp.pr4.mv.cpu;

import java.util.ArrayList;

/**
 * Una clase OperandStack para representar la pila de la CPU.
 * Cada pila contiene un atributo constante MAX_STACK correspondiente 
 * al m�ximo de elementos de la pila, un atributo array correspondiente al
 * array de enteros de la pila y un indice que indica el n�mero de elementos
 * almacenados en la pila.
 * @version 1.0, 17/11/2013
 * @author Grupo_7
 */

public class OperandStack {
	
	private ArrayList<Integer> array; //Array de enteros de la pila
	
	/**
	 *  M�todo constructor que inicializa los atributos del objeto de tipo OperandStack
	 * sin par�metros.
	 */
	
	public OperandStack() {
		this.array = new ArrayList<Integer>();
	}

	/**
	 * M�todo accedente que nos devuelve el valor de la cima de la pila.
	 * @return Devuelve el valor de la cima de la pila.
	 */
	
	public int getCima() {	
		return array.get(array.size()-1);
	}
	
	/**
	 * Apila un elemento en la pila comprobando que no est� llena. 
	 * Si est� llena, redimensiona el array y introduce el nuevo 
	 * elemento en la cima de la pila.
	 * @param contenido Contenido del nuevo elemento de la pila.
	 */
	
	public void apilar(Integer contenido) {
		array.add(contenido);
	}
	
	/**
	 * Comprueba si la pila est� vacia.
	 * @return true si la pila est� vacia.
	 */
	public boolean esVacia() {
		return array.isEmpty();
	}
	
	/**
	 * Desapila un elemento de la pila comprobando que no est� vacia. 
	 * Si est� vacia, no hace nada.
	 */
	public void desapilar() {
		array.remove(array.size()-1);
	} 

	/**
	 * M�todo accedente que devuelve el n�mero de elementos de la pila.
	 * @return Devuelve el n�mero de elementos de la pila.
	 */
		
	public int numElems() {
		return array.size();
	}
	
	
	/**
	 * M�todo accedente que devuelve el elemento de la pila  que tiene el indice indicado por el par�metro.
	 * @return Devuelve el elemento de la pila que tiene el indice del par�metro.
	 */
	public Integer getPosicion(int parametro){
		return array.get(parametro);
	}
	
	/**
	 * Muestra la pila.
	 */
	
	public String toString() {
		String cadena = "Pila de operandos: ";
		if(esVacia())
			cadena = cadena + "<vacia>";
		else {
			for(int pos = 0; pos < numElems(); pos++) {
				cadena += array.get(pos) + " ";
			}
		}
			
		
		return cadena;
	}

}