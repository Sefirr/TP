/**
 * 
 */
package tp.pr4.mv.cpu;

import java.util.Vector;
import tp.pr4.mv.ins.Instruction;


/**
 * Clase que representa un programa. Contiene un atributo array que es el array de
 * instruciones y atributo contador.
 * @author usuario_local
 *
 */
public class ProgramMV {
	private Vector<Instruction> array;
	
	/**
	 * M�todo constructor sin par�metros que inicializa los atributos del objeto ProgramMV.
	 */
	public ProgramMV() {
		array = new Vector<Instruction>();
	}
	
	/**
	 * Procedimiento encargado de a�adir instrucciones. Con cada instrucci�n que
	 * se a�ade, se incrementa el contador.
	 * @param ins Es la instrucci�n que se va a a�adir al programa.
	 */
	public void addInstruction(Instruction ins) {
		array.add(ins);
	}
	
	/**
	 * M�todo accedente que devuelve la instrucci�n  que tiene el indice indicado por el par�metro.
	 * @return Devuelve la instrucci�n que tiene el indice del par�metro.
	 */
	public Instruction getInstruction(int parametro) {
		return array.get(parametro);
	}
	
	/**
	 * M�todo accedente que devuelve la �ltima posici�n ocupada en el array.	
	 * @return Devuelve el n� de instrucciones del programa.
	 */
	public int size() {
		return array.size();
	}

	/**
	 * Muestra la informaci�n correspondiente al programa, es decir, el conjunto 
	 * de instrucciones del programa.
	 */
	@Override
	public String toString() {
		
		String cadena = "El programa introducido es: ";
		int contador = 0;
		for(Instruction ins: array) {
			if(ins != null) {
				cadena += System.lineSeparator() + contador + ": " + ins.name() + "      ";
				contador++;
			}
		}
		
		return cadena;
	}
	
}