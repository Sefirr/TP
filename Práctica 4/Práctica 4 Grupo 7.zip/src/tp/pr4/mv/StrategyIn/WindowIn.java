package tp.pr4.mv.StrategyIn;

import java.io.*;

public class WindowIn implements StrategyIn {

	String fname;
	String mensajeEntrada;
	FileReader f;
	int numeroCaracter;
	
	public WindowIn(String fname) {
		this.fname = fname;	
		this.numeroCaracter = 0;
		this.mensajeEntrada = new String();
	}
	
	@Override
	public void open() {
		// TODO Auto-generated method stub
		try {
			f = new FileReader(fname);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("");
		}
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		try {
			f.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("");
		}
	}
	
	@Override
	public int read() {
		// TODO Auto-generated method stub
		char car;
		try {
			
			if(f.ready() && numeroCaracter < mensajeEntrada.length()) {
				car = (char) f.read();
				char[] linea = mensajeEntrada.toCharArray();
				if(mensajeEntrada.charAt(numeroCaracter) == '\n');
				else if(mensajeEntrada.charAt(numeroCaracter) == car)
					linea[numeroCaracter] = '*';
					
				mensajeEntrada = new String(linea);
				numeroCaracter++;
				return (int) car;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			return -1;
		}
		return -1;
	}

	public void leerFichero() {
		// TODO Auto-generated method stub
		int linea;
		BufferedReader entrada = new BufferedReader(f);
		try {
			do {
				linea = entrada.read();
				if(linea != -1)
					mensajeEntrada += (char) linea;
			} while(linea != -1);
			close();
			open();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public String obtenerMensajeEntrada() {
		// TODO Auto-generated method stub
		return mensajeEntrada;
	}
	
}
