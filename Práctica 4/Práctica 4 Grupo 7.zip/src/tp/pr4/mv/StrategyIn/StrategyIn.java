package tp.pr4.mv.StrategyIn;

public interface StrategyIn {
	
	public void open();
	public void close();
	public int read();
	public void leerFichero();
	public String obtenerMensajeEntrada();

	
}
