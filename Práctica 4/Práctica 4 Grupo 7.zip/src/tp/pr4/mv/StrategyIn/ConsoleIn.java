package tp.pr4.mv.StrategyIn;

import java.io.IOException;

public class ConsoleIn implements StrategyIn {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public int read() {
		// TODO Auto-generated method stub

			int ret = 0;
			String cadena = new String();
			char caracter;
			try {
				caracter = (char) System.in.read();
				cadena += caracter;
				
				if(Character.isDigit(caracter)) {
					do {
						caracter = (char) System.in.read();
						cadena += caracter;						
					} while(caracter != '\n');
					cadena = cadena.trim();
					ret = Integer.parseInt(cadena);		
				} else if (caracter == 45) {
					caracter = (char) System.in.read();
					cadena += caracter;
					
					if(Character.isLetter(caracter)) {
						ret = caracter;
					} else if(Character.isDigit(caracter)) {
						do {
							caracter = (char) System.in.read();
							cadena += caracter;						
						} while(caracter != '\n');
						cadena = cadena.trim();
						ret = Integer.parseInt(cadena);
					}	
				} else {
					ret = (int) caracter;
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
		return ret;
	}

	@Override
	public String obtenerMensajeEntrada() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void leerFichero() {
		// TODO Auto-generated method stub
		
	}	

}
