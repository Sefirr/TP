package tp.pr4.mv.StrategyIn;

public class NullIn implements StrategyIn {

	@Override
	public void open() {
		// TODO Auto-generated method stub

	}

	@Override
	public void close() {
		// TODO Auto-generated method stub

	}

	@Override
	public int read() {
		// TODO Auto-generated method stub
		return -1;
	}

	@Override
	public String obtenerMensajeEntrada() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void leerFichero() {
		// TODO Auto-generated method stub
		
	}

}