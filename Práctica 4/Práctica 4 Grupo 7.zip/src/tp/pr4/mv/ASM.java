package tp.pr4.mv;

import java.io.*;

import tp.pr4.mv.cpu.ProgramMV;
import tp.pr4.mv.ins.Instruction;
import tp.pr4.mv.ins.InstructionParser;

public class ASM {
	
	String fname;
	FileReader archivo;
	
	public ASM(String fname) {
		this.fname = fname;	
	}
	
	
	public void leer(ProgramMV programa) throws IOException {
	
		Instruction ins = null;
		
		archivo = new FileReader(fname);
		BufferedReader entrada  = new BufferedReader(archivo);
		String cadena = "";
		String instruccion = "";
		do {
			cadena = entrada.readLine();
			for(int i = 0; i < cadena.length(); i++) {
				if(cadena.charAt(i) != ';') {
					instruccion += cadena.charAt(i);
				} else {
					i = cadena.length();
				}
			}
			ins = InstructionParser.parse(instruccion);
			if(instruccion.isEmpty() == false) {
				instruccion = "";
			if(ins == null) {
				throw new IOException("Error en el programa. L�nea: " + cadena);
			} else 
				programa.addInstruction(ins);
			}
		 } while(entrada.ready());
		entrada.close();			

		
	}

}