package tp.pr4.mv.command;


/**
 * Clase derivada de CommanInterpreter que representa el comando RUN.
 * @version 2.0
 * @author Grupo_7
 *
 */
public class RUN extends STEP {

	/**
	 * M�todo constructor sin par�metros que llama al constructor de
	 * CommanInterpreter.
	 */
	public RUN() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * M�todo de CommanInterpreter que se sobreescribe aqui correspondiente a la
	 * ejecuci�n del comando RUN.
	 * @return Devuelve si el comando es correcto o no.
	 */
	@Override
	public void executeCommand() {
		
		boolean correcto = false;
		
		do{
			correcto = computadora.step();	  
		} while(correcto && !CommandInterpreter.isQuit());
		
	}
	
	/**
	 * M�todo de CommanInterpreter que se sobreescribe aqui correspondiente a devolver
	 * un objeto de la clase derivada RUN.
	 * @return Devuelve el objeto de la clase derivada.
	 */
	@Override
	protected CommandInterpreter Command() {
		// TODO Auto-generated method stub
		return new RUN();
	}
	
	/**
	 * M�todo de CommanInterpreter que se sobreescribe aqui correspondiente al
	 * toString de RUN.
	 * @return Devuelve la cadena correspondiente al comando RUN.
	 */
	@Override
	public String toString() {
		return "RUN";
	}

}
