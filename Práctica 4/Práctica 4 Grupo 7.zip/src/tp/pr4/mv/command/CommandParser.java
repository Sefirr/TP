package tp.pr4.mv.command;



/**
 * Una clase para parsear la cadena correspondiente al comando 
 * que quiere ejecutar el usuario. 
 * @version 1.0, 17/11/2013
 * @author Grupo_7
 */
public class CommandParser {
	
	private static CommandInterpreter[] command = {
		new STEP(), new STEPS(), new RUN(), new QUIT(), new DEBUG()
	};

	/**
	 * Recorre el conjunto de posibles comandos. Si la instancia del comando
	 * que se va a ejecutar corresponde con alguno de ellos.
	 * @param s Es la cadena correspondiente al comando con el par�metro o no.
	 * @return Devuelve una clase derivada de CommandInterpreter.
	 */
	public static CommandInterpreter parseCommand(String cadena) {
		// TODO Auto-generated method stub
		for(CommandInterpreter op : command){
			CommandInterpreter command = op.parseComm(cadena);
			if (command != null){
				return command;
			}
		}
		return null;
	}

}
